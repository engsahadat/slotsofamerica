-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2026 at 07:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slotsofamerica`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `action` varchar(255) NOT NULL,
  `target_type` varchar(255) NOT NULL,
  `target_id` varchar(255) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `admin_id`, `action`, `target_type`, `target_id`, `details`, `ip_address`, `created_at`, `updated_at`) VALUES
(1, 3, 'approved_game_access', 'GameUnlockRequest', '3', '{\"game_id\":1,\"admin_note\":null}', '127.0.0.1', '2026-08-02 07:34:23', '2026-08-02 07:34:23'),
(2, 1, 'approved_game_access', 'GameUnlockRequest', '2', '{\"game_id\":2,\"admin_note\":null}', '127.0.0.1', '2026-08-02 08:25:28', '2026-08-02 08:25:28'),
(3, 1, 'approved_game_access', 'GameUnlockRequest', '5', '{\"game_id\":2,\"admin_note\":null}', '127.0.0.1', '2026-08-02 08:25:53', '2026-08-02 08:25:53'),
(4, 3, 'approved_game_access', 'GameUnlockRequest', '7', '{\"game_id\":3,\"admin_note\":null}', '127.0.0.1', '2026-08-02 08:48:49', '2026-08-02 08:48:49'),
(5, 3, 'approved_password_request', 'PasswordRequest', '1', '{\"game_account_id\":6}', '127.0.0.1', '2026-08-02 08:54:06', '2026-08-02 08:54:06'),
(6, 3, 'created_game', 'Game', '10', '{\"name\":\"test\"}', '127.0.0.1', '2026-08-07 04:10:42', '2026-08-07 04:10:42'),
(7, 3, 'deleted_game', 'Game', '10', '{\"name\":\"test\"}', '127.0.0.1', '2026-08-07 04:10:50', '2026-08-07 04:10:50'),
(8, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-08-07 11:01:24', '2026-08-07 11:01:24'),
(9, 3, 'create_backup', 'Backup', '2', '{\"size_bytes\":112160,\"storage_path\":\"backups\\/full\\/full-manual-20260812-165733.zip\"}', '127.0.0.1', '2026-08-12 10:57:33', '2026-08-12 10:57:33'),
(10, 3, 'download_backup', 'Backup', '2', '[]', '127.0.0.1', '2026-08-12 10:57:47', '2026-08-12 10:57:47'),
(11, 3, 'customer_export', 'User', NULL, '{\"format\":\"csv\",\"scope\":\"emergency\",\"count\":515}', '127.0.0.1', '2026-08-12 10:58:24', '2026-08-12 10:58:24'),
(12, 1, 'toggled_game_api_provider_is_active', 'GameApiProvider', '1', '{\"name\":\"gameroom777\",\"value\":true}', '127.0.0.1', '2026-08-12 11:11:05', '2026-08-12 11:11:05'),
(13, 3, 'updated_reward', 'RewardsConfig', '1', '{\"key\":\"welcome_bonus\"}', '127.0.0.1', '2026-08-12 12:38:57', '2026-08-12 12:38:57'),
(14, 3, 'updated_reward', 'RewardsConfig', '2', '{\"key\":\"daily_checkin\"}', '127.0.0.1', '2026-08-12 12:38:57', '2026-08-12 12:38:57'),
(15, 3, 'updated_reward', 'RewardsConfig', '3', '{\"key\":\"referral_reward\"}', '127.0.0.1', '2026-08-12 12:38:57', '2026-08-12 12:38:57'),
(16, 3, 'updated_redeem_settings', 'SiteSetting', '1', '{\"min_amount\":45,\"max_amount\":300}', '127.0.0.1', '2026-08-12 13:32:18', '2026-08-12 13:32:18'),
(17, 3, 'updated_redeem_settings', 'SiteSetting', '1', '{\"min_amount\":40,\"max_amount\":300}', '127.0.0.1', '2026-08-12 13:32:24', '2026-08-12 13:32:24'),
(18, 3, 'toggled_game_api_provider_is_active', 'GameApiProvider', '2', '{\"name\":\"gamevault999\",\"value\":true}', '127.0.0.1', '2026-08-12 23:15:52', '2026-08-12 23:15:52'),
(19, 3, 'set_game_api_provider_password', 'GameApiProvider', '2', '{\"name\":\"gamevault999\"}', '127.0.0.1', '2026-08-12 23:17:14', '2026-08-12 23:17:14'),
(20, 3, 'balance_adjustment', 'User', '7', '{\"old_balance\":0,\"new_balance\":0,\"reason\":\"teat\"}', '127.0.0.1', '2026-08-12 23:54:15', '2026-08-12 23:54:15'),
(21, 3, 'balance_adjustment', 'User', '7', '{\"old_balance\":0,\"new_balance\":10,\"reason\":\"test\"}', '127.0.0.1', '2026-08-12 23:54:44', '2026-08-12 23:54:44'),
(22, 3, 'balance_adjustment', 'User', '515', '{\"old_balance\":0,\"new_balance\":500,\"reason\":\"Developer\"}', '127.0.0.1', '2026-08-12 23:55:17', '2026-08-12 23:55:17'),
(23, 3, 'balance_adjustment', 'User', '513', '{\"old_balance\":0,\"new_balance\":200,\"reason\":\"test\"}', '127.0.0.1', '2026-08-12 23:55:40', '2026-08-12 23:55:40'),
(24, 3, 'created_transaction', 'Transaction', '5', '{\"type\":\"deposit\",\"amount\":500,\"status\":\"approved\"}', '127.0.0.1', '2026-08-13 10:09:52', '2026-08-13 10:09:52'),
(35, 3, 'approved_transaction', 'Transaction', '22', '{\"type\":\"redeem\",\"amount\":40,\"note\":null}', '127.0.0.1', '2026-08-13 11:17:55', '2026-08-13 11:17:55'),
(36, 3, 'approved_transaction', 'Transaction', '20', '{\"type\":\"transfer\",\"amount\":20,\"note\":null}', '127.0.0.1', '2026-08-13 11:18:01', '2026-08-13 11:18:01'),
(37, 3, 'approved_transaction', 'Transaction', '9', '{\"type\":\"transfer\",\"amount\":10,\"note\":null}', '127.0.0.1', '2026-08-13 11:18:02', '2026-08-13 11:18:02'),
(38, 3, 'approved_transaction', 'Transaction', '6', '{\"type\":\"deposit\",\"amount\":10,\"note\":null}', '127.0.0.1', '2026-08-13 11:18:06', '2026-08-13 11:18:06'),
(39, 3, 'approved_transaction', 'Transaction', '23', '{\"type\":\"withdraw\",\"amount\":100,\"note\":null}', '127.0.0.1', '2026-08-13 11:19:14', '2026-08-13 11:19:14'),
(40, 3, 'set_game_api_provider_password', 'GameApiProvider', '2', '{\"name\":\"gamevault999\"}', '127.0.0.1', '2026-08-16 11:12:21', '2026-08-16 11:12:21'),
(41, 3, 'set_game_api_provider_password', 'GameApiProvider', '2', '{\"name\":\"gamevault999\"}', '127.0.0.1', '2026-08-16 11:18:06', '2026-08-16 11:18:06'),
(42, 3, 'updated_game_api_provider', 'GameApiProvider', '2', '{\"fields\":[\"name\",\"display_name\",\"protocol\",\"base_url\",\"agent_username\",\"secret_name\",\"is_active\",\"automate_create_account\",\"automate_deposit\",\"automate_withdraw\",\"notes\",\"request_content_type\",\"request_method\",\"custom_headers\",\"proxy_url\",\"requires_ip_whitelist\",\"health_check_path\",\"whitelist_ip_note\",\"docs_url\"]}', '127.0.0.1', '2026-08-16 11:18:24', '2026-08-16 11:18:24'),
(43, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-08-16 11:29:04', '2026-08-16 11:29:04'),
(44, 3, 'created_game_api_provider', 'GameApiProvider', '3', '{\"name\":\"juwa\",\"protocol\":\"agent_login\"}', '127.0.0.1', '2026-08-18 11:08:26', '2026-08-18 11:08:26'),
(45, 3, 'set_game_api_provider_password', 'GameApiProvider', '3', '{\"name\":\"juwa\"}', '127.0.0.1', '2026-08-18 11:08:47', '2026-08-18 11:08:47'),
(46, 3, 'toggled_game_api_provider_is_active', 'GameApiProvider', '3', '{\"name\":\"juwa\",\"value\":true}', '127.0.0.1', '2026-08-18 11:09:11', '2026-08-18 11:09:11'),
(47, 3, 'toggled_game_api_provider_is_active', 'GameApiProvider', '3', '{\"name\":\"juwa\",\"value\":true}', '127.0.0.1', '2026-08-18 11:09:12', '2026-08-18 11:09:12'),
(48, 3, 'toggled_game_api_provider_automate_create_account', 'GameApiProvider', '3', '{\"name\":\"juwa\",\"value\":true}', '127.0.0.1', '2026-08-18 11:10:30', '2026-08-18 11:10:30'),
(49, 3, 'updated_game_api_provider', 'GameApiProvider', '3', '{\"fields\":[\"name\",\"display_name\",\"protocol\",\"base_url\",\"agent_username\",\"secret_name\",\"is_active\",\"automate_create_account\",\"automate_deposit\",\"automate_withdraw\",\"notes\",\"request_content_type\",\"request_method\",\"custom_headers\",\"proxy_url\",\"requires_ip_whitelist\",\"health_check_path\",\"whitelist_ip_note\",\"docs_url\"]}', '127.0.0.1', '2026-08-18 11:16:22', '2026-08-18 11:16:22'),
(50, 3, 'updated_game_api_provider', 'GameApiProvider', '3', '{\"fields\":[\"name\",\"display_name\",\"protocol\",\"base_url\",\"agent_username\",\"secret_name\",\"is_active\",\"automate_create_account\",\"automate_deposit\",\"automate_withdraw\",\"notes\",\"request_content_type\",\"request_method\",\"custom_headers\",\"proxy_url\",\"requires_ip_whitelist\",\"health_check_path\",\"whitelist_ip_note\",\"docs_url\"]}', '127.0.0.1', '2026-08-18 11:17:07', '2026-08-18 11:17:07'),
(51, 3, 'updated_game_api_provider', 'GameApiProvider', '3', '{\"fields\":[\"name\",\"display_name\",\"protocol\",\"base_url\",\"agent_username\",\"secret_name\",\"is_active\",\"automate_create_account\",\"automate_deposit\",\"automate_withdraw\",\"notes\",\"request_content_type\",\"request_method\",\"custom_headers\",\"proxy_url\",\"requires_ip_whitelist\",\"health_check_path\",\"whitelist_ip_note\",\"docs_url\"]}', '127.0.0.1', '2026-08-18 11:23:10', '2026-08-18 11:23:10'),
(52, 3, 'set_game_api_provider_password', 'GameApiProvider', '3', '{\"name\":\"juwa\"}', '127.0.0.1', '2026-08-18 11:23:16', '2026-08-18 11:23:16'),
(53, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-02 11:51:16', '2026-09-02 11:51:16'),
(54, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-02 11:58:32', '2026-09-02 11:58:32'),
(55, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-02 12:13:15', '2026-09-02 12:13:15'),
(56, 3, 'approved_transaction', 'Transaction', '26', '{\"type\":\"deposit\",\"amount\":10,\"note\":null}', '127.0.0.1', '2026-09-02 12:55:37', '2026-09-02 12:55:37'),
(57, 3, 'approved_transaction', 'Transaction', '25', '{\"type\":\"deposit\",\"amount\":4.99,\"note\":null}', '127.0.0.1', '2026-09-02 12:55:59', '2026-09-02 12:55:59'),
(58, 3, 'created_email_template', 'EmailTemplate', '1', '{\"name\":\"Special Promotion\"}', '127.0.0.1', '2026-09-12 08:24:51', '2026-09-12 08:24:51'),
(59, 3, 'created_email_template', 'EmailTemplate', '2', '{\"name\":\"Transaction Notification\"}', '127.0.0.1', '2026-09-12 08:25:13', '2026-09-12 08:25:13'),
(60, 3, 'created_email_template', 'EmailTemplate', '3', '{\"name\":\"asas\"}', '127.0.0.1', '2026-09-12 08:25:39', '2026-09-12 08:25:39'),
(61, 3, 'created_email_template', 'EmailTemplate', '4', '{\"name\":\"Weekly Newsletter\"}', '127.0.0.1', '2026-09-12 08:25:53', '2026-09-12 08:25:53'),
(62, 3, 'deleted_email_template', 'EmailTemplate', '4', '{\"name\":\"Weekly Newsletter\"}', '127.0.0.1', '2026-09-12 08:26:12', '2026-09-12 08:26:12'),
(63, 3, 'deleted_email_template', 'EmailTemplate', '1', '{\"name\":\"Special Promotion\"}', '127.0.0.1', '2026-09-12 08:26:19', '2026-09-12 08:26:19'),
(64, 3, 'deleted_email_template', 'EmailTemplate', '3', '{\"name\":\"asas\"}', '127.0.0.1', '2026-09-12 08:26:27', '2026-09-12 08:26:27'),
(65, 3, 'deleted_email_template', 'EmailTemplate', '2', '{\"name\":\"Transaction Notification\"}', '127.0.0.1', '2026-09-12 08:26:30', '2026-09-12 08:26:30'),
(66, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-14 07:07:18', '2026-09-14 07:07:18'),
(67, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-14 07:07:36', '2026-09-14 07:07:36'),
(68, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-14 07:09:58', '2026-09-14 07:09:58'),
(69, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-16 09:21:28', '2026-09-16 09:21:28'),
(70, 3, 'updated_payment_gateway', 'PaymentGateway', '1', '{\"name\":\"Cash App\"}', '127.0.0.1', '2026-09-16 09:54:48', '2026-09-16 09:54:48'),
(71, 3, 'updated_payment_gateway', 'PaymentGateway', '3', '{\"name\":\"Venmo\"}', '127.0.0.1', '2026-09-16 09:55:58', '2026-09-16 09:55:58'),
(72, 3, 'updated_payment_gateway', 'PaymentGateway', '2', '{\"name\":\"Zelle\"}', '127.0.0.1', '2026-09-16 09:56:13', '2026-09-16 09:56:13'),
(73, 3, 'updated_payment_gateway', 'PaymentGateway', '1', '{\"name\":\"CashApp\"}', '127.0.0.1', '2026-09-16 09:57:25', '2026-09-16 09:57:25'),
(74, 3, 'updated_payment_gateway', 'PaymentGateway', '1', '{\"name\":\"CashApp\"}', '127.0.0.1', '2026-09-16 09:57:50', '2026-09-16 09:57:50'),
(75, 3, 'updated_payment_gateway', 'PaymentGateway', '3', '{\"name\":\"Chime\"}', '127.0.0.1', '2026-09-16 09:58:15', '2026-09-16 09:58:15'),
(76, 3, 'updated_payment_gateway', 'PaymentGateway', '2', '{\"name\":\"Google Pay\"}', '127.0.0.1', '2026-09-16 09:58:33', '2026-09-16 09:58:33'),
(77, 3, 'updated_payment_gateway', 'PaymentGateway', '1', '{\"name\":\"CashApp\"}', '127.0.0.1', '2026-09-16 09:59:08', '2026-09-16 09:59:08'),
(78, 3, 'updated_payment_gateway', 'PaymentGateway', '3', '{\"name\":\"Chime\"}', '127.0.0.1', '2026-09-16 09:59:19', '2026-09-16 09:59:19'),
(79, 3, 'created_payment_gateway', 'PaymentGateway', '4', '{\"name\":\"Paypal\"}', '127.0.0.1', '2026-09-16 09:59:41', '2026-09-16 09:59:41'),
(80, 3, 'created_payment_gateway', 'PaymentGateway', '5', '{\"name\":\"USDC\"}', '127.0.0.1', '2026-09-16 10:00:15', '2026-09-16 10:00:15'),
(81, 3, 'created_payment_gateway', 'PaymentGateway', '6', '{\"name\":\"Zelle\"}', '127.0.0.1', '2026-09-16 10:00:59', '2026-09-16 10:00:59'),
(82, 3, 'updated_payment_gateway', 'PaymentGateway', '1', '{\"name\":\"CashApp\"}', '127.0.0.1', '2026-09-16 10:01:02', '2026-09-16 10:01:02'),
(83, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-16 10:16:49', '2026-09-16 10:16:49'),
(84, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-16 10:17:47', '2026-09-16 10:17:47'),
(85, 3, 'updated_withdraw_method', 'WithdrawMethod', '1', '{\"name\":\"CashApp\"}', '127.0.0.1', '2026-09-16 10:46:38', '2026-09-16 10:46:38'),
(86, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '1', '{\"field_label\":\"Cash App Tag ($Cashtag)\"}', '127.0.0.1', '2026-09-16 10:46:38', '2026-09-16 10:46:38'),
(87, 3, 'updated_withdraw_method', 'WithdrawMethod', '2', '{\"name\":\"Chime\"}', '127.0.0.1', '2026-09-16 10:47:08', '2026-09-16 10:47:08'),
(88, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '2', '{\"field_label\":\"Zelle Email or Phone\"}', '127.0.0.1', '2026-09-16 10:47:08', '2026-09-16 10:47:08'),
(89, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '2', '{\"field_label\":\"Full Account Name\"}', '127.0.0.1', '2026-09-16 10:47:08', '2026-09-16 10:47:08'),
(90, 3, 'updated_withdraw_method', 'WithdrawMethod', '3', '{\"name\":\"USDC\"}', '127.0.0.1', '2026-09-16 10:47:32', '2026-09-16 10:47:32'),
(91, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '3', '{\"field_label\":\"Venmo Handle (@username)\"}', '127.0.0.1', '2026-09-16 10:47:33', '2026-09-16 10:47:33'),
(92, 3, 'created_withdraw_method', 'WithdrawMethod', '4', '{\"name\":\"Zelle\"}', '127.0.0.1', '2026-09-16 10:47:54', '2026-09-16 10:47:54'),
(93, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-17 09:38:17', '2026-09-17 09:38:17'),
(94, 3, 'updated_verification_settings', 'VerificationSetting', '1', '{\"updated_by\":3}', '127.0.0.1', '2026-09-17 09:46:15', '2026-09-17 09:46:15'),
(95, 3, 'updated_payment_gateway', 'PaymentGateway', '1', '{\"name\":\"Apple Pay\"}', '127.0.0.1', '2026-09-17 10:01:43', '2026-09-17 10:01:43'),
(96, 3, 'updated_payment_gateway', 'PaymentGateway', '1', '{\"name\":\"Apple Pay\"}', '127.0.0.1', '2026-09-17 10:01:52', '2026-09-17 10:01:52'),
(97, 3, 'updated_payment_gateway', 'PaymentGateway', '3', '{\"name\":\"CashApp\"}', '127.0.0.1', '2026-09-17 10:02:19', '2026-09-17 10:02:19'),
(98, 3, 'updated_payment_gateway', 'PaymentGateway', '1', '{\"name\":\"Apple Pay\"}', '127.0.0.1', '2026-09-17 10:02:24', '2026-09-17 10:02:24'),
(99, 3, 'updated_payment_gateway', 'PaymentGateway', '2', '{\"name\":\"Chime\"}', '127.0.0.1', '2026-09-17 10:02:54', '2026-09-17 10:02:54'),
(100, 3, 'updated_payment_gateway', 'PaymentGateway', '4', '{\"name\":\"Google Pay\"}', '127.0.0.1', '2026-09-17 10:03:21', '2026-09-17 10:03:21'),
(101, 3, 'updated_payment_gateway', 'PaymentGateway', '5', '{\"name\":\"Paypal\"}', '127.0.0.1', '2026-09-17 10:03:40', '2026-09-17 10:03:40'),
(102, 3, 'updated_payment_gateway', 'PaymentGateway', '6', '{\"name\":\"USDC\"}', '127.0.0.1', '2026-09-17 10:03:59', '2026-09-17 10:03:59'),
(103, 3, 'created_payment_gateway', 'PaymentGateway', '7', '{\"name\":\"Zelle\"}', '127.0.0.1', '2026-09-17 10:04:19', '2026-09-17 10:04:19'),
(104, 3, 'updated_payment_gateway', 'PaymentGateway', '6', '{\"name\":\"USDC\"}', '127.0.0.1', '2026-09-17 10:04:34', '2026-09-17 10:04:34'),
(105, 3, 'updated_payment_gateway', 'PaymentGateway', '5', '{\"name\":\"Paypal\"}', '127.0.0.1', '2026-09-17 10:04:46', '2026-09-17 10:04:46'),
(106, 3, 'updated_payment_gateway', 'PaymentGateway', '4', '{\"name\":\"Google Pay\"}', '127.0.0.1', '2026-09-17 10:04:57', '2026-09-17 10:04:57'),
(107, 3, 'updated_withdraw_method', 'WithdrawMethod', '4', '{\"name\":\"Cashapp\"}', '127.0.0.1', '2026-09-17 10:05:46', '2026-09-17 10:05:46'),
(108, 3, 'updated_withdraw_method', 'WithdrawMethod', '1', '{\"name\":\"Chime\"}', '127.0.0.1', '2026-09-17 10:06:15', '2026-09-17 10:06:15'),
(109, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '1', '{\"field_label\":\"Cash App Tag ($Cashtag)\"}', '127.0.0.1', '2026-09-17 10:06:15', '2026-09-17 10:06:15'),
(110, 3, 'updated_withdraw_method', 'WithdrawMethod', '2', '{\"name\":\"PayPal\"}', '127.0.0.1', '2026-09-17 10:07:04', '2026-09-17 10:07:04'),
(111, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '2', '{\"field_label\":\"Paypal email\"}', '127.0.0.1', '2026-09-17 10:07:04', '2026-09-17 10:07:04'),
(112, 3, 'removed_withdraw_method_field', 'WithdrawMethod', '2', '{\"field_label\":\"Zelle Email or Phone\"}', '127.0.0.1', '2026-09-17 10:07:05', '2026-09-17 10:07:05'),
(113, 3, 'updated_withdraw_method', 'WithdrawMethod', '3', '{\"name\":\"USDC\"}', '127.0.0.1', '2026-09-17 10:07:30', '2026-09-17 10:07:30'),
(114, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '3', '{\"field_label\":\"Wallet Address\"}', '127.0.0.1', '2026-09-17 10:07:30', '2026-09-17 10:07:30'),
(115, 3, 'created_withdraw_method', 'WithdrawMethod', '5', '{\"name\":\"Zelle\"}', '127.0.0.1', '2026-09-17 10:08:12', '2026-09-17 10:08:12'),
(116, 3, 'added_withdraw_method_field', 'WithdrawMethod', '5', '{\"field_label\":\"Emaill Address\"}', '127.0.0.1', '2026-09-17 10:08:13', '2026-09-17 10:08:13'),
(117, 3, 'added_withdraw_method_field', 'WithdrawMethod', '5', '{\"field_label\":\"Number\"}', '127.0.0.1', '2026-09-17 10:08:13', '2026-09-17 10:08:13'),
(118, 3, 'added_withdraw_method_field', 'WithdrawMethod', '5', '{\"field_label\":\"Name of Zelle\"}', '127.0.0.1', '2026-09-17 10:08:13', '2026-09-17 10:08:13'),
(119, 3, 'updated_withdraw_method', 'WithdrawMethod', '1', '{\"name\":\"Chime\"}', '127.0.0.1', '2026-09-17 10:08:51', '2026-09-17 10:08:51'),
(120, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '1', '{\"field_label\":\"Chimetag\\/Tag\"}', '127.0.0.1', '2026-09-17 10:08:52', '2026-09-17 10:08:52'),
(121, 3, 'updated_withdraw_method', 'WithdrawMethod', '5', '{\"name\":\"Zelle\"}', '127.0.0.1', '2026-09-17 10:09:07', '2026-09-17 10:09:07'),
(122, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '5', '{\"field_label\":\"Emaill Address\"}', '127.0.0.1', '2026-09-17 10:09:07', '2026-09-17 10:09:07'),
(123, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '5', '{\"field_label\":\"Number\"}', '127.0.0.1', '2026-09-17 10:09:08', '2026-09-17 10:09:08'),
(124, 3, 'updated_withdraw_method_field', 'WithdrawMethod', '5', '{\"field_label\":\"Name of Zelle\"}', '127.0.0.1', '2026-09-17 10:09:08', '2026-09-17 10:09:08'),
(125, 3, 'updated_withdraw_method', 'WithdrawMethod', '4', '{\"name\":\"Cashapp\"}', '127.0.0.1', '2026-09-17 10:09:30', '2026-09-17 10:09:30'),
(126, 3, 'added_withdraw_method_field', 'WithdrawMethod', '4', '{\"field_label\":\"Cashtag\\/ Tag\"}', '127.0.0.1', '2026-09-17 10:09:30', '2026-09-17 10:09:30');

-- --------------------------------------------------------

--
-- Table structure for table `backups`
--

CREATE TABLE `backups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL,
  `format` varchar(255) NOT NULL,
  `scope` varchar(255) NOT NULL DEFAULT 'manual',
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `size_bytes` bigint(20) UNSIGNED DEFAULT NULL,
  `storage_path` varchar(255) DEFAULT NULL,
  `error` text DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backups`
--

INSERT INTO `backups` (`id`, `type`, `format`, `scope`, `status`, `size_bytes`, `storage_path`, `error`, `meta`, `created_by`, `completed_at`, `expires_at`, `created_at`) VALUES
(1, 'full', 'zip', 'manual', 'success', 112047, 'backups/full/full-manual-20260812-165657.zip', NULL, NULL, 1, '2026-08-12 10:56:57', NULL, '2026-08-12 10:56:57'),
(2, 'full', 'zip', 'manual', 'success', 112160, 'backups/full/full-manual-20260812-165733.zip', NULL, NULL, 3, '2026-08-12 10:57:33', NULL, '2026-08-12 10:57:33');

-- --------------------------------------------------------

--
-- Table structure for table `backup_downloads`
--

CREATE TABLE `backup_downloads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `backup_id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backup_downloads`
--

INSERT INTO `backup_downloads` (`id`, `backup_id`, `admin_id`, `ip`, `created_at`) VALUES
(1, 2, 3, '127.0.0.1', '2026-08-12 10:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('laravel-cache-jwt_blacklist_3a4b7fa2-0ccd-46d6-9875-f1114d7f3484', 'b:1;', 1790180016),
('laravel-cache-jwt_blacklist_3ac737f4-02dc-41b7-a615-cbc3b2de5bda', 'b:1;', 1790178919),
('laravel-cache-jwt_blacklist_6e8d0daa-42ba-483d-8bac-8365897479da', 'b:1;', 1790264423),
('laravel-cache-jwt_blacklist_72a7680f-d1e0-4a80-8d3b-221d2afd61d9', 'b:1;', 1790264256),
('laravel-cache-jwt_blacklist_88f4ba40-6f8e-45c2-9818-2e9cf990c12b', 'b:1;', 1790176999),
('laravel-cache-jwt_blacklist_d4657355-61f3-4598-9fe7-9e451062aff9', 'b:1;', 1790178846);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE `email_templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL DEFAULT 'custom',
  `transaction_type` varchar(255) DEFAULT NULL,
  `trigger_event` varchar(255) NOT NULL DEFAULT 'manual',
  `subject` varchar(255) NOT NULL,
  `body_html` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `export_requests`
--

CREATE TABLE `export_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `manager_id` bigint(20) UNSIGNED NOT NULL,
  `export_type` varchar(255) NOT NULL DEFAULT 'transactions',
  `filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`filters`)),
  `reason` text DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `row_count` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approved_expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fast_payment_api_logs`
--

CREATE TABLE `fast_payment_api_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fast_payment_transaction_id` bigint(20) UNSIGNED DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `provider_reference` varchar(255) DEFAULT NULL,
  `http_status` smallint(5) UNSIGNED DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_payload`)),
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_payload`)),
  `signature_valid` tinyint(1) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fast_payment_transactions`
--

CREATE TABLE `fast_payment_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transaction_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_sn` varchar(255) NOT NULL,
  `fast_transaction_id` varchar(255) DEFAULT NULL,
  `provider` enum('cashapp','applepay','googlepay') NOT NULL,
  `requested_amount` decimal(12,2) NOT NULL,
  `confirmed_amount` decimal(12,2) DEFAULT NULL,
  `payment_status` enum('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
  `pay_url` text DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `raw_response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`raw_response`)),
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `username_suffix` varchar(10) DEFAULT NULL,
  `api_provider` varchar(255) DEFAULT NULL COMMENT 'orion_stars, game_agent, fast_api, river_pay, custom',
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `download_url` varchar(255) DEFAULT NULL,
  `web_url` varchar(255) DEFAULT NULL,
  `android_url` varchar(255) DEFAULT NULL,
  `ios_url` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`id`, `name`, `username_suffix`, `api_provider`, `description`, `image_url`, `download_url`, `web_url`, `android_url`, `ios_url`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Cash Machine', 'CM', NULL, 'Fast-paced reel action with instant multipliers and big jackpots.', 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop', 'https://cashmachine.game', 'https://cashmachine777.com/play', 'https://cashmachine.game/apk', 'https://cashmachine.game/ios', 1, '2026-08-01 12:55:10', '2026-08-08 13:06:26'),
(2, 'Fire Kirin', 'FK', NULL, 'Popular fish hunter game with huge jackpots and bonus rounds.', 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop', 'https://firekirin.xyz', 'https://firekirin.xyz/play', 'https://firekirin.xyz/apk', 'https://firekirin.xyz/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(3, 'Game Room', 'GR', NULL, 'All-in-one arcade gaming hub featuring slots, fish tables, and keno.', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop', 'https://gameroom777.com', 'https://gameroom777.com/play', 'https://gameroom777.com/apk', 'https://gameroom777.com/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(4, 'Game Vault', 'GV', NULL, 'High payouts and exciting bonus multipliers for top players.', 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&auto=format&fit=crop', 'https://gamevault999.com', 'https://gamevault999.com', 'https://gamevault999.com/apk', 'https://gamevault999.com/ios', 1, '2026-08-01 12:55:10', '2026-08-11 12:48:24'),
(5, 'Juwa', 'JW', NULL, 'Classic sweepstakes slots & fish tables with daily rewards.', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop', 'https://juwa777.com', 'https://juwa777.com/web', 'https://juwa777.com/android', 'https://juwa777.com/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(6, 'Milky Way', 'MW', NULL, 'Intergalactic sweepstakes gaming experience with high multipliers.', 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=800&auto=format&fit=crop', 'https://milkywayapp.xyz', 'https://milkywayapp.xyz/play', 'https://milkywayapp.xyz/apk', 'https://milkywayapp.xyz/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(7, 'Orion Star', 'OS', NULL, 'Fast-paced action slots, reel games and interactive fish tables.', 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop', 'https://orionstars.vip', 'https://orionstars.vip/play', 'https://orionstars.vip/apk', 'https://orionstars.vip/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(8, 'Panda Master', 'PM', NULL, 'Vibrant graphics, progressive jackpots, and instant prizes.', 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop', 'https://pandamaster.vip', 'https://pandamaster.vip/web', 'https://pandamaster.vip/apk', 'https://pandamaster.vip/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(9, 'River Sweeps', 'RS', NULL, 'Premier sweepstakes casino games with spinning reels and bonus wins.', 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop', 'https://riversweeps.org', 'https://riversweeps.org/play', 'https://riversweeps.org/apk', 'https://riversweeps.org/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10');

-- --------------------------------------------------------

--
-- Table structure for table `game_accounts`
--

CREATE TABLE `game_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `provider_account_id` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `web_login_url` varchar(255) DEFAULT NULL,
  `status` enum('available','assigned','locked') NOT NULL DEFAULT 'available',
  `assigned_to` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_accounts`
--

INSERT INTO `game_accounts` (`id`, `game_id`, `username`, `provider_account_id`, `password_hash`, `web_login_url`, `status`, `assigned_to`, `created_at`, `updated_at`) VALUES
(38, 1, 'engmdsahCM', NULL, '11223344', 'https://cashmachine777.com/play', 'assigned', 3, '2026-08-27 09:22:32', '2026-09-12 07:44:03'),
(39, 2, 'engmdsahFK', NULL, '1o8OQElDFD', 'https://firekirin.xyz/play', 'assigned', 3, '2026-09-12 07:35:23', '2026-09-12 07:35:23');

-- --------------------------------------------------------

--
-- Table structure for table `game_api_logs`
--

CREATE TABLE `game_api_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `provider_id` bigint(20) UNSIGNED DEFAULT NULL,
  `provider_name` varchar(255) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `provider_reference` varchar(255) DEFAULT NULL,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_payload`)),
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_payload`)),
  `http_status` int(11) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `related_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `related_transaction_id` bigint(20) UNSIGNED DEFAULT NULL,
  `related_request_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_api_logs`
--

INSERT INTO `game_api_logs` (`id`, `provider_id`, `provider_name`, `action`, `endpoint`, `provider_reference`, `request_payload`, `response_payload`, `http_status`, `success`, `error_message`, `duration_ms`, `related_user_id`, `related_transaction_id`, `related_request_id`, `created_at`) VALUES
(1, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":430,\"message\":\"Username or password error\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Username or password error). Retried 8 times with multipart and urlencoded encodings.', 23362, NULL, NULL, NULL, '2026-08-10 11:54:26'),
(2, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":430,\"message\":\"Username or password error\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Username or password error). Retried 8 times with multipart and urlencoded encodings.', 22919, NULL, NULL, NULL, '2026-08-10 11:54:49'),
(3, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20358, NULL, NULL, NULL, '2026-08-10 11:55:15'),
(4, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 19623, NULL, NULL, NULL, '2026-08-10 11:55:35'),
(5, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20396, NULL, NULL, NULL, '2026-08-10 12:07:38'),
(6, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20149, NULL, NULL, NULL, '2026-08-10 12:08:00'),
(7, 1, 'gameroom777', 'agent_login', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20465, NULL, NULL, NULL, '2026-08-10 12:21:34'),
(8, 1, 'gameroom777', 'agent_login', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20365, NULL, NULL, NULL, '2026-08-10 12:22:07'),
(9, 1, 'gameroom777', 'agent_login', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 19340, NULL, NULL, NULL, '2026-08-10 12:34:30'),
(10, 1, 'gameroom777', 'agent_login', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 19315, NULL, NULL, NULL, '2026-08-10 12:35:33'),
(11, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":430,\"message\":\"Username or password error\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Username or password error). Retried 8 times with multipart and urlencoded encodings.', 22447, NULL, NULL, NULL, '2026-08-11 10:26:38'),
(12, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":430,\"message\":\"Username or password error\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Username or password error). Retried 8 times with multipart and urlencoded encodings.', 26987, NULL, NULL, NULL, '2026-08-11 10:27:05'),
(13, 2, 'gamevault999', 'test', '/api/agent/login', NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"\"}). Retried 8 times with multipart and urlencoded encodings.', 28237, NULL, NULL, NULL, '2026-08-11 10:35:06'),
(14, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1731, NULL, NULL, NULL, '2026-08-11 10:55:22'),
(15, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1293, NULL, NULL, NULL, '2026-08-11 12:11:43'),
(16, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1084, NULL, NULL, NULL, '2026-08-11 12:16:00'),
(17, 1, 'gameroom777', 'test', NULL, NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":200,\"message\":\"Users login succeeded\",\"data\":{\"userName\":\"teststore22\",\"money\":\"100.00\",\"token\":\"[REDACTED]\",\"expires_time\":1786494248}}', 200, 1, NULL, 3452, NULL, NULL, NULL, '2026-08-11 12:24:09'),
(18, 1, 'gameroom777', 'e2e_create_player', NULL, NULL, '{\"username\":\"TESTGR_msozpmtdae2\",\"nickname\":\"TESTGR_msozpmtdae2\"}', '{\"status_code\":400,\"message\":\"Nickname can only be letters and numbers, and cannot exceed 20 characters\"}', 200, 0, 'Nickname can only be letters and numbers, and cannot exceed 20 characters', 7868, NULL, NULL, NULL, '2026-08-11 12:24:55'),
(19, 1, 'gameroom777', 'e2e_create_player', NULL, NULL, '{\"username\":\"TESTmsozr4ey94ee65\",\"nickname\":\"TESTmsozr4ey94ee65\"}', '{\"status_code\":400,\"message\":\"Username already exists\"}', 200, 0, 'Username already exists', 33242, NULL, NULL, NULL, '2026-08-11 12:26:30'),
(20, 1, 'gameroom777', 'e2e_create_player', NULL, NULL, '{\"username\":\"TESTmsozt937e63b14\",\"nickname\":\"TESTmsozt937e63b14\"}', '{\"status_code\":200,\"message\":\"Insert successful\",\"data\":{\"id\":3172648,\"account\":\"TESTmsozt937e63b14\",\"password\":\"[REDACTED]\",\"balance\":\"0\",\"time\":\"2026-08-11 13:27:44\"}}', 200, 1, NULL, 16037, NULL, NULL, NULL, '2026-08-11 12:27:52'),
(21, 1, 'gameroom777', 'e2e_player_list', NULL, NULL, '{\"username\":\"TESTmsozt937e63b14\"}', '{\"status_code\":200,\"message\":\"Query successful\",\"count\":4,\"data\":[{\"Account\":\"TESTmsozt937e63b14\",\"nickname\":\"TESTmsozt937e63b14\",\"AddDate\":\"2026-08-11 13:27:44\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172648,\"score\":0},{\"Account\":\"TESTmsozr4ey94ee65\",\"nickname\":\"TESTmsozr4ey94ee65\",\"AddDate\":\"2026-08-11 13:26:04\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172644,\"score\":0},{\"Account\":\"unknownGR\",\"nickname\":\"unknownGR\",\"AddDate\":\"2026-06-06 12:46:41\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3054418,\"score\":0},{\"Account\":\"soae2emq2mv95n30bu\",\"nickname\":\"soae2emq2mv95n30bu\",\"AddDate\":\"2026-06-06 12:34:59\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3054400,\"score\":0}]}', 200, 1, NULL, 1067, NULL, NULL, NULL, '2026-08-11 12:27:54'),
(22, 1, 'gameroom777', 'e2e_get_score', NULL, NULL, '{\"id\":3172648}', '{\"status_code\":200,\"message\":\"Query successful\",\"data\":{\"username\":\"TESTmsozt937e63b14\",\"balance\":0,\"is_game\":false}}', 200, 1, NULL, 1177, NULL, NULL, NULL, '2026-08-11 12:27:56'),
(23, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1233, NULL, NULL, NULL, '2026-08-11 12:32:11'),
(24, 1, 'gameroom777', 'test', NULL, NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":200,\"message\":\"Users login succeeded\",\"data\":{\"userName\":\"teststore22\",\"money\":\"100.00\",\"token\":\"[REDACTED]\",\"expires_time\":1786613017}}', 200, 1, NULL, 1512, NULL, NULL, NULL, '2026-08-12 21:23:37'),
(25, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1205, NULL, NULL, NULL, '2026-08-12 23:15:59'),
(26, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1049, NULL, NULL, NULL, '2026-08-12 23:16:09'),
(27, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1043, NULL, NULL, NULL, '2026-08-12 23:17:33'),
(28, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1067, NULL, NULL, NULL, '2026-08-12 23:23:23'),
(29, 1, 'gameroom777', 'test', NULL, NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":200,\"message\":\"Users login succeeded\",\"data\":{\"userName\":\"teststore22\",\"money\":\"100.00\",\"token\":\"[REDACTED]\",\"expires_time\":1786621115}}', 200, 1, NULL, 25528, NULL, NULL, NULL, '2026-08-12 23:38:36'),
(30, 1, 'gameroom777', 'e2e_create_player', NULL, NULL, '{\"username\":\"TESTmsr38nfo9385bd\",\"nickname\":\"TESTmsr38nfo9385bd\"}', '{\"status_code\":200,\"message\":\"Insert successful\",\"data\":{\"id\":3175020,\"account\":\"TESTmsr38nfo9385bd\",\"password\":\"[REDACTED]\",\"balance\":\"0\",\"time\":\"2026-08-13 00:39:13\"}}', 200, 1, NULL, 15115, NULL, NULL, NULL, '2026-08-12 23:39:21'),
(31, 1, 'gameroom777', 'e2e_player_list', NULL, NULL, '{\"username\":\"TESTmsr38nfo9385bd\"}', '{\"status_code\":200,\"message\":\"Query successful\",\"count\":8,\"data\":[{\"Account\":\"TESTmsr38nfo9385bd\",\"nickname\":\"TESTmsr38nfo9385bd\",\"AddDate\":\"2026-08-13 00:39:13\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3175020,\"score\":0},{\"Account\":\"sahadat77\",\"nickname\":\"sahadat77\",\"AddDate\":\"2026-08-11 13:55:41\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172673,\"score\":0},{\"Account\":\"TESTmsp0lv77c6f276\",\"nickname\":\"TESTmsp0lv77c6f276\",\"AddDate\":\"2026-08-11 13:49:57\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172665,\"score\":0},{\"Account\":\"engmdsah11\",\"nickname\":\"engmdsah11\",\"AddDate\":\"2026-08-11 13:48:20\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172663,\"score\":0},{\"Account\":\"TESTmsozt937e63b14\",\"nickname\":\"TESTmsozt937e63b14\",\"AddDate\":\"2026-08-11 13:27:44\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172648,\"score\":0},{\"Account\":\"TESTmsozr4ey94ee65\",\"nickname\":\"TESTmsozr4ey94ee65\",\"AddDate\":\"2026-08-11 13:26:04\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172644,\"score\":0},{\"Account\":\"unknownGR\",\"nickname\":\"unknownGR\",\"AddDate\":\"2026-06-06 12:46:41\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3054418,\"score\":0},{\"Account\":\"soae2emq2mv95n30bu\",\"nickname\":\"soae2emq2mv95n30bu\",\"AddDate\":\"2026-06-06 12:34:59\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3054400,\"score\":0}]}', 200, 1, NULL, 19508, NULL, NULL, NULL, '2026-08-12 23:39:41'),
(32, 1, 'gameroom777', 'e2e_get_score', NULL, NULL, '{\"id\":3175020}', '{\"status_code\":200,\"message\":\"Query successful\",\"data\":{\"username\":\"TESTmsr38nfo9385bd\",\"balance\":0,\"is_game\":false}}', 200, 1, NULL, 1113, NULL, NULL, NULL, '2026-08-12 23:39:44'),
(33, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 3514, NULL, NULL, NULL, '2026-08-16 11:13:46'),
(34, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Mcashier01\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1037, NULL, NULL, NULL, '2026-08-16 11:18:27'),
(35, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 19664, NULL, NULL, NULL, '2026-08-18 11:09:11'),
(36, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 19241, NULL, NULL, NULL, '2026-08-18 11:09:31'),
(37, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 18893, NULL, NULL, NULL, '2026-08-18 11:10:02'),
(38, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 18761, NULL, NULL, NULL, '2026-08-18 11:10:22'),
(39, 1, 'gameroom777', 'test', NULL, NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":200,\"message\":\"Users login succeeded\",\"data\":{\"userName\":\"teststore22\",\"money\":\"100.00\",\"token\":\"[REDACTED]\",\"expires_time\":1787094623}}', 200, 1, NULL, 1440, NULL, NULL, NULL, '2026-08-18 11:10:23'),
(40, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 18666, NULL, NULL, NULL, '2026-08-18 11:10:55'),
(41, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 19063, NULL, NULL, NULL, '2026-08-18 11:11:14'),
(42, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1039, NULL, NULL, NULL, '2026-08-18 11:16:26'),
(43, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1023, NULL, NULL, NULL, '2026-08-18 11:17:01'),
(44, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1021, NULL, NULL, NULL, '2026-08-18 11:17:11'),
(45, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"109961\"}', '{\"code\":5,\"msg\":\"Access ip is not white ip\",\"data\":[],\"count\":0}', 200, 0, 'Access ip is not white ip (code 5)', 1091, NULL, NULL, NULL, '2026-08-18 11:23:21'),
(46, 1, 'gameroom777', 'create_player', NULL, NULL, '{\"username\":\"engmdsahCM\",\"nickname\":\"engmdsahCM\"}', '{\"status_code\":200,\"message\":\"Insert successful\",\"data\":{\"id\":3204129,\"account\":\"engmdsahCM\",\"password\":\"[REDACTED]\",\"balance\":\"0\",\"time\":\"2026-08-27 10:22:24\"}}', 200, 1, NULL, 31657, NULL, NULL, NULL, '2026-08-27 09:22:32'),
(47, 2, 'gamevault999', 'agent_login', NULL, NULL, '{\"agent_username\":\"Mcashier01\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1179, NULL, NULL, NULL, '2026-08-27 09:35:03'),
(48, 2, 'gamevault999', 'agent_login', NULL, NULL, '{\"agent_username\":\"Mcashier01\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1090, NULL, NULL, NULL, '2026-08-27 09:35:57'),
(49, 3, 'juwa', 'agent_login', NULL, NULL, '{\"agent_username\":\"109961\"}', '{\"code\":3,\"msg\":\"Invalid token\",\"data\":[],\"count\":0}', 200, 0, 'Invalid token (code 3)', 1141, NULL, NULL, NULL, '2026-08-27 09:36:06'),
(50, 4, 'orion_stars', 'agent_login', NULL, NULL, '{\"agent_username\":\"Mcashier01\"}', NULL, NULL, 0, 'Orion Stars API error [201]: Session timeout.', 1455, NULL, NULL, NULL, '2026-08-27 09:36:11'),
(51, 6, 'river_pay', 'agent_login', NULL, NULL, '{\"agent_username\":\"river_login\"}', NULL, NULL, 0, 'River Pay API request to [balance] failed: 403 <!DOCTYPE html>\n<html lang=\"en\">\n\n<head>\n	<meta charset=\"utf-8\">\n	<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/bootstrap.min.css\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/bootstrap-responsive.min.css\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/custom.css?v=1.12\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/datepicker/css/datepicker.css\" />\n<style type=\"text/css\">\n/*<![CDATA[*/\nbody {\r\n	background-image: url(\'/images/bg.png\');\r\n}\r\n		\r\n@media print {\r\n	body { padding: 0; margin: 0; background: none; }\r\n	a:link:after, a:visited:after { content: \"\"; }\r\n	.notforprint { display: none; }\r\n	.forprint { display: block; }\r\n	.for-print { display: block !important; }\r\n}\r\n\r\n@media screen {\r\n	.notforprint { display: block; }\r\n	.forprint { display: none; }\r\n}\n/*]]>*/\n</style>\n<script type=\"text/javascript\" src=\"/assets/f347dd98/jquery.min.js\"></script>\n<script type=\"text/javascript\" src=\"/lib/bootstrap/js/bootstrap.min.js\"></script>\n<script type=\"text/javascript\" src=\"/lib/datepicker/js/bootstrap-datepicker.js\"></script>\n<script type=\"text/javascript\" src=\"/js/shortcut.js\"></script>\n<script type=\"text/javascript\" src=\"/js/main.js?v=1.1.83\"></script>\n<script type=\"text/javascript\" src=\"/js/fp.min.js\"></script>\n<script type=\"text/javascript\" src=\"/js/fp-bootstrap.js\"></script>\n<title>Admin panel</title>\n	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n	<link rel=\"stylesheet\" href=\"/css/main.css?v=1.094\"/>\n</head>\n\n<body>\n	<div class=\"notforprint\">\r\n		<style type=\"text/css\">\n    body {\n        padding-top: 80px;\n        padding-bottom: 40px;\n    }\n</style>\n<div class=\"row-fluid\">\n	<div class=\"span6 offset3\">\n		<div class=\"alert alert-error\">\n			<h2>Error 403</h2>\n			<p>Access denied.</p>\n		</div>\n	</div>\n</div>\n<div class=\"row-fluid\">\n    <div class=\"span6 offset3\">\n        <a class=\"btn btn-primary\" href=\"/office/logout\"><i class=\"icon icon-white icon-refresh\"></i> Switch account</a>    </div>\n</div>\n	</div>\r\n	<div id=\"forprint\" class=\"forprint\"></div>\r\n<script type=\"module\" src=\"https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925\" integrity=\"sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==\" data-cf-beacon=\'{\"version\":\"2024.11.0\",\"token\":\"69a66274fbdc40c58dd0607c3fc7f8a1\"}\' crossorigin=\"anonymous\"></script>\n</body>\n\n</html>\n (a business error here can be normal for River Pay — use \"Run Safe Test\" to confirm)', 963, NULL, NULL, NULL, '2026-08-27 09:36:17'),
(52, 5, 'fast_api', 'agent_login', NULL, NULL, '{\"agent_username\":\"agent_account\"}', NULL, NULL, 0, 'cURL error 6: Could not resolve host: api.fastprovider.com (see https://curl.se/libcurl/c/libcurl-errors.html) for https://api.fastprovider.com/fast/agent/login', 1748, NULL, NULL, NULL, '2026-08-27 09:36:24'),
(53, 3, 'juwa', 'agent_login', NULL, NULL, '{\"agent_username\":\"109961\"}', '{\"code\":3,\"msg\":\"Invalid token\",\"data\":[],\"count\":0}', 200, 0, 'Invalid token (code 3)', 1515, NULL, NULL, NULL, '2026-08-28 11:43:20'),
(54, 3, 'juwa', 'agent_login', NULL, NULL, '{\"agent_username\":\"109961\"}', '{\"code\":3,\"msg\":\"Invalid token\",\"data\":[],\"count\":0}', 200, 0, 'Invalid token (code 3)', 1041, NULL, NULL, NULL, '2026-08-28 11:50:29'),
(55, 1, 'gameroom777', 'create_player', NULL, 'engmdsahFK', '{\"username\":\"engmdsahFK\",\"nickname\":\"engmdsahFK\"}', '{\"status_code\":200,\"message\":\"Insert successful\",\"data\":{\"id\":3235087,\"account\":\"engmdsahFK\",\"password\":\"[REDACTED]\",\"balance\":\"0\",\"time\":\"2026-09-12 08:35:12\"}}', 200, 1, NULL, 18924, NULL, NULL, NULL, '2026-09-12 07:35:23');

-- --------------------------------------------------------

--
-- Table structure for table `game_api_providers`
--

CREATE TABLE `game_api_providers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `protocol` varchar(255) NOT NULL DEFAULT 'agent_login',
  `display_name` varchar(255) NOT NULL,
  `base_url` varchar(255) NOT NULL,
  `agent_username` varchar(255) NOT NULL,
  `secret_name` varchar(255) DEFAULT NULL COMMENT 'legacy env-var fallback for agent password',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `automate_create_account` tinyint(1) NOT NULL DEFAULT 0,
  `automate_deposit` tinyint(1) NOT NULL DEFAULT 0,
  `automate_withdraw` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `request_content_type` varchar(255) NOT NULL DEFAULT 'multipart/form-data',
  `request_method` varchar(255) NOT NULL DEFAULT 'POST',
  `custom_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`custom_headers`)),
  `proxy_url` varchar(255) DEFAULT NULL,
  `requires_ip_whitelist` tinyint(1) NOT NULL DEFAULT 0,
  `health_check_path` varchar(255) NOT NULL DEFAULT '/api/agent/login',
  `whitelist_ip_note` text DEFAULT NULL,
  `docs_url` varchar(255) DEFAULT NULL,
  `last_health_status` varchar(255) DEFAULT NULL,
  `last_health_message` text DEFAULT NULL,
  `last_health_latency_ms` int(11) DEFAULT NULL,
  `last_health_checked_at` timestamp NULL DEFAULT NULL,
  `consecutive_failures` int(11) NOT NULL DEFAULT 0,
  `last_success_at` timestamp NULL DEFAULT NULL,
  `last_failure_at` timestamp NULL DEFAULT NULL,
  `last_error_code` varchar(255) DEFAULT NULL,
  `last_error_summary` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_api_providers`
--

INSERT INTO `game_api_providers` (`id`, `name`, `protocol`, `display_name`, `base_url`, `agent_username`, `secret_name`, `is_active`, `automate_create_account`, `automate_deposit`, `automate_withdraw`, `notes`, `request_content_type`, `request_method`, `custom_headers`, `proxy_url`, `requires_ip_whitelist`, `health_check_path`, `whitelist_ip_note`, `docs_url`, `last_health_status`, `last_health_message`, `last_health_latency_ms`, `last_health_checked_at`, `consecutive_failures`, `last_success_at`, `last_failure_at`, `last_error_code`, `last_error_summary`, `created_at`, `updated_at`) VALUES
(1, 'gameroom777', 'agent_login', 'Game Room 777', 'https://agentserver1.gameroom777.com', 'Teststore22', NULL, 1, 1, 0, 0, NULL, 'multipart/form-data', 'POST', NULL, NULL, 0, '/api/agent/login', NULL, NULL, 'connected', 'Provider is responding normally.', NULL, '2026-08-11 12:24:27', 0, '2026-08-11 12:24:27', NULL, NULL, NULL, '2026-08-10 11:51:32', '2026-08-11 12:24:27'),
(2, 'gamevault999', 'external_signed', 'Game Vault 999', 'https://apius.gamevault999.com', 'Mcashier01', NULL, 1, 1, 0, 0, 'Uses the vendor\'s External API protocol (agent_id + timestamp + secret_key HMAC signing — see API-Documentation.pdf), not the Bearer-login style. agent_username here holds the agent_id. Vendor-provided secret_key: set via GAMEVAULT999_SECRET_KEY in .env or the Providers tab. As of last test, the vendor\'s server returned \'Invalid request parameters\' (code 2) — the agent_id likely needs to be the vendor\'s numeric ID rather than \'Megacashier\'; confirm and update before activating.', 'multipart/form-data', 'POST', '[]', NULL, 0, '/api/agent/login', NULL, NULL, 'unstable', 'Invalid request parameters If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 1090, '2026-08-27 09:35:57', 2, NULL, '2026-08-27 09:35:57', '200', 'Invalid request parameters (code 2)', '2026-08-11 10:34:06', '2026-08-27 09:35:57'),
(3, 'juwa', 'external_signed', 'Juwa', 'https://external.juwa777.com', '109961', NULL, 1, 1, 0, 0, NULL, 'multipart/form-data', 'POST', '[]', NULL, 0, '/api/external/agentBalance', NULL, NULL, 'needs_attention', 'Provider rejected the login token immediately after issuing it (code 3). This is usually a temporary provider-side issue and can be retried; if it keeps happening, confirm this server\'s IP is whitelisted with the provider. If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 1041, '2026-08-28 11:50:29', 3, NULL, '2026-08-28 11:50:29', '200', 'Invalid token (code 3)', '2026-08-18 11:08:26', '2026-08-28 11:50:29'),
(4, 'orion_stars', 'orion_stars_signed', 'Orion Stars', 'https://orionstars.vip:8033', 'Mcashier01', NULL, 1, 1, 0, 0, 'Migrated from Site Settings -> API Keys & Secrets -> Orion Stars Terminal API.', 'multipart/form-data', 'POST', NULL, NULL, 0, '/api/agent/login', NULL, NULL, 'unstable', 'Provider did not respond in time. If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 1455, '2026-08-27 09:36:11', 1, NULL, '2026-08-27 09:36:11', '', 'Orion Stars API error [201]: Session timeout.', '2026-08-18 11:59:23', '2026-08-27 09:36:11'),
(5, 'fast_api', 'fast_api_signed', 'Fast API', 'https://api.fastprovider.com', 'agent_account', NULL, 1, 1, 0, 0, 'Migrated from Site Settings -> API Keys & Secrets -> Fast API Integration. Verify with Test Connection before relying on it, then assign it to the game(s) it should serve.', 'multipart/form-data', 'POST', NULL, NULL, 0, '/api/agent/login', NULL, NULL, 'unstable', 'Provider host could not be resolved. Double-check the base URL. If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 1748, '2026-08-27 09:36:24', 1, NULL, '2026-08-27 09:36:24', '', 'cURL error 6: Could not resolve host: api.fastprovider.com (see https://curl.se/libcurl/c/libcurl-errors.html) for https://api.fastprovider.com/fast/agent/login', '2026-08-18 12:54:39', '2026-08-27 09:36:24'),
(6, 'river_pay', 'river_pay_simple', 'River Pay', 'http://river-pay.com', 'river_login', NULL, 1, 1, 0, 0, 'Migrated from Site Settings -> API Keys & Secrets -> River Pay API. River Pay assigns its own account \"code\" on creation (see RiverPaySimpleProtocol) — verify with Run Safe Test, not just Test Connection, before relying on it.', 'multipart/form-data', 'POST', NULL, NULL, 0, '/api/agent/login', NULL, NULL, 'unstable', 'Provider blocked the request. If the provider requires IP whitelisting, confirm the server IP is approved. If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 963, '2026-08-27 09:36:17', 1, NULL, '2026-08-27 09:36:17', '', 'River Pay API request to [balance] failed: 403 <!DOCTYPE html>\n<html lang=\"en\">\n\n<head>\n	<meta charset=\"utf-8\">\n	<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/bootstrap.min.css\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/bootstrap-responsive.min.css\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/custom.css?v=1.12\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/datepicker/css/datepicker.css\" />\n<style type=\"text/css\">\n/*<![CDATA[*/\nbody {\r\n	background-image: url(\'/images/bg.png\');\r\n}\r\n		\r\n@media print {\r\n	body { padding: 0; margin: 0; background: none; }\r\n	a:link:after, a:visited:after { content: \"\"; }\r\n	.notforprint { display: none; }\r\n	.forprint { display: block; }\r\n	.for-print { display: block !important; }\r\n}\r\n\r\n@media screen {\r\n	.notforprint { display: block; }\r\n	.forprint { display: none; }\r\n}\n/*]]>*/\n</style>\n<script type=\"text/javascript\" src=\"/assets/f347dd98/jquery.min.js\"></script>\n<script type=\"text/javascript\" src=\"/lib/bootstrap/js/bootstrap.min.js\"></script>\n<script type=\"text/javascript\" src=\"/lib/datepicker/js/bootstrap-datepicker.js\"></script>\n<script type=\"text/javascript\" src=\"/js/shortcut.js\"></script>\n<script type=\"text/javascript\" src=\"/js/main.js?v=1.1.83\"></script>\n<script type=\"text/javascript\" src=\"/js/fp.min.js\"></script>\n<script type=\"text/javascript\" src=\"/js/fp-bootstrap.js\"></script>\n<title>Admin panel</title>\n	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n	<link rel=\"stylesheet\" href=\"/css/main.css?v=1.094\"/>\n</head>\n\n<body>\n	<div class=\"notforprint\">\r\n		<style type=\"text/css\">\n    body {\n        padding-top: 80px;\n        padding-bottom: 40px;\n    }\n</style>\n<div class=\"row-fluid\">\n	<div class=\"span6 offset3\">\n		<div class=\"alert alert-error\">\n			<h2>Error 403</h2>\n			<p>Access denied.</p>\n		</div>\n	</div>\n</div>\n<div class=\"row-fluid\">\n    <div class=\"span6 offset3\">\n        <a class=\"btn btn-primary\" href=\"/office/logout\"><i class=\"icon icon-white icon-refresh\"></i> Switch account</a>    </div>\n</div>\n	</div>\r\n	<div id=\"forprint\" class=\"forprint\"></div>\r\n<script type=\"module\" src=\"https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925\" integrity=\"sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==\" data-cf-beacon=\'{\"version\":\"2024.11.0\",\"token\":\"69a66274fbdc40c58dd0607c3fc7f8a1\"}\' crossorigin=\"anonymous\"></script>\n</body>\n\n</html>\n (a business error here can be normal for River Pay — use \"Run Safe Test\" to confirm)', '2026-08-18 12:54:39', '2026-08-27 09:36:17');

-- --------------------------------------------------------

--
-- Table structure for table `game_api_provider_secrets`
--

CREATE TABLE `game_api_provider_secrets` (
  `provider_id` bigint(20) UNSIGNED NOT NULL,
  `agent_password` text NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_api_provider_secrets`
--

INSERT INTO `game_api_provider_secrets` (`provider_id`, `agent_password`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'eyJpdiI6Ino2OVEzV3pSckl6SG9IYUlMeUhKTkE9PSIsInZhbHVlIjoieGgxODBRSlU0ZUZ2c21jZUR4V1I4UT09IiwibWFjIjoiYmNmYTBjNTI4NDE3M2JkYzdlZjFhMjRjMjc2M2M2YWUyMzg5ODNiZDU2ZTA0MTUxNTM0NDg4M2E0MTNiNjBhOSIsInRhZyI6IiJ9', 3, '2026-08-10 11:53:35', '2026-08-11 12:24:06'),
(2, 'eyJpdiI6Im1yVWJPOGQ2aVBDQk9RT2hQdEY5Qmc9PSIsInZhbHVlIjoiZ3ZEZXBud2lTS1Rqc3dTM1VlRGdtUT09IiwibWFjIjoiZWVkNmIwOWRmMGE1ZTBkMGRmYTgyZTBjMmRmNTM4ODJkZTY4N2QxNWNjZGZhNTEyNjNhODExNTY1NDEyNzk5OSIsInRhZyI6IiJ9', 3, '2026-08-11 10:34:06', '2026-08-16 11:12:21'),
(3, 'eyJpdiI6ImpPS1lERWlIUXdoUjEzUWxmWENCTmc9PSIsInZhbHVlIjoiaDZXNFVOV2VpZ245YnVJdVhEWE5PS0lubEJFckxLbFBRTFg3Q21UVVhDb3JpZ3B0ais0VTVXRi9nbVBFMFlwZiIsIm1hYyI6IjQxNTY1MGY1MGY2YTkwZjljMWRlNWMyYTk4ODZjMDMxNjUxMWMyMGZlNTU2YmM5ODViYmE4YzAwMDE4ZDdhZGIiLCJ0YWciOiIifQ==', 3, '2026-08-18 11:08:47', '2026-08-18 11:23:16'),
(4, 'eyJpdiI6IldaaEswOXd4NzhiWlRXcTdvUjk5YWc9PSIsInZhbHVlIjoiN0g2L2Qvay9RTU44aXhrNzJteWhxUT09IiwibWFjIjoiZmE1NDg0MTViOTljMDlkODA1OWQ3ZTYwZGQxMTY3Nzc0MDE4YzM0ODQ1NzZlZjc3Y2E4MDVlYWE3YjY1ZTdjYiIsInRhZyI6IiJ9', NULL, '2026-08-18 11:59:23', '2026-08-18 11:59:23'),
(5, 'eyJpdiI6IkRObWtpMzQwenhYeVlLMVp6dkU4cmc9PSIsInZhbHVlIjoiK2FpZFAxT0xJUlRZV0hJWWUrdVhxQT09IiwibWFjIjoiYjEzYWNjNDM4MjA0ODFiODc5OTYzZDYzM2M4Y2I1OTBhZjNiZjIwNzA1MDA2MjYzMmFmZTUxOTY5MjY5MDEyYiIsInRhZyI6IiJ9', NULL, '2026-08-18 12:54:39', '2026-08-18 12:54:39'),
(6, 'eyJpdiI6IjN6R05CemtnV2ZWejBXWWgzSmZRMEE9PSIsInZhbHVlIjoicG44K3kxZDFRbkZ5Sk45NzRUbzZKdz09IiwibWFjIjoiODczNDc0N2MyMDU1OTc0ZTMxZDQ4MTk4ZTI4MTQ3OGQxOTZmYWRkNDBlODBhMzdjZTNhYWE0YmZjOWNlMmFkYyIsInRhZyI6IiJ9', NULL, '2026-08-18 12:54:39', '2026-08-18 12:54:39');

-- --------------------------------------------------------

--
-- Table structure for table `game_provider_assignments`
--

CREATE TABLE `game_provider_assignments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED NOT NULL,
  `provider_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_provider_assignments`
--

INSERT INTO `game_provider_assignments` (`id`, `game_id`, `provider_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2026-08-10 11:59:09', '2026-08-10 11:59:09'),
(2, 2, 1, '2026-08-10 11:59:11', '2026-08-10 11:59:11'),
(3, 3, 1, '2026-08-10 11:59:14', '2026-08-10 11:59:14'),
(4, 4, 2, '2026-08-10 11:59:17', '2026-08-11 10:34:06'),
(5, 5, 1, '2026-08-10 11:59:20', '2026-08-10 11:59:20'),
(6, 9, 1, '2026-08-10 12:15:53', '2026-08-10 12:15:53');

-- --------------------------------------------------------

--
-- Table structure for table `game_unlock_requests`
--

CREATE TABLE `game_unlock_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED NOT NULL,
  `game_account_id` bigint(20) UNSIGNED DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `game_password` varchar(255) DEFAULT NULL,
  `web_login_url` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_note` text DEFAULT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ghl_api_logs`
--

CREATE TABLE `ghl_api_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `provider_reference` varchar(255) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_payload`)),
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_payload`)),
  `http_status` int(11) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manual_verification_requests`
--

CREATE TABLE `manual_verification_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'phone',
  `contact` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `admin_note` text DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_08_01_000002_create_games_table', 1),
(5, '2026_08_01_000003_create_game_accounts_table', 1),
(6, '2026_08_01_000004_create_game_unlock_requests_table', 1),
(7, '2026_08_01_000005_create_payment_gateways_table', 1),
(8, '2026_08_01_000006_create_payment_gateway_accounts_table', 1),
(9, '2026_08_01_000007_create_withdraw_methods_table', 1),
(10, '2026_08_01_000008_create_withdraw_method_fields_table', 1),
(11, '2026_08_01_000009_create_transactions_table', 1),
(12, '2026_08_01_000010_create_transaction_logs_table', 1),
(13, '2026_08_01_000011_create_withdraw_requests_table', 1),
(14, '2026_08_01_000012_create_password_requests_table', 1),
(15, '2026_08_01_000013_create_rewards_config_table', 1),
(16, '2026_08_01_000014_create_reward_history_table', 1),
(17, '2026_08_01_000015_create_notifications_table', 1),
(18, '2026_08_01_000016_create_site_settings_table', 1),
(19, '2026_08_01_000017_create_support_channels_table', 1),
(20, '2026_08_01_000018_create_audit_logs_table', 1),
(21, '2026_08_01_182617_alter_transactions_type_enum_add_transfer', 1),
(22, '2026_08_01_183423_add_proof_url_to_withdraw_requests_table', 1),
(23, '2026_08_02_142009_add_game_account_id_to_game_unlock_requests_table', 2),
(24, '2026_08_02_152832_add_legacy_id_to_users_table', 3),
(25, '2026_08_02_230307_create_otp_verifications_table', 4),
(26, '2026_08_02_170000_add_web_login_url_to_game_tables', 5),
(27, '2026_08_07_000001_create_verification_settings_table', 6),
(28, '2026_08_07_000002_add_api_keys_to_site_settings_table', 7),
(29, '2026_08_07_173016_add_api_provider_to_games_table', 8),
(30, '2026_08_10_230500_create_game_api_providers_table', 9),
(31, '2026_08_10_230501_create_game_api_provider_secrets_table', 9),
(32, '2026_08_10_230502_create_game_provider_assignments_table', 9),
(33, '2026_08_10_230503_create_game_api_logs_table', 9),
(34, '2026_08_11_224200_add_protocol_to_game_api_providers_table', 10),
(35, '2026_08_12_222300_create_backups_table', 11),
(36, '2026_08_12_222301_create_backup_downloads_table', 11),
(37, '2026_08_12_222302_create_recovery_configs_table', 11),
(38, '2026_08_12_232200_create_export_requests_table', 12),
(39, '2026_08_12_233000_add_contact_widget_fields_to_site_settings_table', 13),
(40, '2026_08_13_120000_add_missing_fields_to_verification_settings_table', 14),
(41, '2026_08_13_120100_create_manual_verification_requests_table', 15),
(42, '2026_08_13_130000_create_email_templates_table', 16),
(43, '2026_08_13_140000_add_redeem_limits_to_site_settings_table', 17),
(44, '2026_08_13_150000_add_withdraw_daily_limit_to_site_settings_table', 18),
(45, '2026_08_13_160000_add_gateway_columns_to_transactions_table', 19),
(46, '2026_08_13_170128_add_last_login_at_to_users_table', 20),
(47, '2026_08_27_150234_add_username_suffix_to_games_table', 21),
(48, '2026_08_27_150235_add_provider_account_id_to_game_accounts_table', 21),
(49, '2026_08_27_154752_add_ghl_contact_id_to_users_table', 22),
(50, '2026_08_27_154753_create_ghl_api_logs_table', 22),
(51, '2026_08_27_175307_add_fast_payment_credentials_to_site_settings_table', 23),
(52, '2026_08_27_175308_create_fast_payment_transactions_table', 23),
(53, '2026_08_27_175401_create_fast_payment_api_logs_table', 23),
(54, '2026_08_28_090000_make_action_by_nullable_on_transaction_logs_table', 24),
(55, '2026_08_28_100000_add_instant_recharge_columns_to_transactions_table', 25),
(56, '2026_08_28_110000_add_financial_ledger_columns_to_transactions_table', 26),
(57, '2026_08_28_130000_add_centralized_logging_fields', 27),
(58, '2026_08_29_090000_add_brevo_fields_to_verification_settings_table', 28);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'info',
  `category` varchar(255) NOT NULL DEFAULT 'general',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otp_verifications`
--

CREATE TABLE `otp_verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `channel` enum('email','sms') NOT NULL,
  `destination` varchar(255) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_requests`
--

CREATE TABLE `password_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `game_account_id` bigint(20) UNSIGNED NOT NULL,
  `requested_password` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateways`
--

CREATE TABLE `payment_gateways` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL DEFAULT '',
  `minimum_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `logo_url` varchar(255) DEFAULT NULL,
  `qr_code_url` varchar(255) DEFAULT NULL,
  `deep_link` varchar(255) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_gateways`
--

INSERT INTO `payment_gateways` (`id`, `name`, `address`, `minimum_amount`, `logo_url`, `qr_code_url`, `deep_link`, `instructions`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Apple Pay', 'Please use live chat to deposit', 10.00, '/storage/gateway-qr/Yzz6MByieeZUR9gl8gzF7SN5SAYV4k06zygQ6pRw.png', NULL, NULL, 'Send payment to our Cash App tag. Upload screenshot as deposit proof.', 1, '2026-08-01 12:55:10', '2026-09-17 10:02:24'),
(2, 'Chime', 'Please use live chat to ask ChimeTag', 10.00, '/storage/gateway-qr/zyUsfm8EmqxIsHkEeFrPixlwk97CrtNWuvc5ZSVw.jpg', NULL, NULL, 'Send payment via Zelle to pay@horizon.gg.', 1, '2026-08-01 12:55:11', '2026-09-17 10:02:53'),
(3, 'CashApp', 'Please use live chat to deposit', 10.00, '/storage/gateway-qr/uDbvM5cHy9IAw4ttdoA0yxW8oogd4Pio4sp8a4KS.png', NULL, NULL, 'Send payment via Venmo. Include your username in payment note.', 1, '2026-08-01 12:55:11', '2026-09-17 10:02:19'),
(4, 'Google Pay', 'Please use live chat to deposit', 10.00, '/storage/gateway-qr/WnDJDW0l25ZbSttODoSREZP6BkvA9Sn5dxIQGKWL.png', NULL, NULL, NULL, 1, '2026-09-16 09:59:41', '2026-09-17 10:04:57'),
(5, 'Paypal', 'kaziagencygroup@gmail.com', 10.00, '/storage/gateway-qr/KfgdHqm8KF0pto208OEBallQkF3VZJOeuqecXHRH.png', NULL, NULL, NULL, 1, '2026-09-16 10:00:15', '2026-09-17 10:04:46'),
(6, 'USDC', '0x962e6F6D3edD1b1f7C49ECb8e94d5ED3cbB324C4', 10.00, '/storage/gateway-qr/50dxThbGy4pJj62z8j6ms0GVEHwFulgLy89Zwu1l.png', NULL, NULL, NULL, 1, '2026-09-16 10:00:59', '2026-09-17 10:04:34'),
(7, 'Zelle', 'Adarsh.kazi87@gmail.com', 10.00, '/storage/gateway-qr/7s4em1wxHyVX9eEtlpoV0CNzY7EDzEizrj16eA4p.jpg', NULL, NULL, NULL, 1, '2026-09-17 10:04:19', '2026-09-17 10:04:19');

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateway_accounts`
--

CREATE TABLE `payment_gateway_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` bigint(20) UNSIGNED NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `priority_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `qr_code_url` varchar(255) DEFAULT NULL,
  `deep_link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_gateway_accounts`
--

INSERT INTO `payment_gateway_accounts` (`id`, `gateway_id`, `account_name`, `account_number`, `priority_order`, `is_active`, `qr_code_url`, `deep_link`, `created_at`, `updated_at`) VALUES
(1, 1, 'Cash App Official Account', '$HorizonPay', 1, 1, NULL, NULL, '2026-08-01 12:55:11', '2026-08-01 12:55:11'),
(2, 2, 'Zelle Official Account', 'pay@horizon.gg', 1, 1, NULL, NULL, '2026-08-01 12:55:11', '2026-08-01 12:55:11'),
(3, 3, 'Venmo Official Account', '@HorizonPay', 1, 1, NULL, NULL, '2026-08-01 12:55:11', '2026-08-01 12:55:11');

-- --------------------------------------------------------

--
-- Table structure for table `recovery_configs`
--

CREATE TABLE `recovery_configs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_url` varchar(255) DEFAULT NULL,
  `frontend_url` varchar(255) DEFAULT NULL,
  `support_email` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recovery_configs`
--

INSERT INTO `recovery_configs` (`id`, `site_url`, `frontend_url`, `support_email`, `notes`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, '2026-08-12 10:57:23', '2026-08-12 10:57:23');

-- --------------------------------------------------------

--
-- Table structure for table `rewards_config`
--

CREATE TABLE `rewards_config` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` decimal(12,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rewards_config`
--

INSERT INTO `rewards_config` (`id`, `key`, `value`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'welcome_bonus', 10.00, 'Free $10 sign up bonus for new players', 1, '2026-08-01 12:55:11', '2026-08-01 12:55:11'),
(2, 'daily_checkin', 5.00, 'Daily $5 free play login reward', 1, '2026-08-01 12:55:11', '2026-08-01 12:55:11'),
(3, 'referral_reward', 15.00, 'Refer a friend and get $15 bonus credit', 1, '2026-08-01 12:55:11', '2026-08-01 12:55:11');

-- --------------------------------------------------------

--
-- Table structure for table `reward_history`
--

CREATE TABLE `reward_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `reward_key` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE `site_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_name` varchar(255) NOT NULL DEFAULT 'Horizon Players',
  `logo_url` varchar(255) DEFAULT NULL,
  `favicon_url` varchar(255) DEFAULT NULL,
  `custom_css` text DEFAULT NULL,
  `colors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`colors`)),
  `fonts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fonts`)),
  `nav_links` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`nav_links`)),
  `landing_page_config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`landing_page_config`)),
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `seo_keywords` varchar(255) DEFAULT NULL,
  `header_scripts` text DEFAULT NULL,
  `body_scripts` text DEFAULT NULL,
  `footer_scripts` text DEFAULT NULL,
  `whatsapp_number` varchar(255) DEFAULT NULL,
  `telegram_link` varchar(255) DEFAULT NULL,
  `messenger_link` varchar(255) DEFAULT NULL,
  `ghl_api_key` varchar(255) DEFAULT NULL,
  `ghl_location_id` varchar(255) DEFAULT NULL,
  `ghl_assigned_user_id` varchar(255) DEFAULT NULL,
  `ghl_conversation_mode` varchar(255) NOT NULL DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `game_agent_base_url` varchar(255) DEFAULT NULL,
  `game_agent_id` varchar(255) DEFAULT NULL,
  `game_agent_secret_key` text DEFAULT NULL,
  `orion_stars_base_url` varchar(255) DEFAULT NULL,
  `orion_stars_agent_name` varchar(255) DEFAULT NULL,
  `orion_stars_agent_password` text DEFAULT NULL,
  `fast_api_base_url` varchar(255) DEFAULT NULL,
  `fast_api_app_id` varchar(255) DEFAULT NULL,
  `fast_api_app_secret` text DEFAULT NULL,
  `fast_api_agent_account` varchar(255) DEFAULT NULL,
  `fast_api_agent_password` text DEFAULT NULL,
  `river_pay_base_url` varchar(255) DEFAULT NULL,
  `river_pay_login` varchar(255) DEFAULT NULL,
  `river_pay_password` text DEFAULT NULL,
  `fast_payment_base_url` varchar(255) DEFAULT NULL,
  `fast_payment_merchant_id` varchar(255) DEFAULT NULL,
  `fast_payment_key` text DEFAULT NULL,
  `contact_display_mode` varchar(255) DEFAULT NULL,
  `contact_button_label` varchar(255) DEFAULT NULL,
  `contact_header_title` varchar(255) DEFAULT NULL,
  `contact_widget_position` varchar(255) DEFAULT NULL,
  `contact_button_color` varchar(255) DEFAULT NULL,
  `contact_text_color` varchar(255) DEFAULT NULL,
  `redeem_min_amount` decimal(10,2) DEFAULT NULL,
  `redeem_max_amount` decimal(10,2) DEFAULT NULL,
  `withdraw_daily_limit` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `site_name`, `logo_url`, `favicon_url`, `custom_css`, `colors`, `fonts`, `nav_links`, `landing_page_config`, `seo_title`, `seo_description`, `seo_keywords`, `header_scripts`, `body_scripts`, `footer_scripts`, `whatsapp_number`, `telegram_link`, `messenger_link`, `ghl_api_key`, `ghl_location_id`, `ghl_assigned_user_id`, `ghl_conversation_mode`, `created_at`, `updated_at`, `game_agent_base_url`, `game_agent_id`, `game_agent_secret_key`, `orion_stars_base_url`, `orion_stars_agent_name`, `orion_stars_agent_password`, `fast_api_base_url`, `fast_api_app_id`, `fast_api_app_secret`, `fast_api_agent_account`, `fast_api_agent_password`, `river_pay_base_url`, `river_pay_login`, `river_pay_password`, `fast_payment_base_url`, `fast_payment_merchant_id`, `fast_payment_key`, `contact_display_mode`, `contact_button_label`, `contact_header_title`, `contact_widget_position`, `contact_button_color`, `contact_text_color`, `redeem_min_amount`, `redeem_max_amount`, `withdraw_daily_limit`) VALUES
(1, 'Horizon Players', '/storage/brand-assets/3Mimeg6Q0ZfS4O0DXKE39f0NOSTUBEuEvJEQic7y.jpg', '/storage/brand-assets/1mznBNjzMUKd7VSMtFOs1rzPMQRbcIWshHSSdjbW.jpg', NULL, '{\"primary\":\"43 72% 52%\",\"primary-foreground\":\"0 0% 0%\",\"secondary\":\"45 85% 62%\",\"background\":\"0 0% 4%\",\"foreground\":\"0 0% 100%\",\"card\":\"0 0% 9%\",\"muted\":\"217 33% 17%\",\"muted-foreground\":\"226 40% 65%\",\"border\":\"216 20% 20%\",\"input\":\"216 20% 20%\",\"popover\":\"222 46% 11%\"}', '{\"primary\":null,\"secondary\":null,\"button\":null}', NULL, '{\"hero\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"badge_text\":\"#1 Trusted Gaming Platform\",\"title_line1\":\"YOUR WINNING\",\"title_highlight\":\"JOURNEY\",\"title_line2\":\"STARTS HERE\",\"subtitle\":\"Sweepstakes, fish games, slots & more \\u2014 all in one place. Register now and start winning today.\",\"trust_items\":[{\"label\":\"Secure & Encrypted\"},{\"label\":\"Fast Approval\"},{\"label\":\"Reliable System\"}]},\"stats_banner\":{\"background_type\":\"color\",\"background_color\":\"#09090b\",\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"stats\":[{\"value\":\"10K+\",\"label\":\"Active Players\"},{\"value\":\"24\\/7\",\"label\":\"Live Support\"},{\"value\":\"$1M+\",\"label\":\"Total Payouts\"},{\"value\":\"50+\",\"label\":\"Games Available\"}]},\"games_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"title\":\"OUR GAMES\",\"subtitle\":\"Discover the best online gaming experience - play top industry games in one place.\\nWhich game you wanna play today?\"},\"transfers_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"badge_text\":\"Lightning Fast\",\"title_line1\":\"INSTANT FUND\",\"title_highlight\":\"TRANSFERS\",\"subtitle\":\"Deposit, Transfer, Redeem or Withdraw your funds instantly. No delays, no hassle \\u2014 your money moves when you want it to.\",\"cta_text\":\"Get Started Free\",\"feature_image_url\":null,\"actions\":[\"Deposit\",\"Withdraw\",\"Transfer\",\"Redeem\"]},\"features_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"title\":\"WHY GAME WITH US?\",\"subtitle\":\"The reasons players trust us\",\"features\":[{\"title\":\"Live 24\\/7 Support\",\"desc\":\"Our dedicated team is always online to solve problems instantly.\",\"image_url\":null},{\"title\":\"Unlimited & Instant Withdrawals\",\"desc\":\"Fast withdrawals to fulfill your needs.\",\"image_url\":null},{\"title\":\"Constant Community Bonuses\",\"desc\":\"Get rewarded with free credits and exclusive promotions.\",\"image_url\":null},{\"title\":\"All Games in One Account\",\"desc\":\"Play all of your favorite games under one account.\",\"image_url\":null}]},\"testimonials_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"title\":\"WHAT PLAYERS SAY\",\"subtitle\":\"Join thousands of satisfied gamers\",\"image_url\":null,\"testimonials\":[{\"name\":\"Alex M.\",\"quote\":\"Best gaming platform I\'ve ever used! Fast payouts and amazing support.\",\"avatar_url\":null},{\"name\":\"Sarah K.\",\"quote\":\"The variety of games is incredible. I play every day!\",\"avatar_url\":null},{\"name\":\"Mike R.\",\"quote\":\"Deposits and withdrawals are instant. Highly recommended!\",\"avatar_url\":null}]},\"faq_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"title\":\"FREQUENTLY ASKED QUESTIONS\",\"subtitle\":\"Everything you need to know before getting started\",\"faqs\":[{\"question\":\"How do I create an account?\",\"answer\":\"Simply click the Register button and fill in your details. It only takes a minute to get started!\"},{\"question\":\"How long do deposits and withdrawals take?\",\"answer\":\"Deposits are instant, and withdrawals are processed within minutes. No long waits!\"},{\"question\":\"Is my personal information secure?\",\"answer\":\"Absolutely. We use industry-standard encryption to protect all your data and transactions.\"},{\"question\":\"Can I play on mobile?\",\"answer\":\"Yes! Our platform works on all devices \\u2014 desktop, tablet, and mobile browsers.\"},{\"question\":\"How do I contact support?\",\"answer\":\"Our 24\\/7 support team is always available. Use the live chat or reach out via email anytime.\"}]},\"cta_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"pre_title\":\"Don\'t Miss Out\",\"title\":\"REGISTER NOW & START PLAYING YOUR FAVORITE GAMES\",\"button_text\":\"Register Now \\u2014 It\'s Free\",\"image_url\":null},\"footer\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"show_games\":true,\"copyright_text\":\"iGameplayers Copyright @2022\",\"extra_payment_methods\":[]},\"navbar\":{\"links\":[{\"label\":\"Games\",\"href\":\"#games\"},{\"label\":\"Features\",\"href\":\"#features\"},{\"label\":\"Transfers\",\"href\":\"#transfers\"}]}}', 'Horizon Players - #1 Trusted Gaming Platform', 'Sweepstakes, fish games, slots & more — all in one place. Register now and start winning today.', NULL, NULL, NULL, NULL, '+1234567890', 'https://t.me/horizon_support', 'https://m.me/horizon', 'pit-594b52be-213f-456f-a8c6-c7aef2a37ffb', 'T1QNjGrUssAlvTaHbjiH', 'usr_12345', 'manual', '2026-08-01 12:55:11', '2026-09-17 10:17:35', 'https://agent.gameprovider.com', '10045', 'secret_key_12345', 'https://orionstars.vip:8033', 'Mcashier01', 'Fireron2026#$', 'https://api.fastprovider.com', 'app_123456', 'app_secret_123456', 'agent_account', 'agent_password', 'http://river-pay.com', 'river_login', 'river_password', 'https://mh.dollarpaywallet.com', '1092768610', 'c38a302a69b588ea113bc28b31e36ed1', NULL, 'More', NULL, 'bottom-right', NULL, NULL, 40.00, 300.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `support_channels`
--

CREATE TABLE `support_channels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'message-square',
  `link` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `support_channels`
--

INSERT INTO `support_channels` (`id`, `name`, `icon`, `link`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Messenger', 'messenger', 'https://m.me/602916016243577', 1, 1, '2026-08-01 12:55:11', '2026-08-12 12:06:01'),
(2, 'Telegram', 'telegram', 'https://t.me/username', 2, 1, '2026-08-01 12:55:11', '2026-08-12 12:05:19'),
(3, 'Whatsapp', 'whatsapp', 'https://wa.me/1234567890', 3, 1, '2026-08-01 12:55:11', '2026-08-12 12:04:40');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gateway_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gateway_account_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` enum('deposit','withdraw','redeem','transfer','reward') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `deposit_proof_url` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `balance_reserved` tinyint(1) NOT NULL DEFAULT 0,
  `idempotency_key` varchar(255) DEFAULT NULL,
  `provider_reference` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `balance_before` decimal(12,2) DEFAULT NULL,
  `balance_after` decimal(12,2) DEFAULT NULL,
  `failure_reason` text DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_logs`
--

CREATE TABLE `transaction_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transaction_id` bigint(20) UNSIGNED NOT NULL,
  `action` varchar(255) NOT NULL,
  `action_by` bigint(20) UNSIGNED DEFAULT NULL,
  `old_status` varchar(255) DEFAULT NULL,
  `new_status` varchar(255) DEFAULT NULL,
  `old_amount` decimal(12,2) DEFAULT NULL,
  `new_amount` decimal(12,2) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `action_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `legacy_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `ghl_contact_id` varchar(255) DEFAULT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `role` enum('user','manager','admin') NOT NULL DEFAULT 'user',
  `is_flagged` tinyint(1) NOT NULL DEFAULT 0,
  `flagged_reason` text DEFAULT NULL,
  `flagged_at` timestamp NULL DEFAULT NULL,
  `email_verified_by_admin` tinyint(1) NOT NULL DEFAULT 0,
  `phone_verified` tinyint(1) NOT NULL DEFAULT 0,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `legacy_id`, `name`, `username`, `email`, `phone`, `avatar_url`, `ghl_contact_id`, `balance`, `role`, `is_flagged`, `flagged_reason`, `flagged_at`, `email_verified_by_admin`, `phone_verified`, `phone_verified_at`, `country`, `state`, `gender`, `date_of_birth`, `email_notifications`, `email_verified_at`, `last_login_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Admin Manager', 'admin', 'admin@horizon.gg', NULL, NULL, NULL, 5000.00, 'admin', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-08-01 12:55:10', '2026-09-16 11:16:18', '$2y$12$yaeuLomj7DpYGc0zITjfwOmXOTyLXgBe2r0WBBgjmoQkKG7OudzeS', NULL, '2026-08-01 12:55:10', '2026-09-16 11:16:18'),
(2, NULL, 'engmdsah', 'engmdsah', 'eng.md.sahadathossain@gmail.com', '+8801640638628', NULL, NULL, 374.99, 'admin', 0, NULL, NULL, 0, 1, '2026-08-07 04:57:27', NULL, NULL, NULL, NULL, 1, '2026-08-07 04:38:31', '2026-09-17 09:40:23', '$2y$12$30wLBY3RT4cPQiuio2KiDOprVzXrK3yfW/sJvjQ1R6g7g4uyfLdbi', NULL, '2026-08-01 13:04:12', '2026-09-17 09:40:23'),
(3, NULL, 'engmdsah52', 'engmdsah52', 'www.morad5227@gmail.com', NULL, NULL, NULL, 200.00, 'admin', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$xrIN5EHcfHsVz/Jm4h8Iee905v.okDDHNTJtPiwfxNUr0zHOFyw7W', NULL, '2026-08-02 11:14:25', '2026-08-12 23:55:40'),
(4, 'b84895fd-c3ca-445e-80fc-4d7816eb7f91', 'developerkazi', 'developerkazi', 'developer@kaziagency.com', '+8801878725658', NULL, NULL, 4295.00, 'manager', 0, NULL, NULL, 1, 1, '2026-04-03 01:42:15', NULL, NULL, NULL, NULL, 1, '2026-04-03 01:42:15', NULL, '$2y$10$OrWstjlapvOWCkKFW.fvme1Mlw3/DVBP4F.8CTZkRP06sL/JOgwA6', NULL, '2026-04-03 01:42:15', '2026-09-17 11:17:55'),
(5, '928e2379-2fa6-4c6f-91b9-49607b46e124', 'gamepaneluser003', 'gamepaneluser003', 'testwidget@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$r7THmSpRv2SbpytAVXU9a.cLCzswlfY/zsQQ.2M.5cq0V6suRI6WS', NULL, '2026-04-02 15:36:17', '2026-09-17 11:17:55'),
(6, '930c8bdb-8012-4240-b9c4-0b7476c3e5d6', 'Funguy7788', 'Funguy7788', 'gstoner773@gmail.com', '+17179806485', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-07 13:00:32', NULL, '$2y$10$iWEgLQTv.pL7m4jJgrG1vuc/A3XUBlC7sEF3pBL93tOCycd0ll55O', NULL, '2026-04-07 13:00:32', '2026-09-17 11:17:55'),
(7, '0ef29576-f733-4818-beb4-87185c140c53', 'gamepaneluser008', 'gamepaneluser008', 'shyminor183@gmail.com', '12052170085', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-04 01:07:22', NULL, '$2y$10$V5Pb.zUSHqX6jFaryAjS8.thZjsm5JBI4PduTlz7Q/.ESdN7d4Cp6', NULL, '2026-04-04 01:07:22', '2026-09-17 11:17:55'),
(8, '9216ad06-91d0-4142-8dc6-43dbaa2d6dfb', 'Slimthang2', 'Slimthang2', 'rosababe503@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6n5CxxxTkbP.6brvhZRWz.SuTxmHc0gsXlUDon7mLFjlez63eYFaC', NULL, '2026-06-04 21:53:57', '2026-09-17 11:17:55'),
(9, '6ce4eede-8a82-400b-870c-13180d073b99', 'hridooyadmin', 'hridooyadmin', 'hridooysaha@gmail.com', '+8801878725658', NULL, NULL, 1400.00, 'admin', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-31 15:48:47', NULL, '$2y$10$acx6X/5/m9YaOpldoPrdvO5WQLEXK4iDa2Be//Wy.CxruUBbrNMZy', NULL, '2026-03-31 15:48:47', '2026-09-17 11:17:55'),
(10, '8624a61e-f89a-4c3d-abeb-54836c0dc43e', 'gamepaneluser009', 'gamepaneluser009', '9876tag@gmail.com', '+16208051852', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-05 03:16:09', NULL, '$2y$10$Qv75IdoOwwUCbM4VRc4RX.MTBUSkKn7NvBPOhArsZsqdH/2PXoinK', NULL, '2026-04-05 03:16:09', '2026-09-17 11:17:55'),
(11, 'bae3c557-beee-4706-ae28-56d192a75640', 'gamepaneluser010', 'gamepaneluser010', 'kalamanna6inch@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$K5bjenxScMcQih3Racf3tOXPlSqd./9LIUOqvv.82h1ibOvv0hgOq', NULL, '2026-04-05 14:47:45', '2026-09-17 11:17:55'),
(12, '7fa4d38d-b8cf-4e22-91aa-03522d98b383', 'testuser1', 'testuser1', 'testdupeuser@test.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$h0xskS6HaGLGAtmjx1sEFuHUWkhrT7v2iwsTPBir60rZC3TJRVJeC', NULL, '2026-04-06 00:25:46', '2026-09-17 11:17:55'),
(13, 'd602ea6a-d5b7-4d58-81d7-41046a9fe355', 'TestPlayer', 'TestPlayer', 'testfk_user@test.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$aYRhzs9eyr8aJ5xwW9Ujw.8FSfk/58UrmQ5b/.kuPjGa5xZa6bbt.', NULL, '2026-04-06 00:50:23', '2026-09-17 11:17:55'),
(14, '59285906-8922-4474-a485-4c3ba492db5c', 'Keen Rogers', 'gamepaneluser004', 'keanalbion@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-03 00:36:21', 'United States', NULL, 'Male', NULL, 1, '2026-04-03 00:36:21', NULL, '$2y$10$LikBnAdmMMGCn5e6eRYdzuYyrdhXNuBIJqWec1yhlQ0ZLZLjtO8K6', NULL, '2026-04-03 00:36:21', '2026-09-17 11:17:55'),
(15, '2b31d25d-772b-4b9b-9300-3a82517fb1d1', 'gamepaneluser006', 'gamepaneluser006', 'tesiornajerome@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-03 11:38:33', NULL, '$2y$10$7XWpoJtlO0R5QZuieCtsXe9w9ueq5U1V3x9u.VpGCSumbA5z.tegu', NULL, '2026-04-03 11:38:33', '2026-09-17 11:17:55'),
(16, '6634769c-d115-4c49-9eed-e807754e7a01', 'Stina0708', 'Stina0708', 'stevenwillis1612@gmail.com', '+12564343710', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-07 14:58:24', NULL, NULL, NULL, NULL, 1, '2026-04-07 14:58:24', NULL, '$2y$10$Q4NMWpv2nlQRZPygE98cGOPjrcqOCUkAof1zN7kGH4OebcRZLxo02', NULL, '2026-04-07 14:58:24', '2026-09-17 11:17:55'),
(17, 'b14c1f31-5944-426c-9f85-23c6c9350631', 'Victoria Elizondo', 'Vicky0221', 'velizondo0221@gmail.com', '+12107692472', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/b14c1f31-5944-426c-9f85-23c6c9350631/avatar.jpg?t=1775566242715', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-07 06:43:38', 'United States', 'Texas', 'Female', '1990-02-21', 1, '2026-04-07 06:43:38', NULL, '$2y$10$tHIBFVH1awglgwdRH544Ye7upVxvSMVJnhbGKsYS2KKKJJtBaIjmS', NULL, '2026-04-07 06:43:38', '2026-09-17 11:17:55'),
(18, '8064aca8-2f0f-47ae-ab66-73540d7b6d24', 'Angee1100', 'Angee1100', 'welsha747@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-07 09:24:42', NULL, '$2y$10$LUoOOgcMxlQ3iwZXkInMje0AYnsTWtIumvzopzv9Ku1M6sH9n4ujO', NULL, '2026-04-07 09:24:42', '2026-09-17 11:17:55'),
(19, 'b910e1f5-fb5c-4570-800c-d9b2fac54da0', 'contacthri', 'contacthri', 'contact.hridayshaha@gmail.com', NULL, NULL, NULL, 1392.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-06 01:59:39', NULL, '$2y$10$uKe3/HBjThvj4sLIgsg3d.gjWzLTS3fomP3R32lK9uFv/jPltcqWe', NULL, '2026-04-06 01:59:39', '2026-09-17 11:17:55'),
(20, '615e046f-0d61-4c4c-8dd0-1baea930232d', 'johnytest', 'johnytest', 'hotmail@fvainboxes.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xWrwyemY2IDpILbM1BLmh.8UtAiupOo7WKBgrkvM8vx4dnufzAvAq', NULL, '2026-04-06 06:54:29', '2026-09-17 11:17:55'),
(21, '6c8f3bfc-7505-4b85-8c99-5b4fe2f4116c', 'phodhai115', 'phodhai115', 'colleenschmelernihil1987yta@hotmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$z71L4kausQ/hfNA/CM6eVOMHG1czSB3Ao23srDkO9A/rbUtDnoKkq', NULL, '2026-04-06 07:16:51', '2026-09-17 11:17:55'),
(22, 'a34122e1-92d7-4466-b06f-1048a9a34719', 'Christopher Hamaker', 'gamepaneluser007', 'hamakershammer@gmail.com', '+1-423-354-8449', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-03 16:01:41', 'United States', 'Arkansas', 'Male', '1995-04-20', 1, '2026-04-03 16:01:41', NULL, '$2y$10$O0rIqFNsigsGl98oFml3gO1shuErfgn7m09JEEeM.SM50jhFHcrqG', NULL, '2026-04-03 16:01:41', '2026-09-17 11:17:55'),
(23, '9e6dcf9a-20f3-4fa8-a66e-c5b71f2fc840', 'mraldo', 'mraldo', 'mr.aldomitch@gmail.com', '+12175002355', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$gea6HNLKJIhXKm29a3BDWOpdVjvSLiHCgCJPXh248GGBLrnFA9yvy', NULL, '2026-04-07 04:45:49', '2026-09-17 11:17:55'),
(24, '78e351ae-3160-4b24-a468-b09f9728933a', 'Wonderboy5', 'Wonderboy5', 'refinishing55@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2sglJzX/IUjofWbqoAWQ4.qbpgrdeIsUA3FzbHHKVPiuii9Ko7xs2', NULL, '2026-06-04 22:25:50', '2026-09-17 11:17:55'),
(25, '565944af-ee47-4a2a-98e5-ad2eab618b6e', 'Luckycharm', 'Luckycharm', 'luckycharms51516@gmail.com', '+13526000126', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-08 08:35:51', NULL, '$2y$10$4roKqDXlA2o1J9XhbHhsw.FIJEe4epkRjO696yZdXcnaZMgZjX7s2', NULL, '2026-04-08 08:35:51', '2026-09-17 11:17:55'),
(26, '68e8e836-d90d-407d-9f55-5c0a547a89ec', 'Gassin26', 'Gassin26', 'ggas19922@gmail.com', '+19165303543', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, 'United States', NULL, NULL, NULL, 1, '2026-04-07 10:13:23', NULL, '$2y$10$GOSQXGg3Z/jwCzwLR3k1TOiL0qFiAZ29L.VK2WTGohjKjuVRVB8tm', NULL, '2026-04-07 10:13:23', '2026-09-17 11:17:55'),
(27, 'be24d277-f679-489e-b4b5-eb6ccf0addfd', 'KEVINWAT01', 'KEVINWAT01', 'k2474570@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$co1RjH4f1xHqNyEkJQrd5.W8IKPF/PR9hd5m0ulOIjVqiHXXqvOY2', NULL, '2026-04-07 10:22:24', '2026-09-17 11:17:55'),
(28, 'e1dea65a-37c8-4902-acab-7ea4b68e7b80', 'Lastcloud', 'Lastcloud', 'andrewdefenbaugh5@gmail.com', '+17206101038', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-07 20:17:12', NULL, '$2y$10$j9HKUhan1IY4pHnEecawE.TilOdGcSNDjzh1mFWlKi8rwNpC0id6.', NULL, '2026-04-07 20:17:12', '2026-09-17 11:17:55'),
(29, '765d3dbe-7d2e-4400-b8ac-52157f3a9257', 'sonnysd', 'sonnysd', 'ssandeep104@gmail.com', '+918688521935', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-07 05:19:09', NULL, NULL, NULL, NULL, 1, '2026-04-07 05:19:09', NULL, '$2y$10$HD/cU4y471kZ22gSCP9bOuNuhmzxguPQMcm3AuJxdQADUnmf8l78y', NULL, '2026-04-07 05:19:09', '2026-09-17 11:17:55'),
(30, '1dc48145-73da-4d74-bef4-451a66ffd2eb', 'Tesa19', 'Tesa19', 'tlemay1437@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-07 05:40:53', NULL, '$2y$10$sKeuojILLgtUS5d2UXqpautBMtm9u1hHg8C3CuQ4yVsHn66UPFrgu', NULL, '2026-04-07 05:40:53', '2026-09-17 11:17:55'),
(31, '20b43cba-81e6-4733-b20d-7ad3d99dc15f', 'Daraisam22', 'Daraisam22', 'daryl.r.lewis@gmail.com', '+14234877770', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-07 10:23:18', NULL, '$2y$10$/GDMx9efy6kKvrh06y29DOPTun9ae3VwM5xMs2l1ZsgkyHv1lJvDm', NULL, '2026-04-07 10:23:18', '2026-09-17 11:17:55'),
(32, '1ae4486e-272d-4c5c-9e48-12d87e5deff7', 'TillTill', 'TillTill', 'tilindiagraham34@gmail.com', '+14172627793', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-07 06:13:43', NULL, '$2y$10$S4sNFMDwYinvCXMtx3zRM.hAxTJAM4Dd3j60xAG5NkyI.8Pm/7Z7C', NULL, '2026-04-07 06:13:43', '2026-09-17 11:17:55'),
(33, 'c23337e3-579e-4fa3-b352-e4dbe9474076', 'SlimJuicy7', 'SlimJuicy7', 'ltaryn27@gmail.com', '+18287056012', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-07 06:43:02', NULL, '$2y$10$RvTMvJgZ9KW1brBnns8wbuMeSZgJ.sTmTsY9lCYA8f43mMGyWpqja', NULL, '2026-04-07 06:43:02', '2026-09-17 11:17:55'),
(34, 'ea3c3b0e-217d-467b-84bd-7e58a49ea541', 'BooBear420', 'BooBear420', 'booiswicked13@gmail.com', '+18593086632', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-07 10:55:11', NULL, NULL, NULL, NULL, 1, '2026-04-07 10:55:11', NULL, '$2y$10$yisnwx6flhnDL17v9bYDk.WcVA6mwG26uYRY/.wSflijSuoITx3GK', NULL, '2026-04-07 10:55:11', '2026-09-17 11:17:55'),
(35, '04e597dc-888d-4080-b797-f595b77b1cc9', 'Tyshanna', 'Tyshanna', 'cowintyshanna0@gmail.comlll', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$N91LKzxCYFR8psh/hNSKzOzfDWlccFjVIVzE.m1NSXcGtcqu4a.ty', NULL, '2026-04-07 12:14:36', '2026-09-17 11:17:55'),
(36, 'ba854b86-2f11-424e-9b77-15ed99adb0e6', 'Msboutique', 'Msboutique', 'tracyeaston66@gmail.com', '+14059159347', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-08 13:08:18', NULL, '$2y$10$KC1ONQOyXte/NuB9XsJ/AOt8usEeESsjU0DkroWIqm1iwR5l.2aeW', NULL, '2026-04-08 13:08:18', '2026-09-17 11:17:55'),
(37, '192dc478-6bf8-4aeb-ac2d-c86467b2ea2b', 'Nannerjo99', 'Nannerjo99', 'nannerjo99@yahoo.com', '+15026634188', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$WOzTdTN4MzMi0md12mzZiu6/FSRcv5sJnBrLqndVwi/0RutpagcKC', NULL, '2026-04-08 13:12:02', '2026-09-17 11:17:55'),
(38, 'ab5ce0fc-80e0-43a3-97a2-73fb02506ef3', 'Jasmine Payne', 'Jazzylee42', 'jasminepayne360@gmail.com', '+14174063136', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-07 21:17:01', 'United States', 'Missouri', 'Female', '1983-04-20', 1, '2026-04-07 21:17:01', NULL, '$2y$10$4/JYQZPvO1G3WKGx9eHTwuyGqk3lMWyYDQf4HceahoaEPE7sxyIUC', NULL, '2026-04-07 21:17:01', '2026-09-17 11:17:55'),
(39, 'cb78e2c8-c37f-4805-8bf0-66fe647844d4', 'Herc50', 'Herc50', 'ayman_ghali76@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$TLPIOSohzqijq/8AZkkHreapUEf5YZSHQG2EkDytCzEfw143jweMO', NULL, '2026-04-08 02:37:41', '2026-09-17 11:17:55'),
(40, '73f21786-0cc0-40a4-97d0-9d90fb86904b', 'Ydfjfdf', 'Ydfjfdf', 'christianmason19940@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VyzWqTbvbimgtgwyUhFtEevQcjCOlFfS1WbNZeQIcaARA/poTjkbS', NULL, '2026-04-08 03:08:16', '2026-09-17 11:17:55'),
(41, 'b3010870-04ec-4c1d-9bb8-35bf2fd20cb9', 'Daniel Edwards', 'dedwards03', 'dedwards0357@outlook.com', '+12525037406', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/b3010870-04ec-4c1d-9bb8-35bf2fd20cb9/avatar.png?t=1775801708927', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-09 23:46:51', 'United States', 'North Carolina', 'Male', '1981-08-04', 1, '2026-04-09 23:46:51', NULL, '$2y$12$8lQX0v.SrZTY55UoOG/15uUG2NLkvrcp7././hIxs9DwaUqECaNbe', NULL, '2026-04-09 23:46:51', '2026-09-17 11:17:55'),
(42, 'cc5d3c5f-3818-4dd9-a87f-05c2fe12e10a', 'Nicole Phillips', 'Greeneyez', 'greeneyemonsta1979@gmail.com', '+14058685550', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-09 16:44:09', 'United States', 'Oklahoma', 'Female', '1979-02-20', 1, '2026-04-09 16:44:09', NULL, '$2y$10$HIHsP2f882tjvsN975Nf6OfrWz8bPPSF7Tttw16XyAn04erGIIE3C', NULL, '2026-04-09 16:44:09', '2026-09-17 11:17:55'),
(43, '6b71bbd6-4cfe-43e6-afe4-37a6b82e96ba', 'Atl251', 'Atl251', 'wardamn6876@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DedtZHQhkTFjSaUfndV2kOJoqHfk9KLFciyoOf2ISnydrrtKuUOiu', NULL, '2026-04-08 22:06:49', '2026-09-17 11:17:55'),
(44, '857770c3-26ae-4878-99a2-2f87c6e105b0', 'Mamma0912', 'Mamma0912', 'paigeskye0912@gmail.com', '+14793062206', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-09 07:49:25', NULL, NULL, NULL, NULL, 1, '2026-04-09 07:49:25', NULL, '$2y$10$VeSBloKbHkWNW9YTjEUzKu9K5QPb8SXAz0cLXq2HMhEH.R84iVu2G', NULL, '2026-04-09 07:49:25', '2026-09-17 11:17:55'),
(45, '4f6ee492-e31b-4e2f-939e-60e7e6419ca2', 'KatyG92', 'KatyG92', 'kategoulet192@gmail.com', '+15072790938', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-08 20:36:04', NULL, '$2y$10$v29vEbQZLYFVFBclPSoM..W7nW71XQrkn7UQYMotGWw64QxioDxki', NULL, '2026-04-08 20:36:04', '2026-09-17 11:17:55'),
(46, 'ed6883ae-3d3d-4fb9-9cb1-54df2d08aab3', 'Medussa', 'Medussa', 'hlnyc@yahoo.com', '+15165063680', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$X.tuGPt/2ml5PNzwZlonc.uKztht2e0WaJJkwtZgfQEB5moN4BLuK', NULL, '2026-04-10 10:45:58', '2026-09-17 11:17:55'),
(47, '8449bece-40c5-417b-9ce2-cb2384466192', 'Justkeith', 'Justkeith', 'justinkpressnell@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1QeoslpM9Cfz8d9OxJTGDuOrhKW05docieYm1dOxQLZ.hcT66fTd6', NULL, '2026-04-11 13:53:05', '2026-09-17 11:17:55'),
(48, '05d1805f-0ffe-4b59-ade2-903cd7cd5c73', 'SlikRik842', 'SlikRik842', 'anessa2924@gmail.com', '+17047284135', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-08 10:02:13', NULL, NULL, NULL, NULL, 1, '2026-04-08 10:02:13', NULL, '$2y$10$YQkCDprN9YyTuHRBVxdkZOnFfGS6bqdXhlpbE3kYMexy1hfK4GMI.', NULL, '2026-04-08 10:02:13', '2026-09-17 11:17:55'),
(49, 'c607687a-7220-4779-9397-908a378c255f', 'Jimm1126', 'Jimm1126', 'jimmiebminoroverseer@gmail.com', '20531278910', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-04-10 16:27:50', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$k/YArq7lv5gLrNVPJO1lmek810DaVQheN67OXD/M4ZF47cD8LDgEi', NULL, '2026-04-10 16:27:50', '2026-09-17 11:17:55'),
(50, '33ad3709-6cc0-4c45-870b-17c751f3e56c', 'Smurf84', 'Smurf84', 'smurf121784@gmail.com', '+12055369599', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-10 16:25:44', NULL, NULL, NULL, NULL, 1, '2026-04-10 16:25:44', NULL, '$2y$10$cxe6Jhukf1xr3z9O/9Bvp.N32Jjh2/KphRoRvTfR3a4xgrtq2UMuq', NULL, '2026-04-10 16:25:44', '2026-09-17 11:17:55'),
(51, 'a9ab3be4-195a-4eb6-ace5-e0ed6c52ff8b', 'zamira', 'zamira', 'zamira.estella77@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-08 20:50:27', NULL, NULL, NULL, NULL, 1, '2026-04-08 20:50:27', NULL, '$2y$10$OmvLX/wFWF7IRbnRI5luRuoIcDeDinSCF2GwJ5SK8/4Aaha1C3h4m', NULL, '2026-04-08 20:50:27', '2026-09-17 11:17:55'),
(52, 'dd6a864e-a1ac-4999-a10a-f32be474b234', 'Akib007', 'Akib007', 'akib.work25@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-08 21:32:34', NULL, NULL, NULL, NULL, 1, '2026-04-08 21:32:34', NULL, '$2y$10$UysZzuKb43DCdscX.2UNg.SVx6/K0Vu5NPIMtMm30DVKH0HM1cFc6', NULL, '2026-04-08 21:32:34', '2026-09-17 11:17:55'),
(53, '7bfd438a-01d1-452a-9e7a-557860c5ec04', 'MstLija', 'MstLija', 'jennielou120@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-15 23:32:28', NULL, '$2y$10$SkLRQZc46Aj6SG450BzG5eexAgySXh62fof5ldA9q0mJVOtwuM6pa', NULL, '2026-04-15 23:32:28', '2026-09-17 11:17:55'),
(54, 'e6e45918-a88e-452b-bed4-6e5de235c198', 'Sorepp', 'Sorepp', 'schryer666@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LDRGWuyGoD8hKrShuScVx.AHgVSpWn2QuO2wo4zeDyXd0mNpP/GIm', NULL, '2026-04-19 14:20:41', '2026-09-17 11:17:55'),
(55, '421b3ed9-87d4-4ffd-a443-60b22b2e059b', 'dicknose12', 'dicknose12', 'arlenevillasenor801@gmail.com', '+17144008983', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-11 15:47:47', NULL, '$2y$10$9ymcSs3DaVpiUTBYdPRdeO/CQIUhoyYKWXq88sRI9L/s6kgR1SLZq', NULL, '2026-04-11 15:47:47', '2026-09-17 11:17:55'),
(56, '4a454dc2-d3c1-47fe-a7f0-a51b6194a47a', 'annabass11', 'annabass11', 'annabass1117@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZkVAyTfJecefQmdc8YWygeY10uDKyGO.rdG8cKCL6MFx7Luk1QTe.', NULL, '2026-04-11 22:30:33', '2026-09-17 11:17:55'),
(57, '30ec3455-4f25-44f2-b265-f1f91cb2319d', 'Keithw32', 'Keithw32', 'kwilliamsjr2012@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-13 14:14:54', NULL, '$2y$10$rz1GYQ6wUdnDM5/YlPn8/.ek4SMlLUUmKxFqs0OWXXUCk/rU5A6Ku', NULL, '2026-04-13 14:14:54', '2026-09-17 11:17:55'),
(58, 'fe9310bd-deeb-4c71-a4f3-56196b3f0376', 'Bubonixxx', 'Bubonixxx', 'wes.george30906@gmail.com', '15015769324', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-13 12:01:28', NULL, '$2y$10$z066cZbSJiJFcOPqrkspseJZqWGmFziPydiEIP75x4SR20eycvnA.', NULL, '2026-04-13 12:01:28', '2026-09-17 11:17:55'),
(59, '6d02af92-7ab4-494f-8898-2737567b050e', 'diesel', 'diesel', 'diesel@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$I/wya5vh1vTGZSIZ0ZNPz.pIqB0mqSd8.VtVUiCiZaLzwXEiNs8Cq', NULL, '2026-04-20 09:10:47', '2026-09-17 11:17:55'),
(60, '7fd6631c-030d-45a3-97e0-93b0ae8a007e', 'JamieSea', 'JamieSea', 'seagraves791@gmail.com', '+18432059242', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-16 03:43:30', NULL, NULL, NULL, NULL, 1, '2026-04-16 03:43:30', NULL, '$2y$10$HzDwnVgV1jTSCVB9fbZlPuBnesvuXEB8FXeVW04hVPLPHxw8DmnKG', NULL, '2026-04-16 03:43:30', '2026-09-17 11:17:55'),
(61, 'd3f6908e-8c0f-4e2c-9189-a1337712a1bf', 'smariec', 'smariec', 'nenemariec@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$k6ANazCb5NTl6k.0PLG3iOlHDdP9qZ9HPZfwOPz1cZ8vBAvtXE3s2', NULL, '2026-04-16 22:57:44', '2026-09-17 11:17:55'),
(62, '25783cab-b2e0-4cbe-bad6-da87b2928453', 'Nicoleort', 'Nicoleort', 'nicole.ortiviz@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MgOb2pqK9DTSGNDiUdi9PuQ.ORq/URSvuEGttw/1ldAyp5IvT78XG', NULL, '2026-04-17 09:02:55', '2026-09-17 11:17:55'),
(63, '59f843f0-f18e-4c49-b184-2f4e0e0030f7', 'Lee121', 'Lee121', 'leearchie121@gmail.com', '+13614072536', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-14 07:56:45', NULL, '$2y$10$TbeQNiaeQ/4mDFXPkAxdseXpnNEaQNyzOUh0bLXP2.fRqnlSAKAuq', NULL, '2026-04-14 07:56:45', '2026-09-17 11:17:55'),
(64, 'f437d88d-e454-43b7-8391-ba26446a0294', 'Oapypie87', 'Oapypie87', 'dustermorgan18@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZH6GhL1HiMPIU/cztQ42K.wWQHvpkpLbArBEzWwzQXAYzVzDeK3eS', NULL, '2026-04-17 16:30:51', '2026-09-17 11:17:55'),
(65, 'c6ae9c6e-3955-448c-b525-b3b3a4d06ce4', 'xvietboi', 'xvietboi', 'xlitovietboi916x@aol.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$65VRTR/opNyPZpEHELLisuArQZ/1CGtZOdh.rQiOxbhj/h/SBGXVK', NULL, '2026-04-17 20:03:46', '2026-09-17 11:17:55'),
(66, '5f1b0017-f236-4b1a-99bc-7d5421574f82', 'YogiBoi', 'YogiBoi', 'sikoraeugene81@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$7eGZQrXNACeXlpRr8DQSyOa2rUuxbU6F3N5889xIaTXw4UCsW18JC', NULL, '2026-09-03 03:19:04', '2026-09-17 11:17:55'),
(67, '8a91121e-cf88-4f6a-a315-1b18a1d39303', 'Jdooley232', 'Jdooley232', 'dooleyj505@gmail.com', '+12543465072', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-26 00:40:48', NULL, '$2y$10$Tfp/W740YXxy/DzKr.CLLOMPfW490l/PbeHzHC6YIEb7FpVv.edlW', NULL, '2026-04-26 00:40:48', '2026-09-17 11:17:55'),
(68, 'd4a3cd87-5f35-4e2f-a494-a9b29f98b026', 'Sunshine', 'Sunshine', 'hicksbaby1992@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$WTACqFYz.JVTQrmMnnzmKO53sOiysoLbew3C3tEc3Tn6rvR6wTNRG', NULL, '2026-04-26 11:40:14', '2026-09-17 11:17:55'),
(69, '68f280ea-9ff5-4efe-a76b-3cfb14a08670', 'Clay Crawford', 'Swayyy420', 'clay.crawford1996@gmail.com', '(806) 674-6157', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/68f280ea-9ff5-4efe-a76b-3cfb14a08670/avatar.jpg?t=1777122200996', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-25 06:46:24', 'United States', 'Texas', 'Male', '1996-05-15', 1, '2026-04-25 06:46:24', NULL, '$2y$10$BrC.BJ0nhlh0TktPJs63TeE5OQWi7xF7Ytv.GxZtDF5nYC0ruYfjm', NULL, '2026-04-25 06:46:24', '2026-09-17 11:17:55'),
(70, 'bb560572-7641-47ef-bc6c-f9559275cd31', 'smallcasso', 'smallcasso', 'small.cassondra.patreece@gmail.com', '+13184809332', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-20 15:14:07', NULL, '$2y$10$KPXkzc2t52Fc3irkvHEIOOHVGxFCtx2cTZHMNu21VgH.JACDitx1C', NULL, '2026-04-20 15:14:07', '2026-09-17 11:17:55'),
(71, '77fd4bf5-8c53-49f5-aeaf-aca94d2078f8', 'Kobza1', 'Kobza1', 'kobzasharon30@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-15 00:18:07', NULL, '$2y$10$RvPgDSWqy3REtkGeakQcDuVWwuvKFOhVqtJAzsiBP1Qy9DGAHFzzu', NULL, '2026-04-15 00:18:07', '2026-09-17 11:17:55'),
(72, 'a4b03704-6eb1-47ef-9542-25d9de9a200a', 'Stacy Freer', '2clean80', 'stacyfreer64@gmail.com', '+12705704883', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/a4b03704-6eb1-47ef-9542-25d9de9a200a/avatar.png?t=1776493949822', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-18 00:23:32', 'United States', 'Kentucky', 'Female', '1980-11-05', 1, '2026-04-18 00:23:32', NULL, '$2y$10$3/YK4gP37TtLFuhMfUd2ZuyXb7XRMHqF1ISynTvhxb/DCYrytFY4.', NULL, '2026-04-18 00:23:32', '2026-09-17 11:17:55'),
(73, '2ed17fde-0afb-4b29-b056-b1e46c0c61e2', 'Krisboi13', 'Krisboi13', 'krisboi9313@gmail.com', '+12547239514', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-18 01:16:09', NULL, NULL, NULL, NULL, 1, '2026-04-18 01:16:09', NULL, '$2y$10$nR8A8JR4OYCsRrEszZNHVOOmmdvTCDRppUYT8OBgF//EwSRXSYT4q', NULL, '2026-04-18 01:16:09', '2026-09-17 11:17:55'),
(74, 'f3cdac65-778f-4b7a-829f-5823df8374cd', 'Swearpaul', 'Swearpaul', 'swearpaul1980@gmail.com', '+15808267809', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-21 20:29:17', NULL, '$2y$10$/jhyNIAeRVQos65doaPL5e7op/slJMXSnqdjYwI/nxxNP1nBJSQ3a', NULL, '2026-04-21 20:29:17', '2026-09-17 11:17:55'),
(75, '30321f7c-ba83-4973-a6ce-0c561945775d', 'PleasureP', 'PleasureP', 'jessica.rey.4159@icloud.com', '+15627388816', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-04-18 01:33:01', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tJofaK805J.I0joFr/8/2OE5iVAq3GPpdodvI7Lz3x1vc4lz27JQW', NULL, '2026-04-18 01:33:01', '2026-09-17 11:17:55'),
(76, 'c14e9d2b-27ae-46ad-a6d5-707f8cf12b73', 'Zonazoe', 'Zonazoe', 'lilfizzle77@gmail.com', '+13242000418', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-18 14:30:17', NULL, '$2y$10$kpsKAa0J2nwqDbzSTwwQgeAZXUzMdzCUDhUefsVAwUylt61DxQ9DC', NULL, '2026-04-18 14:30:17', '2026-09-17 11:17:55'),
(77, '9ed4e515-8711-4288-9bae-ef3aafe4cc49', 'Abkampen', 'Abkampen', 'berkenkampallan@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-27 13:18:21', NULL, '$2y$10$HV8xJQLcqsUfzu.bHJCb5ukInB84LmvBfuewxm5N0wOGeE2tNiXBe', NULL, '2026-04-27 13:18:21', '2026-09-17 11:17:55'),
(78, 'aad561ac-4696-47e7-84d0-c34c031633ee', 'Mwig333', 'Mwig333', 'wiggermelissa333@gmail.com', '+18034968774', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-13 12:29:34', NULL, '$2y$10$pgAOFKQ3EaCwD4ldFXbOWeVQl9J9I5HkLXsZTRVnMgXA19g7LU23.', NULL, '2026-04-13 12:29:34', '2026-09-17 11:17:55'),
(79, '6b543b4d-8a8a-4616-a110-fc8dee4503ee', 'Charlesv82', 'Charlesv82', 'charlesvickory82@gmail.com', '+19049218487', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-25 13:18:58', NULL, '$2y$10$Tg8Gx/51A93ewxZ04VzuleiGk4WKWPMEX735b8hybcOYKyHgeLNlS', NULL, '2026-04-25 13:18:58', '2026-09-17 11:17:55'),
(80, 'bbb06d35-59b6-418b-841b-a17a7812a719', 'Adnanislam', 'Adnanislam', 'mehadislam92@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZHQ3MjtYiI89264/FLfwt.ZBYSPakg5DYc/znxNAR3mtzE1fV4X3C', NULL, '2026-04-15 23:31:52', '2026-09-17 11:17:55'),
(81, '03c4bc8f-15c7-4cb8-a515-6cb312fbbf78', 'ceemoney', 'ceemoney', 'idkyouyoudkm@gmail.com', '+18435686839', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-19 00:05:05', NULL, '$2y$10$ObB71bS0dNBTqwTi0GwzLuFZaZpP18kde8qGeKPx8g88ZlN4f5zI6', NULL, '2026-04-19 00:05:05', '2026-09-17 11:17:55'),
(82, '5d63cc4b-a3e6-4de9-8bc5-612a76cb99fe', 'Brittany42', 'Brittany42', 'brittanyparker903@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-25 13:54:50', NULL, '$2y$10$.BJ.A5W5ljfkBRTtgP2qjOkjDXTodvqAn3WdlODLl3dSWQu0lKYzO', NULL, '2026-04-25 13:54:50', '2026-09-17 11:17:55'),
(83, 'e63c7a67-539e-4bf7-a7c2-9cd8168f514a', 'Buugggzzzz', 'Buugggzzzz', 'katie.mccarley9552@gmail.com', '+16617726565', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-19 00:32:25', NULL, NULL, NULL, NULL, 1, '2026-04-19 00:32:25', NULL, '$2y$10$W4YYzECm1a42Q5GCeY8OcujmHLRj6Q.GF4wblUayXkmbWUSFKKqpK', NULL, '2026-04-19 00:32:25', '2026-09-17 11:17:55'),
(84, '2465eaef-b135-4710-ad65-92e1a5a37827', 'Amanda Szakel', 'Aman214', 'aszakel.00@gmail.com', '+13179457842', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/2465eaef-b135-4710-ad65-92e1a5a37827/avatar.jpg?t=1776836294691', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-21 23:24:11', 'United States', 'Indiana', 'Female', '1989-02-14', 1, '2026-04-21 23:24:11', NULL, '$2y$10$NznE8c69zJH/mj3/cYCJfOagEygm8eZbkTXYkYwk0iLrPVeln0iOu', NULL, '2026-04-21 23:24:11', '2026-09-17 11:17:55'),
(85, '0f515a6d-4a75-4f65-b179-4c2582c3cd3b', 'kotarayna', 'kotarayna', 'kotarayna@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$R6uv8JmHca6sG2NtgXvAlOzVsOtL0sZT3lzSbd1XzFfUVyR9L1l7S', NULL, '2026-04-22 02:25:52', '2026-09-17 11:17:55'),
(86, '6bccb168-f4ad-466f-bb48-5b4f7b132ebe', 'Romeroscot', 'Romeroscot', 'romeroscotti33@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$.Y3v1ZluqP90thcCdjO63ewWtmRn4.7.ykxvkkriTNxAbuUQ3BC5q', NULL, '2026-04-24 04:19:58', '2026-09-17 11:17:55'),
(87, 'dc1e18bd-2de9-4117-9c67-6cf13b7b1754', 'Coolbreeze', 'Coolbreeze', 'brantly2085@gmail.com', '+15738870052', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vp9x6NDuTDp3o9GFR6XnF.wQATVah5wbYXgXKYTHVeIu1EniBcGv.', NULL, '2026-04-24 09:08:52', '2026-09-17 11:17:55'),
(88, '56317257-f303-4d11-9598-b3245281d44f', 'dodgesp', 'dodgesp', 'dodger90723@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-24 18:20:38', 'United States', NULL, NULL, NULL, 1, '2026-04-24 18:20:38', NULL, '$2y$10$qxIlrpsRt480ZxrcRiFje.ltv4npwACqJD2p2JkG6FnLj2BzFs9KS', NULL, '2026-04-24 18:20:38', '2026-09-17 11:17:55'),
(89, '82d79e19-2751-4b26-8f49-9b567be4a34a', 'Keeleyx3', 'Keeleyx3', 'keeley2225@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$be4j9.hEUlIJq2nr0TJPFehN5Uwf9LWppxD5BfUJ/3SGtYtDVTQxW', NULL, '2026-04-27 14:31:03', '2026-09-17 11:17:55'),
(90, '9d591b6a-d3e5-468c-8907-32e4fbd16fa2', 'jdwl1817', 'jdwl1817', 'jdwl1817@gmail.com', '+18302999267', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-25 21:46:49', NULL, NULL, NULL, NULL, 1, '2026-04-25 21:46:49', NULL, '$2y$10$tzek0ydeDI8xNqDZkYzM9eVWi1KhwcoM8lESUb.PEw3Z.Lv80ri3i', NULL, '2026-04-25 21:46:49', '2026-09-17 11:17:55'),
(91, '08924fb8-7004-458a-b18c-40397b069e20', 'Jtjojo007', 'Jtjojo007', 'trejoxjx@gmail.com', '+18184713607', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-04-27 22:02:54', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zdrIUV5RaDZ8Ku30MShfkOFtPtwei49gH9EHw8N.87UsgUR.MXSOC', NULL, '2026-04-27 22:02:54', '2026-09-17 11:17:55'),
(92, '29f34064-8c71-41c8-bc16-3ef0c8522667', 'gamepaneluser011', 'gamepaneluser011', 'redeem-test-0a6bbca3-c78b-4b70-8718-9186d74fbbf1@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$WekO5gRDu0WJIYrpS3Zs/e1U9smblS3iWqHf21N2QMV7zU49aJcPq', NULL, '2026-04-28 04:54:09', '2026-09-17 11:17:55'),
(93, 'e8aeb52c-6d27-4660-b401-9083aec63e22', 'gamepaneluser012', 'gamepaneluser012', 'redeem-test-1ac8f667-e7dc-4204-bb2b-bcd8277012c8@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$T3EUBaIjTuP046/.a.glvOIt5.IbNpLOc2EEoZc9IsHv3Lvn.IPwu', NULL, '2026-04-28 04:54:12', '2026-09-17 11:17:55'),
(94, 'f4113665-628c-486d-9a59-73f47820b59c', 'gamepaneluser013', 'gamepaneluser013', 'redeem-test-0b98d380-ca7a-4a54-b98e-e67a891573c3@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xJO7VY2ArklDbkuy1EshEe1Ez9fP.t8Qbp8jjAC.mKj1hUzJqY9pm', NULL, '2026-04-28 04:54:15', '2026-09-17 11:17:55'),
(95, '52ea0ca4-8537-47de-8954-f13743bd26d8', 'gamepaneluser014', 'gamepaneluser014', 'redeem-test-d383f03a-f31a-4011-9c57-f8fa4ac4944f@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MVaBlWjUJ14dE9Yq2NnQl.L30DWWuRjxiXUVWMMctlAhzpZc2ytM2', NULL, '2026-04-28 04:54:18', '2026-09-17 11:17:55'),
(96, 'f4abbcb5-aafa-476e-9c0c-12e53be07aed', 'Carmadda', 'Carmadda', 'cmadd8855@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Cbhfco7jgqC1uv/wHjVRbOiSWvlrkUhFTONUQj6h0tnqpsXbpHfxO', NULL, '2026-04-28 19:05:45', '2026-09-17 11:17:55'),
(97, 'cfb3895e-e410-4d86-bd8d-9a2175c6bcbe', 'Tearsha420', 'Tearsha420', 'tearsha83@icloud.com', '+14303330687', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$k0lHprIhfSFH9bHfGhxjTeVfHItxfe3fyxHMLq7czEHK.xkYlj4oG', NULL, '2026-04-28 15:21:43', '2026-09-17 11:17:55'),
(98, 'f4f4ea52-35c7-41f9-8c30-0b0c98f243d6', 'Jessica Robinson', 'Jessica724', 'jessicarobinson724@gmail.com', '+13375152324', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/f4f4ea52-35c7-41f9-8c30-0b0c98f243d6/avatar.jpeg?t=1777438283308', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-04-28 22:32:34', 'United States', 'Louisiana', 'Female', '1980-09-18', 1, '2026-04-28 22:32:34', NULL, '$2y$10$fD0y3jvMC09usbwQLT/uBOtbEJIuKIPuJsKQnV2Ct91.zWaR8zq/a', NULL, '2026-04-28 22:32:34', '2026-09-17 11:17:55'),
(99, 'd5cec6ee-1efc-4610-936a-f661aa68d11b', 'Mmcleod142', 'Mmcleod142', 'mmcleod1423@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6pI6j7ArX9BqNJHDnJ3yw.BjKUM3U4.pD1kl0hCvv8IddrTCNU5we', NULL, '2026-06-04 22:15:27', '2026-09-17 11:17:55'),
(100, '771731a5-4dd6-4b57-a79d-0d2080e865c3', 'Khaikhai', 'Khaikhai', 'khaikhaitheone1@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CT5RVf3fGgTe501kGNSSoeYmzIJi1VZsd3wBeTm8RhHy0ti/h1.GW', NULL, '2026-04-29 08:07:21', '2026-09-17 11:17:55'),
(101, '12446d4d-9e13-40ee-9a74-763baa76b84b', 'Mmcleod14', 'Mmcleod14', 'melissa110123@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$QVFuTuy39xsS9F.OTKK6wOckOZ6G2w.4u8R3vqc.3zzcb2BvFPTxa', NULL, '2026-06-04 22:16:03', '2026-09-17 11:17:55'),
(102, '1508c1f8-5e27-41a9-9b68-665b53d48ef5', 'Queenambee', 'Queenambee', 'queenambeezy@gmail.com', '+14085093386', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-29 02:49:44', NULL, '$2y$10$Oa7HN82ahgMhCrJjKyEh0e.8NmYOhP.P9vzUREUfOnr6OzVQNnX5S', NULL, '2026-04-29 02:49:44', '2026-09-17 11:17:55'),
(103, 'bfb67f17-5918-4025-b09d-097df245ebbf', 'Hannahglov', 'Hannahglov', 'fallin4you1989@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sqLiLYdPYoLLW8Ym3xW4e.Mr4k2qikuLm8KkEFqn5fXNBXPKT9N12', NULL, '2026-05-01 05:43:27', '2026-09-17 11:17:55'),
(104, '532bebe4-cbee-4be7-9074-9ea1d97b4223', 'Jessma77fk', 'Jessma77fk', 'mazieb89@gmail.com', '+16209608504', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-11 08:43:21', NULL, NULL, NULL, NULL, 1, '2026-05-11 08:43:21', NULL, '$2y$10$waC6cEMOOEI426A/tqwosuJEb1N.8Z3w8t9GeCAxxCvvUON1JRbmC', NULL, '2026-05-11 08:43:21', '2026-09-17 11:17:55'),
(105, 'a318b805-da16-4b38-974d-c170ca57ae8a', 'Babytysonx', 'Babytysonx', 'zariyahsdad1989@gmail.com', '+19193686098', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-08 23:59:53', NULL, NULL, NULL, NULL, 1, '2026-05-08 23:59:53', NULL, '$2y$10$T2cun8LkruDQQxGrkoFhNe.aFTg7UMUOjnsfECtrV74NtW/9eATqK', NULL, '2026-05-08 23:59:53', '2026-09-17 11:17:55'),
(106, '2e96cb57-4720-485d-a5e3-241c4d15e753', 'Thareal8ps', 'Thareal8ps', 'dylanmack.biz@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$M.3xZ7BihTwdh6P8w6FHkeL9jARRBpaAmEdzNeIIvgL6mUNnYAJeO', NULL, '2026-05-01 13:22:16', '2026-09-17 11:17:55'),
(107, '8cb30bae-a375-4969-94c6-5fe1d358a55c', 'Bryce Michaux', 'Redskidoo', 'landskibryce@gmail.com', '+13529668605', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/8cb30bae-a375-4969-94c6-5fe1d358a55c/avatar.jpg?t=1778110955198', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-06 17:38:56', 'United States', 'Florida', 'Male', '1998-10-16', 1, '2026-05-06 17:38:56', NULL, '$2y$10$GKF/IOKHp9hHtSvMzhL.eek9vPIK.qMPJrqBlc8WYZG5GnyQKRcry', NULL, '2026-05-06 17:38:56', '2026-09-17 11:17:55'),
(108, 'd241d464-0d4d-4607-915f-d3234c92b11f', 'Chevatron5', 'Chevatron5', 'jimmydeanapplesnatch@gmail.com', '+15304436070', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-01 13:20:01', NULL, '$2y$10$fGh2HFt/mpWRJWQ4gEQ7Eu7q9yc.oFjy948yvIbezEtULtPakJ47e', NULL, '2026-05-01 13:20:01', '2026-09-17 11:17:55'),
(109, '6998020d-7cf8-4ab9-be2b-dc800e8e6f9b', 'Xolton', 'Xolton', 'colton.rivers678@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-02 08:41:55', NULL, '$2y$10$QdXS6.aRlXABRzsimGbjje2fKoJ0B3qxSs0fP3eP0Xv0LbsQA3v.y', NULL, '2026-05-02 08:41:55', '2026-09-17 11:17:55'),
(110, '9c47c6a3-d19e-4bf9-96aa-37e66b543b90', 'Rachel222', 'Rachel222', 'rachelreneeday@gmail.com', '17374029207', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zQK4NKJrfxwED7hyeyFu2.XmJfvvyd/ugnLNkKvm/MkN1HbzC9ody', NULL, '2026-05-09 00:12:09', '2026-09-17 11:17:55'),
(111, '94161159-c51e-4b77-9a68-f9b7133bfe06', 'Boakley', 'Boakley', 'bwitched098@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Ptv/k6t3f8twIYPfSvaU2.jakKvkRFl5Lal5v.WsEfaS.IipzKGgq', NULL, '2026-05-09 14:21:15', '2026-09-17 11:17:55'),
(112, '98e347d5-066b-4640-ae23-e3b0d2dcf589', 'Bwine96', 'Bwine96', 'westonjames26@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qkaiRpzlfxoGq0tLcH6OrOZobeSUZhBjcyAgkbVtOBJaNfvYPW0p.', NULL, '2026-05-10 01:12:21', '2026-09-17 11:17:55'),
(113, '6cfc1dc6-bfda-40e7-8506-4e8944384c70', 'Francisco Quintero', 'Jalisco', 'awesum189@gmail.com', '+19514514489', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-03 19:53:06', 'United States', 'California', 'Male', '1990-03-26', 1, '2026-05-03 19:53:06', NULL, '$2y$10$ZbVTg9WiwVnbYpGso8ZEFefVFDmeAVbvwX6QYxOFVtigxN.UKlVv2', NULL, '2026-05-03 19:53:06', '2026-09-17 11:17:55'),
(114, '1c45e247-5db5-44ad-a919-44072bcac669', 'Anthony Hartsell', 'AntHart85', '86gthartsell@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Male', '1985-12-04', 1, NULL, NULL, '$2y$10$atPDJsziOYSjRUnBn.Ith.uCeg3Twcla0eC1Zwv8UUik/VeHTbDKe', NULL, '2026-05-04 12:41:07', '2026-09-17 11:17:55'),
(115, '623a713c-1edd-4e3d-b7f5-d675d1967ae1', 'Honeywell7', 'Honeywell7', 'bsexxi650@gmail.com', '+19038848831', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$E575DJbqA460cc0OoTw.z.PIJSwn57uznigUXKtVFUd8wb4Yt2Zwq', NULL, '2026-05-04 20:22:29', '2026-09-17 11:17:55'),
(116, '7b0c4403-5406-4e41-a6d5-9e46b8d08807', '2AVallejo2', '2AVallejo2', 'tomaddhattz@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vuS9Skz4/0pCSYKw3KbdzeJ7hw8PXxOc4x4o.8elrtbDeUWMYVcGy', NULL, '2026-05-06 20:20:42', '2026-09-17 11:17:55'),
(117, '2068f2c0-0872-44d9-adb0-305035e893d8', 'Arlicia', 'Arlicia', 'arliciastrickland0913@gmail.com', '+19032167820', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-11 05:21:46', NULL, NULL, NULL, NULL, 1, '2026-05-11 05:21:46', NULL, '$2y$10$i7ainJRbFextlcWHcQN10u1MWnGxuN.gBN55oLzhZQ6lK68p49X8K', NULL, '2026-05-11 05:21:46', '2026-09-17 11:17:55'),
(118, 'c111ef6d-4a3b-43b1-b2b5-50c1adaffbb6', 'Taterade', 'Taterade', 'sipontaterade23@gmail.com', '+18289990883', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$jTcw1fJvqIqdNjZZbz0zO.k3ZjMki7QwTSfJc1oc4JZE/9QKm.xS.', NULL, '2026-05-06 03:06:56', '2026-09-17 11:17:55'),
(119, '8dabf1ba-4d68-4874-aa64-271200ad7c7f', 'Jess724', 'Jess724', 'jbrobinson724@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$O6.2yYdxnaAVZfleH8CAsO/gWaGZMtLzl9aRgWNim/OpU.WfnWk8C', NULL, '2026-05-06 05:46:44', '2026-09-17 11:17:55'),
(120, 'fcbf2925-a1db-4bf6-b6eb-585ac4aff05a', 'strictly89', 'strictly89', 'strictly89business@gmail.com', '+12293920725', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, 'United States', NULL, NULL, NULL, 1, '2026-05-05 23:25:26', NULL, '$2y$10$BGHysCYJui6Nx0WsYCKz/ua/lewibSt8I12/oDeZYVoA4qHCbW2Xy', NULL, '2026-05-05 23:25:26', '2026-09-17 11:17:55'),
(121, 'e8d1e6ad-a815-4c21-bd5f-05f56dc62e76', 'Marisolt', 'Marisolt', 'nestrejo00@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LpzD9rMwbR.Uxg4gI7UIU.amOKTm209OFYLnnsqFIZ1cn5LZonyCi', NULL, '2026-05-08 00:37:11', '2026-09-17 11:17:55'),
(122, 'd7bdc82a-fe3d-4380-8312-0b268fe1d48c', 'Logan4774', 'Logan4774', 'loganharrold178@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/p2WrgEEXVxiTGU0WjVdmOvY3bu2vt54vUDBZyTkLQBLTWMowI0XW', NULL, '2026-05-08 04:15:18', '2026-09-17 11:17:55'),
(123, '6acf3a79-00bd-418c-8a49-5f8271868272', 'Lambo225', 'Lambo225', 'lmcraney533@gmail.com', '+12259985017', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-06 06:14:24', NULL, '$2y$10$yssX4gOisPirmAm2ri0dl.7bGSTyqEAQHGXXcNVixUR6c/1TEQjjm', NULL, '2026-05-06 06:14:24', '2026-09-17 11:17:55'),
(124, '8a9ebb80-4e91-46f1-91c2-11fc0b644a60', 'jonilynn', 'jonilynn', 'jonilynnvedros22@gmail.co', '+12514828152', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RAFAeyit6PMT6XBu.rB/Pe2sXLZ/t2Fxkc/X1V6LQDb8WZ0Ex4wOy', NULL, '2026-05-08 05:05:51', '2026-09-17 11:17:55'),
(125, '3e05980e-2073-4145-bd59-cbca09d7e4bb', 'DylanJ8os', 'DylanJ8os', 'su3de9x9@gmail.com', '+19097495892', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-06 07:52:56', NULL, NULL, NULL, NULL, 1, '2026-05-06 07:52:56', NULL, '$2y$10$fgeJVvXPDsTv1v0/rBneeeAuQyTfG31tke60oRVUsYKUxyEqSC6m.', NULL, '2026-05-06 07:52:56', '2026-09-17 11:17:55'),
(126, '4d0d948d-ebb8-40c6-be4f-3b95bebc323b', 'Outlawbarb', 'Outlawbarb', 'mcrisp405@gmail.com', '+19105485125', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-10 03:06:26', NULL, NULL, NULL, NULL, 1, '2026-05-10 03:06:26', NULL, '$2y$10$YAvCJqcXDICEip8rWVHM2e5stahohXEnOJGUp9IT7FXvmu7Kjv41S', NULL, '2026-05-10 03:06:26', '2026-09-17 11:17:55'),
(127, 'eff902d8-ecc3-4a8f-bf6f-d9ed8af0f83e', 'Lirpa420', 'Lirpa420', 'lirpa086@gmail.com', '+13306618153', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YMhpBekA7NkQCJtIXBNr/.aq2LXIY86JdJdfcJ2XGhBa6j30ZLJ2y', NULL, '2026-09-03 05:19:28', '2026-09-17 11:17:55'),
(128, '16239f08-0a47-480a-ab65-2bf5f956f1ab', 'UnRegister', 'UnRegister', 'roxycannon021920@gmail.com', '+12817227637', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-08 05:29:52', NULL, '$2y$10$X3MGe2l.C9KWxVcR4Q8iROhsox.hOXszl0rRFPucWxor5lzHIElvK', NULL, '2026-05-08 05:29:52', '2026-09-17 11:17:55'),
(129, 'a7c678d3-998a-4e40-ab1f-3c866c67bec7', 'Legend2681', 'Legend2681', 'yotes890@gmail.com', '+18049040268', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-06 10:08:44', NULL, '$2y$10$fNJM6.iNWlO7jgTGR3z02uJS0.QlS.ln7PkDV/bU2jZdr0gxOlGJS', NULL, '2026-05-06 10:08:44', '2026-09-17 11:17:55'),
(130, '198f032a-7346-49d2-89d3-1993f762064f', 'Susiefonse', 'Susiefonse', 'susiefonseca9@gmail.com', '+18052481721', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2Ws9dAQ481O/Lzx5l3IKmuO7qo62N4uzVIzKjV.QfW0U2evHqX46S', NULL, '2026-05-06 16:00:47', '2026-09-17 11:17:55'),
(131, '64f123ec-4f41-470a-98fb-2ce08426b116', 'limbourneb', 'limbourneb', 'limbourneb@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-08 17:55:35', NULL, '$2y$10$tiED9pNdOdFrE.k6owyliOfYSHPF3qowm6dt0VLR6Bpj8l4V9TUvu', NULL, '2026-05-08 17:55:35', '2026-09-17 11:17:55'),
(132, '866fd875-a08c-4dc0-9e0e-0f22fe941121', 'Ladymay', 'Ladymay', 'magan.bailey1234@gmail.com', '+13374233681', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 00:55:19', NULL, '$2y$10$FnsEcI8UbQe9bI6wdfvKVukArQvbEZ/YUw/dEnvuOCMOjJQiF043y', NULL, '2026-05-11 00:55:19', '2026-09-17 11:17:55'),
(133, 'f7f97c2b-2c18-4430-b092-397c5c2929be', 'Darkchild', 'Darkchild', 'willleanww26@gmail.com', '+14302916252', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/f7f97c2b-2c18-4430-b092-397c5c2929be/avatar.png?t=1778512056033', NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 08:52:27', NULL, '$2y$10$pOPvsEYCEsRuztouKgPIJudsLbRsp3K/XnbdjCJRPQL3WVfpzC/Ee', NULL, '2026-05-11 08:52:27', '2026-09-17 11:17:55'),
(134, '9ed26697-bc84-46a0-b4b2-0312ad2a57b4', 'Joshua Yarbrough', 'Yardy94', 'joshyarbrough216@gmail.com', '+18122591945', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, 'United States', 'Indiana', 'Male', '1994-02-16', 1, '2026-05-08 20:52:51', NULL, '$2y$10$0C.faolo9Ywr7ryKSbPRiOx5BH68xHUWkDcCAV6L3jCh7.TEM/RmS', NULL, '2026-05-08 20:52:51', '2026-09-17 11:17:55'),
(135, '88844802-b3fe-4feb-8f90-f0a63d711ec0', 'Marisoltre', 'Marisoltre', 'solymar0721@gmail.com', '15624172545', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-11 11:20:35', NULL, NULL, NULL, NULL, 1, '2026-05-11 11:20:35', NULL, '$2y$10$23lPsPkGWp1HxTwt6WLpX.nqM840uXxOIVDucN.uN7vcKXaW7klRO', NULL, '2026-05-11 11:20:35', '2026-09-17 11:17:55'),
(136, '94c35831-13f7-4842-87ec-c8c8021890a3', 'Candymarie', 'Candymarie', 'trammellcandy07@gmail.com', '+14796708392', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-11 11:19:34', NULL, NULL, NULL, NULL, 1, '2026-05-11 11:19:34', NULL, '$2y$10$pxzHYul0q.4VSGbze/4oD.q32NWLWU2iEnsZ2U1AOXB9jy9jsYmMm', NULL, '2026-05-11 11:19:34', '2026-09-17 11:17:55'),
(137, '22b3aac3-9aa1-4119-b163-a54d8463eae4', 'Oropeza6um', 'Oropeza6um', 'ivetteoropeza31@gmail.com', '+19092737215', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-11 06:06:35', NULL, NULL, NULL, NULL, 1, '2026-05-11 06:06:35', NULL, '$2y$10$jN2P4uDDExPZgfB38MRH.OV95LrsYy8kIH0nv6CtgHK38kh386UPG', NULL, '2026-05-11 06:06:35', '2026-09-17 11:17:55'),
(138, '19daf3aa-d3ea-4c7c-bc61-adad1b842404', 'ogfly79', 'ogfly79', 'ogfly1979er@gmail.com', '+13233510542', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-11 10:41:06', NULL, NULL, NULL, NULL, 1, '2026-05-11 10:41:06', NULL, '$2y$10$GqeNtno8l2h3oqrFFEl8d.3BiXEGfjc/X5H6q2sldlcRMqJMRUsNC', NULL, '2026-05-11 10:41:06', '2026-09-17 11:17:55'),
(139, '2b5f308b-f808-4d61-9bdc-786dfa8801c5', 'Mwatts69', 'Mwatts69', 'sarahwatts155@gmail.com', '+19034013075', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 05:02:24', NULL, '$2y$10$/KlicJtqzLJlfbYgKSqZhOLsKylG3VWiWsgfsCGq7oBX8ndQg9aUW', NULL, '2026-05-11 05:02:24', '2026-09-17 11:17:55'),
(140, 'c4865f76-2ec4-4325-a185-068bc7d542de', 'Kari Martinez', 'Karim14jw', 'kariiberrii77@gmail.com', '+15058001319', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/c4865f76-2ec4-4325-a185-068bc7d542de/avatar.jpg?t=1778543425162', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-11 17:32:38', 'United States', 'New Mexico', 'Female', '1977-11-26', 1, '2026-05-11 17:32:38', NULL, '$2y$10$BCPO3H6MGFb3a9IqxbJcpudHIg1KcUk5QUcDTjolVWEqp/PSaJvF2', NULL, '2026-05-11 17:32:38', '2026-09-17 11:17:55'),
(141, 'eed81b44-d11c-45d7-889d-4cf9284b11f7', 'Brownb2pm', 'Brownb2pm', 'saucerealhard2@gmail.com', '+18042010478', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-11 15:48:56', NULL, NULL, NULL, NULL, 1, '2026-05-11 15:48:56', NULL, '$2y$10$LJlxnuTUHdI7EtrU4yA3ZODDr/sHgoQ9GxuApiO.SbDGfCPD50p/i', NULL, '2026-05-11 15:48:56', '2026-09-17 11:17:55'),
(142, 'b29da005-6a70-410d-ba1a-0b115eabaa7b', 'Vero1102', 'Vero1102', 'verom10855@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 21:03:31', NULL, '$2y$10$pBUxFrW/uFJSg3Ea3Fe9U.BZMbDBHIwSBXertEvs4zfXakOHe/3B2', NULL, '2026-05-11 21:03:31', '2026-09-17 11:17:55'),
(143, '6265ae5a-f0e6-4f36-ab99-f87b1cf01b9e', 'DaisyMe91', 'DaisyMe91', 'daisyosuna4@gmail.com', '+16199759365', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, 'United States', NULL, NULL, NULL, 1, '2026-05-11 11:24:52', NULL, '$2y$10$v.oQ9LBfDNXVhtSfX4taZO9fLmJLt6QPdSpwQ9pkqK42aARh1tJ1W', NULL, '2026-05-11 11:24:52', '2026-09-17 11:17:55');
INSERT INTO `users` (`id`, `legacy_id`, `name`, `username`, `email`, `phone`, `avatar_url`, `ghl_contact_id`, `balance`, `role`, `is_flagged`, `flagged_reason`, `flagged_at`, `email_verified_by_admin`, `phone_verified`, `phone_verified_at`, `country`, `state`, `gender`, `date_of_birth`, `email_notifications`, `email_verified_at`, `last_login_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(144, 'b41d1605-4c74-42e9-86b9-cc9ee8eba94f', 'Bigmama1', 'Bigmama1', 'imissmydad12345678910@gmail.com', '+12292652539', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$XwShvuYs9u48o3QI4WicWuN8ox4nbceOVc09OShOp1zQOHJ/uTaPi', NULL, '2026-05-11 06:42:01', '2026-09-17 11:17:55'),
(145, '9d331b7a-2ac6-43de-8e41-4fbc40bdab6b', 'DaJuicyOne', 'DaJuicyOne', 'alexdagreat7414@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$40K7xDkErMjOo/sRrhe1.eEb4CrJV9yi/ok7OAnLCX19ZflVErgma', NULL, '2026-09-04 09:17:53', '2026-09-17 11:17:55'),
(146, '43375961-b3e0-46ea-a2d8-cc03ff0dbacd', 'Monizzy', 'Monizzy', 'monicaandres805@gmail.com', '+17015782093', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 00:17:06', NULL, NULL, NULL, NULL, 1, '2026-05-12 00:17:06', NULL, '$2y$10$M8iTfvnVYFQDkUbYSeo5quz/JWsk4ycTSTJy2uq2FIoz39pxMgORe', NULL, '2026-05-12 00:17:06', '2026-09-17 11:17:55'),
(147, 'b7acb84f-3f7d-4bbc-8ca9-2c18771d37af', 'Isole82', 'Isole82', 'kendrahjones565@gmail.com', '+17402818780', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 00:01:32', 'United States', 'Ohio', 'Female', '1982-03-05', 1, '2026-05-12 00:01:32', NULL, '$2y$10$9ctJCIuMJkqCUHpBKCsEleTgbgC.wGbtOYd7wZFPh2U3kdG8CcVvm', NULL, '2026-05-12 00:01:32', '2026-09-17 11:17:55'),
(148, 'b67824d5-466f-4dbc-9418-3d98e4167b3a', 'Samb88jw', 'Samb88jw', 'sebaker1106@gmail.com', '+19194647862', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 22:27:31', NULL, '$2y$10$1zvLJlMpzgBq9SEpNvv4cOHlYXF6d0t0UQDMAyFfTNk..Wmgx3twS', NULL, '2026-05-11 22:27:31', '2026-09-17 11:17:55'),
(149, '7f527202-580a-4376-9390-274044a9de6c', 'Javv22gvgm', 'Javv22gvgm', 'javv22gv@gmail.com', '+18302758986', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-12 01:56:46', NULL, '$2y$10$iENT7LJjlKN80tdO6cyynOf5pF1LEbGrXESYMSxhSVYpcckiJqz6W', NULL, '2026-05-12 01:56:46', '2026-09-17 11:17:55'),
(150, '9f3a257b-e268-4315-af70-6805c101f1fc', 'sonyasteph', 'sonyasteph', 'sonyastephens90@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mB3cABqEN8Dhjlp9INvrIuVU1s/b20.BGiv0qmg2ijEnulbUcfZm.', NULL, '2026-05-13 06:36:33', '2026-09-17 11:17:55'),
(151, '48228904-b0b2-48be-863d-148b5c111ad4', 'Jeffro13', 'Jeffro13', 'jeffromorton13@icloud.com', '19792481682', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-13 00:25:11', NULL, NULL, NULL, NULL, 1, '2026-05-13 00:25:11', NULL, '$2y$10$.bxD6CFmHkE8/yc4CG6qxuX.5uDj7gRDHj2WrgXh6SwI5v2y1lcBe', NULL, '2026-05-13 00:25:11', '2026-09-17 11:17:55'),
(152, '4bd1aedc-8fc0-4867-95e1-91ed2358f20d', 'Deedee1804', 'Deedee1804', 'koreyboles1804@gmail.com', '+19048010277', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 03:23:38', NULL, NULL, NULL, NULL, 1, '2026-05-12 03:23:38', NULL, '$2y$10$YxfnMvScQf1zxWhNnxe80.2aypN3QhYT4YHF.cEF4zgwREUlD5pmS', NULL, '2026-05-12 03:23:38', '2026-09-17 11:17:55'),
(153, '2a16850e-af7f-485e-a8ee-af7533d80340', 'Chillwill7', 'Chillwill7', 'will76rbr@gmail.com', '+19452248769', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-14 21:46:01', 'United States', 'Texas', 'Male', '1976-10-22', 1, NULL, NULL, '$2y$10$1EnqkJrol4bestg2HRnJVOI62cX1RHKhdncHn5aGeukUcDnOtoOG.', NULL, '2026-05-14 21:46:01', '2026-09-17 11:17:55'),
(154, '644c8eb2-3666-4a71-ae5a-6d0f34a69e65', 'src8991', 'src8991', 'src8991@icloud.com', '+19107590794', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Gzcl0/aGZ28W135HVSsq0epjYZAfLm1r0YJa89UkJ0gVypxtGhccm', NULL, '2026-05-14 15:44:37', '2026-09-17 11:17:55'),
(155, '216bb264-7533-4b53-b683-47c462e73872', 'Jeffery Hodge', 'NemsaiWay', 'hjef9999z@gmail.com', '(430) 344-1639', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-14 03:54:23', 'United States', 'Texas', 'Male', '1979-08-02', 1, NULL, NULL, '$2y$10$WToJPf0SeGoK2Ehica7zAOSO.QRR.Qa0WqixNsKsyk8aOSQOyvh6W', NULL, '2026-05-14 03:54:23', '2026-09-17 11:17:55'),
(156, '036fa212-9cb7-41e1-9284-24da9ac0496f', 'Morris12jw', 'Morris12jw', 'queenw499@gmail.com', '+16023173413', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-13 02:24:52', NULL, '$2y$10$btryFpq5pIekMK0/vJI4KeK19sd4T24NuSZikJvWsYuZxSSZoUrGW', NULL, '2026-05-13 02:24:52', '2026-09-17 11:17:55'),
(157, '3d0ce7ba-9066-4148-aab5-fdea2292560b', 'abraham08d', 'abraham08d', 'abraham08delacruz24@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$BF7QQ/Y0XkDFeoSUjGWQY.HF.76QRmj7LnJdpThFLWNnlviLeSc9u', NULL, '2026-05-13 03:08:54', '2026-09-17 11:17:55'),
(158, 'c37dfeaa-80f2-4526-b727-37d0c7b6fd3d', 'Gatz420', 'Gatz420', 'kellytellywelly143@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$.LR7Nt4tnvsBCs/TZHEkwOeDefR.sIwQa0NbYcJ/1CojuihZajsNK', NULL, '2026-05-13 03:35:26', '2026-09-17 11:17:55'),
(159, '11ecbaed-f034-4339-9c75-a0a53d507657', 'deancreasy', 'deancreasy', 'rcx3823@gmail.com', '+17653572724', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 08:03:01', NULL, NULL, NULL, NULL, 1, '2026-05-12 08:03:01', NULL, '$2y$10$DtKFWLB8KAM/O361dGakbu224XLeBCBmFlHbkokdb2kkawqkG8Id2', NULL, '2026-05-12 08:03:01', '2026-09-17 11:17:55'),
(160, '7d313f91-38e5-499e-8775-daffbd48fc72', 'Patrice  Roderick', 'Twinsmamma', 'amackertwins@gmail.com', '+16614815401', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 07:33:45', 'United States', 'California', 'Female', '1985-12-02', 1, '2026-05-12 07:33:45', NULL, '$2y$10$YSaEap6a6sjrVJlL6Mw.UeChEYqM02dLdpdQySPmpjW1DUV5u9Cw6', NULL, '2026-05-12 07:33:45', '2026-09-17 11:17:55'),
(161, 'd95261e8-da5d-4142-8d89-eff4aa48eb1a', 'Austin Kent', 'Austinkent', 'akent436@gmail.com', '+16615906648', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/d95261e8-da5d-4142-8d89-eff4aa48eb1a/avatar.jpg?t=1778648144963', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 22:44:32', 'United States', 'California', 'Male', '1994-06-11', 1, '2026-05-12 22:44:32', NULL, '$2y$10$rsoS0vubvOykqBV2FbrbZ.cdjGKCaT.vtwuuwpdrQ8xHeMih7fuom', NULL, '2026-05-12 22:44:32', '2026-09-17 11:17:55'),
(162, 'ea6a5771-5965-4da2-b028-2417e75cdb8a', 'jessicah', 'jessicah', 'jessicahello2025@gmail.com', '+15622686507', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-12 08:47:13', NULL, '$2y$10$J4yXZidsE6GX6bynHhYeseR7VKlgkjdWtDQt7Nq9ihWAFX0ACQTGO', NULL, '2026-05-12 08:47:13', '2026-09-17 11:17:55'),
(163, 'e33e2e04-1598-4a85-a576-52198110ec1d', 'Grahamaw08', 'Grahamaw08', 'shuttlesworthgraham31@gmail.com', '+19032834623', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-13 09:21:45', NULL, NULL, NULL, NULL, 1, '2026-05-13 09:21:45', NULL, '$2y$10$vT7Lu.MFP695SIhJPGGQBulWHyKWjPvL4tTlzgL.0LCfhMYaM2aiy', NULL, '2026-05-13 09:21:45', '2026-09-17 11:17:55'),
(164, 'b05ae6e9-20a0-470c-b4d7-0e7a8f211dfe', 'Baybay4242', 'Baybay4242', 'baybaylucifernz@gmail.com', '+18402529762', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-13 03:38:59', NULL, '$2y$10$LdJgFxLK7pqFF8i.EOKwYuiUfOuzxoBBgJbGeMsqkGZuvPAL7Yg56', NULL, '2026-05-13 03:38:59', '2026-09-17 11:17:55'),
(165, 'bc5dda87-34bb-4000-8b49-9e10ec108648', 'Ashante  Bryant', 'Ashante', 'ashantebryant50@gmail.com', '+13189906518', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/bc5dda87-34bb-4000-8b49-9e10ec108648/avatar.jpeg?t=1778602772858', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 10:15:17', 'United States', 'Louisiana', 'Female', '1994-11-02', 1, '2026-05-12 10:15:17', NULL, '$2y$10$KiK7YSDjbQkmSP5n1XAhCewXSmvPCqMHgH9MXwU9F.Zd8vZYsFlyO', NULL, '2026-05-12 10:15:17', '2026-09-17 11:17:55'),
(166, '09e38e6c-a14d-4b52-98a1-ac87936624e1', 'Rick  Cisar', 'Rickcisar', 'cisarrick@gmail.com', '+14406914095', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/09e38e6c-a14d-4b52-98a1-ac87936624e1/avatar.jpg?t=1778650531847', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 22:40:09', 'United States', 'Ohio', 'Male', '1977-11-26', 1, '2026-05-12 22:40:09', NULL, '$2y$10$vQLGMfJy6Fbw6z4gR4Ft9.WqM3V0fIpTpaCBse0QQ6m2Fx/iOXx56', NULL, '2026-05-12 22:40:09', '2026-09-17 11:17:55'),
(167, '6f9a92f6-e4cf-4612-9112-7d789c8682a9', 'NasteeN8', 'NasteeN8', 'ih8n830@gmail.com', '+18065669893', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-15 02:56:41', 'United States', 'Texas', NULL, NULL, 1, NULL, NULL, '$2y$10$2oiRnnNH/7.8QvChtbKDbeOfwMx3Ti4iicyDj9LjezxTuwgrwVwAK', NULL, '2026-05-15 02:56:41', '2026-09-17 11:17:55'),
(168, 'ba4a0c30-aa76-4957-9434-e84e2f852618', 'jessicamae', 'jessicamae', 'jessicabeck1289@gmail.com', '+16125478575', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 20:57:41', NULL, NULL, NULL, NULL, 1, '2026-05-12 20:57:41', NULL, '$2y$10$uklz.pZmQC1dbfXAle1H6.zfav6o7HPxS7KIE3MNCIjYBM39x17eC', NULL, '2026-05-12 20:57:41', '2026-09-17 11:17:55'),
(169, 'f89a2846-4127-4482-bba7-522619a3a200', 'Chandabear', 'Chandabear', 'chandler.haden@icloud.com', '+14174086765', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$htTdmpk0.qusZ614ztZUZO.EuZ25oQPFfx.Sq/kfyWGERGPqarPqm', NULL, '2026-09-03 05:37:33', '2026-09-17 11:17:55'),
(170, '95dce7aa-8809-4523-90d8-3883601cf614', 'Littlek5', 'Littlek5', 'hilllaquita60@gmail.com', '+19727370474', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$IGfPzApDmNzCU7sGVzRWQu7hl5mf.Jdxly0uG70wg17SXK6un0Llq', NULL, '2026-05-13 04:28:08', '2026-09-17 11:17:55'),
(171, '4c8e8901-23c1-420e-9204-28606a47e8d7', 'Jackpotjon', 'Jackpotjon', 'mehringer23@gmail.com', '+18635139955', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-13 10:16:33', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$p3tWCWyxMbzMc9.deEfUceO66IqviklgwppdTl11J0n8xIHJmMp1O', NULL, '2026-05-13 10:16:33', '2026-09-17 11:17:55'),
(172, 'bc7fa3d9-e36f-49ec-ab06-02648e28f7e8', 'Tearsha83', 'Tearsha83', 'tearsha420@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$e0OrR/EiW/nmEh1FvitXVOEkvDfaf37e4mBoww4kgqYXgFxgzkIES', NULL, '2026-09-04 10:18:49', '2026-09-17 11:17:55'),
(173, 'c59f33ac-a602-4f84-9078-1f20ebaf5065', 'Aprophecy', 'Aprophecy', 'asimhaminworks@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2Q7J8CQG07f5EPmVTgoOce0Cs6nrOYncHtqdMpnKMiBH.fDAuYw9e', NULL, '2026-05-13 13:40:09', '2026-09-17 11:17:55'),
(174, 'b6092774-93be-4ff6-ad0a-ff85b61951c6', 'Vurias1pm', 'Vurias1pm', 'toxiclove942@gmail.com', '+13235957493', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 20:02:51', NULL, NULL, NULL, NULL, 1, '2026-05-12 20:02:51', NULL, '$2y$10$wInY.GSLJx7UKSq8x9M8HeVIz9eO3Z/3nw6FGWnr4cnBFZXD343Ga', NULL, '2026-05-12 20:02:51', '2026-09-17 11:17:55'),
(175, 'a7607188-1ece-48f3-83ec-b010b1b7fab6', 'Cheynicole', 'Cheynicole', 'ajsmama229@gmail.com', '+12293287679', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-14 22:07:35', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JklLY3aWniVctP36X6qBa.e/ZqYbPe23uj0hRzXgdhVw7u3M/4Z1S', NULL, '2026-05-14 22:07:35', '2026-09-17 11:17:55'),
(176, '6d835483-9e2c-4926-a776-99c1a7d9975b', 'Nicolem72o', 'Nicolem72o', 'flowershopeful@gmail.com', '+12293287679', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-14 20:24:27', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fpdKICG6728fS4Yxms.Om.8Pro0sNUEl8lofnHPJttCX0upjdesAe', NULL, '2026-05-14 20:24:27', '2026-09-17 11:17:55'),
(177, '53164ed1-b48d-4467-8094-1f700fd8757a', 'Jesse Hernandez', 'Jay1313', 'jayhernandez082713@gmail.com', '(559) 588-8432', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Male', '1988-11-10', 1, NULL, NULL, '$2y$12$9j9o8Pa3Audl/D9lk7QMC.Ismf6RdtdJooyda3r8sBeHY6r4Qm6gG', NULL, '2026-05-15 09:25:22', '2026-09-17 11:17:55'),
(178, 'dc469401-a9d6-4366-8ab2-40a5de21f2ca', 'Tyree  Sanders', 'Jakef65jww', 'babytysonxxx03@gmail.com', '+19193686098', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-12 21:20:11', 'United States', 'North Carolina', 'Male', '1989-01-26', 1, '2026-05-12 21:20:11', NULL, '$2y$10$Irk5Uu3EUd9SOQwQ44kae.VydY4icAjcippmTfl3YpEfqC8VuF.Pa', NULL, '2026-05-12 21:20:11', '2026-09-17 11:17:55'),
(179, 'b5dd6d38-13b6-4ecd-a52c-d2d0751cc33b', 'Robin Watkins', 'Oceaneyes8', 'watkinsrobin77@gmail.com', '+19793345247', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/b5dd6d38-13b6-4ecd-a52c-d2d0751cc33b/avatar.jpg?t=1778866104523', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-06 08:07:22', 'United States', 'Texas', 'Female', '1985-06-13', 1, '2026-05-06 08:07:22', NULL, '$2y$10$QIe61pCkGjFJtBb7/G.4R.8Co6IafY7RbtQwzxuq/D2YXKjzntTXi', NULL, '2026-05-06 08:07:22', '2026-09-17 11:17:55'),
(180, '0b6ce04d-7c45-4a15-acd8-a99369c6a75e', 'Marting1gv', 'Marting1gv', 'gutierrezmartin199520@gmail.com', '+16267864046', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-13 18:42:48', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DH6MtFXoXpy/ovgi0EHJmusQMvEZVHgWdtVX1qP6BuZjTYrIqsHFC', NULL, '2026-05-13 18:42:48', '2026-09-17 11:17:55'),
(181, '770c9995-db8a-4cdf-8402-9c685a1884c0', 'Joeesco13', 'Joeesco13', 'jojoescobar682@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SyWirq2SRoovqn8c/4APeOUIbS9SiBS7lLba/t5CdyCKFK5hH8LLC', NULL, '2026-05-17 03:32:06', '2026-09-17 11:17:55'),
(182, '251f95be-5311-4d06-92f2-fd882629d7b1', 'nolanstace', 'nolanstace', 'nolanstacey5@gmail.com', '+13525372826', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-13 04:08:29', NULL, NULL, NULL, NULL, 1, '2026-05-13 04:08:29', NULL, '$2y$10$zW56rG3eubO9gqP29cWr4eeFUU19cXe0HCzBwIZ7nlwP/Vov6Hd12', NULL, '2026-05-13 04:08:29', '2026-09-17 11:17:55'),
(183, '151ea115-5826-469d-a94b-b4f63308234f', 'NasteeN830', 'NasteeN830', 'justn8dog@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qzyAYSh0F1WIrnsIef1h8eyWOA2cMKQ/DCJpCNwdO9ApOwofBEAdK', NULL, '2026-05-15 17:02:56', '2026-09-17 11:17:55'),
(184, '935678de-79d9-49b1-ad07-52bff224551b', 'Ktvee24', 'Ktvee24', 'keithvasquez177@gmail.com', '+18064735250', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$depL5PRbEQo/a3i6z2oN6OCfZi9K6JWrjiCna3BSPGjJydNC/1vbW', NULL, '2026-05-15 00:48:11', '2026-09-17 11:17:55'),
(185, '123b9e0d-cd1c-416e-8c51-bb0f298c6c26', 'Indaniel75', 'Indaniel75', 'indaniel75@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$KJpqUdry0OWI71dt8XkQwua961Inop5s5W5AAgpjbueAG4QlBaL56', NULL, '2026-09-04 21:40:02', '2026-09-17 11:17:55'),
(186, '9787623c-7b2a-4c7f-a047-bd32a6fef072', 'Taylor Estrill', 'Taylorm4os', 'taylorestrill@gmail.com', '+13522170032', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Florida', 'Female', '1997-03-05', 1, NULL, NULL, '$2y$10$EqTKkzTwiwMpj.zJ2V8pSOEI0M80nUGSBnUb400pYHjrxRsrkn1FG', NULL, '2026-05-15 04:01:18', '2026-09-17 11:17:55'),
(187, '04a553f8-e992-4ada-ae20-5d2fb4357e18', 'Taylormay', 'Taylormay', 'tay.n.nite@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$EqVfqDMxYLXaA4U8zphq1u/EAAYjxpFukVINYWP4ZA3SmpmKN7TKu', NULL, '2026-05-15 04:20:21', '2026-09-17 11:17:55'),
(188, 'e63028b3-46b0-460b-93da-9f33813fc0bb', 'Arinicole9', 'Arinicole9', 'arianademaris38@gmail.com', '+16785484052', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LmRwKQlg6CFPoWUv5urKr.BPQmLiciISp.HUTWY/2NOCf9hYSGG92', NULL, '2026-05-15 18:43:22', '2026-09-17 11:17:55'),
(189, '8a748d8c-1dab-407e-a7ef-1952e694ae92', 'anthonyF77', 'anthonyF77', 'af054420@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$cPtVWywSaFb86k2grbYX0eC53fXxz/evheOVkZ2bMS573vpaZ1JGm', NULL, '2026-05-16 00:28:57', '2026-09-17 11:17:55'),
(190, 'b9faec5d-fe37-4c55-8e24-9cc756964a6e', 'KaelynBboo', 'KaelynBboo', 'itsbburroughs87@gmail.com', '+12055341859', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Alabama', 'Female', '1992-06-11', 1, NULL, NULL, '$2y$10$Qs/505kHwgfE2yhSN55dLeFbP2zDSBqeo98igDAiIc5AKpxsKGPia', NULL, '2026-05-15 23:04:01', '2026-09-17 11:17:55'),
(191, '88902b2c-feb4-48aa-bd2d-33427f3239ed', 'Khaylathom', 'Khaylathom', 'khaylathomas787@gmail.com', '+13136850360', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-16 09:59:20', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$pmPslBv8pbnlmXEMNlLsTe5ykNK0YioelW5AQd0mhHHXL2rtqHue6', NULL, '2026-05-16 09:59:20', '2026-09-17 11:17:55'),
(192, '8d142719-f9ca-4272-b8ff-ab5725048691', 'Jimmy Crosby', 'Jimmyc26', 'crosbyjimmy314@gmail.com', '+17377084428', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1980-11-10', 1, NULL, NULL, '$2y$10$VCsulS76P0n9BlU1rrhtkuZaVEPGhx0acY4kf7i5dzhJkgykNcQGe', NULL, '2026-05-13 09:11:36', '2026-09-17 11:17:55'),
(193, 'a0eec719-f3ae-4234-9f29-497d63de29c3', 'Shynel Wallace', 'beltrangab', 'shynel_wallace94@gmail.com', '+14424942231', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Female', '2026-06-20', 1, NULL, NULL, '$2y$10$pRoqICp9USV3zqEq3KZOl.iHQMiCwhf58HHeckXeSKeW4UvXesUhS', NULL, '2026-05-16 10:22:23', '2026-09-17 11:17:55'),
(194, '58e0eb10-2750-45d1-ad96-d54d61becb11', 'Lorena  Soto', 'stanBTS7', 'soto.88.lr@gmail.com', '+18314355459', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Female', '1988-04-13', 1, NULL, NULL, '$2y$10$/Xg3oxnJWJ3JLiMoP7Rp7uC5wR85nTNcB1xsX1fCnYU2lSHuFXDM6', NULL, '2026-05-17 09:58:04', '2026-09-17 11:17:55'),
(195, 'bf616cd2-3fd0-4cdb-ac52-b6e68b7d3b8f', 'Jujubean26', 'Jujubean26', 'sassycountryqween1990@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Jw9zNj.zhERweiUsWx2OO.VQ6Jdug0bwuyeLoM3SPp2/zOp9J5ZKK', NULL, '2026-05-19 23:57:37', '2026-09-17 11:17:55'),
(196, 'fcfa440d-bc7b-4fd0-b14a-17bb120a28a1', 'DirtyK95', 'DirtyK95', 'teddyp0129@gmail.com', '+18304510346', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-17 22:15:34', 'United States', NULL, 'Male', '1995-12-25', 1, NULL, NULL, '$2y$10$BJnPqSNNrj9BSxA6d6WOteO3jcig3dhRUhRzC0Iu00rsCN1MTo/sS', NULL, '2026-05-17 22:15:34', '2026-09-17 11:17:55'),
(197, 'b5cdae20-b23c-4ab4-a568-9169a161354e', 'DosBooby', 'DosBooby', 'lexihearts13@gmail.com', '+18284052413', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-19 10:42:50', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uFGdBWPxDPOOf9EB5BZiWuxxRzQ8OSng9Q5DQrq4NRsPUHsRH05OS', NULL, '2026-05-19 10:42:50', '2026-09-17 11:17:55'),
(198, 'c0d82ca4-5e4e-48cf-a7f3-385057382764', 'veronica', 'veronica', 'kailcreasy@gmail.com', '+17656524044', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-17 23:09:11', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vsyMBRZPkUZCzEucKSF.oOt/5h/ov7.wRms1GXv36RzLKHDWooHKq', NULL, '2026-05-17 23:09:11', '2026-09-17 11:17:55'),
(199, 'c2863cdb-b750-4cca-91c8-bc199fa67ac2', 'MyLua1', 'MyLua1', 'luafaavi@gmail.com', '+15626178209', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-19 23:08:50', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qSn7cFoLPHpmbyYGNk3NMupNYFb67ORhfa4m9XPBdNfdwWeoMcvN2', NULL, '2026-05-19 23:08:50', '2026-09-17 11:17:55'),
(200, '9d418271-a2b1-4117-877c-72c2e93e3973', 'AMANDA COLLINS', 'CollinsA7', 'amanda.cameron.143.4ever@gmail.com', '+16204740650', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/9d418271-a2b1-4117-877c-72c2e93e3973/avatar.jpg?t=1779168758028', NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-18 23:25:57', 'United States', 'Kansas', 'Female', '1989-08-09', 1, NULL, NULL, '$2y$10$gpzoXuEDugpRDUGjzph.Pel2c2M2LWwj8BLqNYLVHRZ6KxbmdTqOy', NULL, '2026-05-18 23:25:57', '2026-09-17 11:17:55'),
(201, '1dde2ec0-2188-431c-b7e9-33c50873a51e', 'Nina216gv', 'Nina216gv', 'tanishametcalf63@gmail.com', '+12792707771', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/1dde2ec0-2188-431c-b7e9-33c50873a51e/avatar.jpeg?t=1779081827348', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$N.r2t2iHdYC1QuuIku7BdeZZCxuKAi8wG2xWvaKZXwfVZdNXwsOQy', NULL, '2026-05-17 22:17:34', '2026-09-17 11:17:55'),
(202, '48e1498a-9e57-4112-b9a5-e05fb74de51b', 'Shiv42fk', 'Shiv42fk', 'elphickshiv8@gmail.com', '+19296173634', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LMXTk6Nexa31f7aO4WbNGeepUcb980ivdL68F5RgoQUuqyyJXSOJ2', NULL, '2026-05-19 11:27:33', '2026-09-17 11:17:55'),
(203, '49392ce3-afe9-46c3-9cbf-74a868c26ce5', 'ShyyShyy', 'ShyyShyy', 'samiyahs.mommy2011@gmail.com', '+18314355459', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-17 20:23:55', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vfhRf4EE5JsFdyBD8TydBe8QD11mSFCBsBGQDuvKCPJrMcpCa8gEy', NULL, '2026-05-17 20:23:55', '2026-09-17 11:17:55'),
(204, 'e453cb94-eba5-4faa-8dd7-f65c44e84586', 'Jacob  Rodriquez', 'JROD336', 'rodriquezjacob86@gmail.com', '+18064423308', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/e453cb94-eba5-4faa-8dd7-f65c44e84586/avatar.jpg?t=1779089311766', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1986-03-31', 1, NULL, NULL, '$2y$10$dKSWLnkE2DTPxcqKQ2wCieNQml2eJVpoarFxC7hV/kXzbVlNnwh3S', NULL, '2026-05-12 20:59:34', '2026-09-17 11:17:55'),
(205, 'be428d62-5246-47c8-b035-e5aac4d4934d', 'genoworth', 'genoworth', 'jonworth06@myyahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$NZzc9ubKKESwUCF.F4IJ/etv2QPdQy4kDyRjjNX1EittmdbhLj2cq', NULL, '2026-05-18 01:49:13', '2026-09-17 11:17:55'),
(206, 'f22ee59b-8a3d-4d9b-ac36-a6a77788c45b', 'AmandaCL', 'AmandaCL', 'dezznutzyomomma@gmail.com', '+16204740650', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-18 23:46:33', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mtCe81KAH224LEBgKfb/7.BrL6R87GPIGmc07gMhES/wbCiKJ5/BW', NULL, '2026-05-18 23:46:33', '2026-09-17 11:17:55'),
(207, 'b0f5126f-12c9-4e36-af9a-341a2d4ff897', 'MazorRocom', 'MazorRocom', 'lasthermen@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vSyXq8uKjSjh/.zGPTzePOuULWZ58fr/D8xejph5vrTb3zciyoNAu', NULL, '2026-05-18 05:47:11', '2026-09-17 11:17:55'),
(208, 'bd6f6073-0b52-4584-8dea-0f0daf4bae18', 'Expert777m', 'Expert777m', 'maxwrinkler@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$i09TYYWyB2v3w.NywnpxT.a00ASphlqx1wR9eRRysoCUYtGKbmdMy', NULL, '2026-05-18 08:15:43', '2026-09-17 11:17:55'),
(209, '1599fd0e-aa40-4244-9a8b-8fec074da8a4', 'LesMarieCX', 'LesMarieCX', 'lisamariewitt03@gmail.coml', '+14173602302', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mYiOPNA2V4pxqoHMM9gPu.zcSv8jQWnPfQajHsD1rAJXd378/1PXK', NULL, '2026-05-18 12:21:08', '2026-09-17 11:17:55'),
(210, '291c99ba-98ef-4701-8404-64eabc213e5f', 'LesMarieC', 'LesMarieC', 'lisamariewitt03@gmail.com', '+14173602302', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mh8w9r.WsdJpvAvXoLVPM.Nal5sG8bn1wdeO8UWmq49i9Fmln7IgC', NULL, '2026-05-18 12:24:28', '2026-09-17 11:17:55'),
(211, 'c66c25d8-2716-4a81-98eb-eaf5b30fb50a', 'VannieR66', 'VannieR66', 'vanwarped1@yahoo.com', '+12109097197', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5D/VnpUuynRgSnHJ1Pi/POzjttNnchMJ3bIxwekMtZm6TOkwFCw3W', NULL, '2026-05-19 12:01:21', '2026-09-17 11:17:55'),
(212, '31dffe0e-c72b-46f1-939f-36777a8d6c55', 'ChrisJ', 'ChrisJ', 'dontbefacetious@gmail.com', '+16209608444', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-19 00:01:48', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$k2w47W7umDr/.rzepgtqYeRk490V0EIyHma2E4FcrBnfLm7vGEDKm', NULL, '2026-05-19 00:01:48', '2026-09-17 11:17:55'),
(213, '8ea79b9f-23c8-4fa8-828b-0ebf87e282dd', 'Mmjjnn', 'Mmjjnn', 'mjneal100@gmail.com', '+18126531635', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZUVR13Bh883OCwlyvUun..kaHgPBABrThhZ4F4SdUzEI.qS96JLyS', NULL, '2026-05-18 15:33:26', '2026-09-17 11:17:55'),
(214, '270ff1c4-427f-4de2-bf1a-6cccb5e98f49', 'Ytlean361', 'Ytlean361', 'nfalcon3612@gmail.com', '+13612293244', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-19 02:25:20', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$voiNK0a35Pt9H9Wuk6FVk.l6yNRD/qA8ITBxhVJo2XbttkHU5.j7K', NULL, '2026-05-19 02:25:20', '2026-09-17 11:17:55'),
(215, '300ee505-7cee-4377-b57c-8107e9c2af96', 'Angee11000', 'Angee11000', 'welshangela854@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8KU0x64LDSnhO38N0dKaFumXWOX75LA7y0o8RUedUMWKZ9JTJXcpO', NULL, '2026-05-19 08:09:17', '2026-09-17 11:17:55'),
(216, 'b7345aff-475c-4d60-bb84-0334e9455559', 'KillRQueen', 'KillRQueen', 'ashleyehutchinson25@gmail.com', '+16412482444', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-18 18:57:30', 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$IS/1PnqnYAnhLiJWu.K2hu4SgiK7TuOjB/T76oLzydTl.2KTcbg4O', NULL, '2026-05-18 18:57:30', '2026-09-17 11:17:55'),
(217, '5b8e1c00-6669-48fe-90ca-06e8fdc7ab5c', 'Dash2662', 'Dash2662', 'dianaprince3015@gmail.com', '+14045617466', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qnOjEkzGx3EmW6SU/uCTQuDtPO65ZAXpSR8vfHaV0c5/dOh6SHp6.', NULL, '2026-05-18 21:27:30', '2026-09-17 11:17:55'),
(218, 'fd555f55-60da-4440-94a8-74a305577e1c', 'Justcase4u', 'Justcase4u', 'claytonjustin456@gmail.com', '+15302186176', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$pPhLAmicKCIDhM0LWQVtu.uZ.oUwNdVDu9oj10E4gCEYcGKjHIIqS', NULL, '2026-05-18 22:20:06', '2026-09-17 11:17:55'),
(219, '41f99fd4-e67b-4820-9a6b-ae245ea9eae3', 'Santti', 'Santti', 'santiagox3@proton.me', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$yixJJzThAXB3dzHwcrqXmeckxCIltvi9YAUdvHEbAUGis4JbvKGVe', NULL, '2026-05-19 08:13:57', '2026-09-17 11:17:55'),
(220, '607f6c51-6266-4b6d-a8c6-d25a656caefc', 'Uhdoor', 'Uhdoor', 'idorevargas656@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4XLOH6MFXVC0MCkWuwRh2.GCsQTPxuXHcX.TaeKOJ5rT4LVeEpLkq', NULL, '2026-05-19 08:15:34', '2026-09-17 11:17:55'),
(221, 'bce37b13-2d68-4020-91db-5d5b4294f9d3', 'Demerytrac', 'Demerytrac', 'demerytracy786@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hDtURc0d9imXukMYwvcEZ.yPJtF2cMSZRFR1sLOBs5aPDHI5qT7Zq', NULL, '2026-05-19 08:38:17', '2026-09-17 11:17:55'),
(222, 'ff09cc6b-fbf9-49a1-b8ec-48614c837919', 'Jenberr', 'Jenberr', 'jenberridge01@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4CwWU4Nq6R8UIKS0I8MvPeF.gOyqzobR6Igl3d0Xri4XwrcfostyK', NULL, '2026-05-19 08:51:27', '2026-09-17 11:17:55'),
(223, '0b35f6da-d67f-4a65-815b-573b99c7ae0b', 'Jovany Martinez', 'afhFcbgcv7', 'jojodoesit14@gmail.com', '+19156919585', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-19 23:32:32', 'United States', 'Texas', 'Male', '1995-05-19', 1, NULL, NULL, '$2y$10$QwgQ2vVTxdeKVX9EOQY2.OAYc7l8zW5sDTMGnDmacnK9ykMTJx1pO', NULL, '2026-05-19 23:32:32', '2026-09-17 11:17:55'),
(224, '45407a5d-e4be-4995-bcc3-ea1a02bd17ac', 'Jones1225', 'Jones1225', 'brandylee2890@gmail.com', '12055441855', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fAqv5/xZ0TOFXWaIIPjkaejIaWpC41RvBR5sCsSSdSfw/t5INQX.6', NULL, '2026-05-19 09:44:35', '2026-09-17 11:17:55'),
(225, '8ca93893-8fdb-4dc6-a737-4246a86f480e', 'debo2759', 'debo2759', 'debo2759@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZHbPvteg3SuYqC0eyBvIve9OJXiyb86cWvgwS0bh.NjhC2E7alf8m', NULL, '2026-05-19 09:54:07', '2026-09-17 11:17:55'),
(226, 'aa5e4bff-b45a-4df7-b6e2-718d590f6afb', 'tairivera9', 'tairivera9', 'tairivera912@gmail.com', '+18502721787', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-19 12:03:16', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zFInNVfQu.HDcZ3w5G0SIOR1R5XJePDCZes7uct4Q.1BFv5JG0kiu', NULL, '2026-05-19 12:03:16', '2026-09-17 11:17:55'),
(227, 'e8e24188-82be-4065-ad56-32968dc91aa2', 'Cycylegend', 'Cycylegend', 'sirusmoss80@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$T.xDOjD7c7qSJ9DZRE69OOsbC8G6r3r6ObYGA90AYu5.4RIP294YW', NULL, '2026-05-19 19:38:25', '2026-09-17 11:17:55'),
(228, '71e08d49-75ee-431b-b60d-c10aaf82264f', 'Kutyna2fk', 'Kutyna2fk', 'robertkutyna@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$v2mXdQjiAH5cg2rTnOg.5ui68aqQArsGz56ANUN9GX1VQHHtne5o2', NULL, '2026-05-19 20:30:35', '2026-09-17 11:17:55'),
(229, '4acc8345-251c-4667-9794-7843b560ee58', 'jbelieve18', 'jbelieve18', 'jbelievethat1018@gmail.com', '+18287292706', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$UkkK2hG/T0X4ie9ZAX7ZjOyBXwLQUnVhz.sDM/hcn4T4r2Dkysfzi', NULL, '2026-05-19 20:37:05', '2026-09-17 11:17:55'),
(230, '3928f49b-3661-4173-ac34-0afaf52521c6', 'MathewMM', 'MathewMM', 'martmatt245@gmail.com', '+12103002276', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Y3ME9R7c3labflJykmygBeGcs.fOLqwpGqj.iG6piy8XPIIJKhSd6', NULL, '2026-05-19 23:10:30', '2026-09-17 11:17:55'),
(231, 'f50bc64f-0cfe-4947-9bd3-9749d684d2e3', 'Boss56213', 'Boss56213', 'jayhermosillo1313@gmail.com', '15622449774', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-19 23:05:43', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6R71VpGBfkuAev1HwQkJSenS8CyOn8ktVB67tZAyd3uxuo3oucnUC', NULL, '2026-05-19 23:05:43', '2026-09-17 11:17:55'),
(232, '703b218a-e30f-4751-b525-55dfb91a4415', 'jojodoit14', 'jojodoit14', 'moneymakingjojo01@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$yk36d2kyVLXI/WiAI9UzG.BJNsMMxZ882gdWLYupUOTArcKV2pd.S', NULL, '2026-05-19 23:39:52', '2026-09-17 11:17:55'),
(233, 'b9b09cb0-69dc-4475-998d-a9e5a91ddca3', 'Kiilauj', 'Kiilauj', 'maliakamalu6@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MopX9fknserKqNmYiQaBbOHnuTTG.CUwmXzK3J5aIuB1YMIpV8DpS', NULL, '2026-05-19 23:40:36', '2026-09-17 11:17:55'),
(234, 'dfd06769-2856-4778-b9ae-3b788ad7bb78', 'Maia1234', 'Maia1234', 'jlc061582@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$yCpGRtc/7gRlDg6LK02k4.C4ZCEZoecY7mF.F/H4ubk.qPfoNzYBe', NULL, '2026-05-20 00:35:41', '2026-09-17 11:17:55'),
(235, 'c470b91d-a71c-4cb7-9493-73fad1379828', 'Megan8282', 'Megan8282', 'maybo8282@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$t40esYcEeXpp9LE7nq/VlOGUsq7RqPYFy1mw2zRpVx9CxjOjJfKPm', NULL, '2026-05-19 23:36:07', '2026-09-17 11:17:55'),
(236, '267c9246-567c-4a36-91ad-2aa790d785ca', 'gamepaneluser2', 'gamepaneluser002', 'johny.freelancer1802@gmail.com', '(892) 999-298', NULL, NULL, 10025.00, 'admin', 0, NULL, NULL, 1, 1, '2026-04-01 09:03:09', 'United States', NULL, NULL, NULL, 1, '2026-04-01 09:03:09', NULL, '$2y$10$22WLh/SMwPn7b5qQToOsQutZg3oEAUi2GITCNODuw0Zxe8630JUB.', NULL, '2026-04-01 09:03:09', '2026-09-17 11:17:55'),
(237, '289b08f4-e616-4441-b2db-38cf7eb510eb', 'heavenly clinard', 'heavenl03', 'clinard.heavenly03@gmail.com', '+14092240315', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1999-09-21', 1, NULL, NULL, '$2y$10$d6dMFYYx9iU/537aMINyIOYlKPGzSCQdOCQVpYjpbmas9ONwg6z7m', NULL, '2026-05-19 23:34:52', '2026-09-17 11:17:55'),
(238, '07a7b7b4-0125-46a2-af9c-c2511bcf03b8', 'Patty766', 'Patty766', 'beggs.jo.1976@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$/mRGgJz.FXUudD3OEQAJyeqjEzle8Ru.atE.VECtRxCE0Gf7N1K5q', NULL, '2026-09-03 13:23:52', '2026-09-17 11:17:55'),
(239, '06ac6278-b7bd-4cad-b654-4a6464c88e69', 'ysaboss08', 'ysaboss08', 'mitchell.ysatis.1989@gmail.com', '+19038515640', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZJvE0C4oF7oN0TI4P8bbrOMSXW0zO4SL4p4bbbnuLmIRAFFEifvCu', NULL, '2026-05-20 04:42:21', '2026-09-17 11:17:55'),
(240, 'db2360cb-aa92-4ed3-8198-2d00123dc508', 'Jayjay13', 'Jayjay13', 'newjay1369@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OQtXmLEdn86LdLW6rtuQmOVPPleaqk5.9aieANB/JNYwIQBZf2WLq', NULL, '2026-05-20 05:21:55', '2026-09-17 11:17:55'),
(241, '214d80ec-bb54-45ee-8179-1d62d408a917', 'GamerMomma', 'GamerMomma', 'dzo06gabie@icloud.com', '+12133354535', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-20 05:36:49', 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sHYl4kjTf72j/47BUIRLwumLUgUWtEejL1KJlY2ybcqi6PFwZJejG', NULL, '2026-05-20 05:36:49', '2026-09-17 11:17:55'),
(242, '6c9d1936-6ed4-4f04-97d5-13f171450cd8', 'Kdrowz25', 'Kdrowz25', 'alvarojara005@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zAfPtBLm3rWJAdFPeyB6Ue4zy/7FEE4n03EJS5TjHdSFiHm9aIxXy', NULL, '2026-05-20 06:11:49', '2026-09-17 11:17:55'),
(243, 'de78813d-1015-468a-827a-4d804af63c04', 'Mcc1987', 'Mcc1987', 'clint85manuel@gmail.com', '+13376618233', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-20 07:33:30', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OzQCSVLWeVFEdv9IlxGZBOFd8ulJF7s7Jj7dbppuZZIP8yZRkV3Xu', NULL, '2026-05-20 07:33:30', '2026-09-17 11:17:55'),
(244, 'a564a8b6-aca4-4bfc-9184-f9e8938b050a', 'mazieb89', 'mazieb89', 'maziejazie88@gmail.com', '+14056919099', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-20 08:16:34', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uRseL4qORWOH73KQKBbLterLIXSEzLYUd1mLgbqVADD3U2WgI99Oy', NULL, '2026-05-20 08:16:34', '2026-09-17 11:17:55'),
(245, '9417fa8f-8f9a-463d-bcb7-6cf1a8dc9068', 'Tyshanna66', 'Tyshanna66', 'cowintyshanna0@gmail.com', '+19283526928', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$9.iqwUfNI8kvZh0bQ.zm8O8IanZXqGHMh2X3P14l.aufdbEf2jO8G', NULL, '2026-05-20 01:04:46', '2026-09-17 11:17:55'),
(246, '923e3fbb-ba8b-45e5-92c5-cb3a27661213', 'jessimae89', 'jessimae89', 'kimmiemcg67@gmail.com', '+16206919099', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-20 11:18:36', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$wuD5ul9XizJRHHhKJOSbHu7NdNKCZ4go/5KPIizRDmnY33F7mL6eC', NULL, '2026-05-20 11:18:36', '2026-09-17 11:17:55'),
(247, '4fdf23ed-6456-42c2-a17d-64d0b5c4d5c3', 'GamerMom', 'GamerMom', 'dzl06gabie@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$a94qKfsIWHOmwIWaeCF32O6X1mETFZOfmsezE4O6D84CSc6hEkMKa', NULL, '2026-05-20 14:58:24', '2026-09-17 11:17:55'),
(248, '5ab0a929-f3a5-40c7-96af-8f3aa0334171', 'Bigbitty', 'Bigbitty', 'craigcharlie242@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DO1pUElrkT6m1xcjdUowhOW7bLZTP19qU4R424TSxD59Q.TW1tmeO', NULL, '2026-05-20 21:45:44', '2026-09-17 11:17:55'),
(249, '04e934ed-0992-40c7-ae85-30d2c5b748bf', 'AlmaLl', 'AlmaLl', 'lopezalma336@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$HMVds9P/Uu1Bv9iZnmLufOdXgeygu0XmeSn57.LNQ/ohkauW4WG9W', NULL, '2026-05-20 23:26:18', '2026-09-17 11:17:55'),
(250, '169722a8-8914-432d-b70f-d99bcbe15bb0', 'Datboimek', 'Datboimek', 'mekus569@gmail.com', '+18705711457', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Um8N4Qm89BoSk17Ugr7WIuw6amha8xeaQxEHzyx1ApiGKVFS7/uPy', NULL, '2026-05-21 01:08:57', '2026-09-17 11:17:55'),
(251, 'ba3cfb0e-d9bf-4d8b-91a1-b535e3b0b84f', 'sapsermich', 'sapsermich', 'sapsermichael@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JxiAMqLpeljMYtsXeG73S.cGVp/F8i98daDY2tAF0.jCXxi2aERGy', NULL, '2026-05-21 04:48:12', '2026-09-17 11:17:55'),
(252, '668a7e4f-e814-4477-8dfd-da35745cc376', 'Niffer', 'Niffer', 'cappurrocap@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7ksQ5/r00NDVGN40p9R8ROk3X3JGIIjnzj.EqfQ.Dhy2WkUqG/S6C', NULL, '2026-05-21 09:17:13', '2026-09-17 11:17:55'),
(253, '754d48ae-2294-42aa-a03b-f9a41d7d6412', 'Coolroy65', 'Coolroy65', 'cougar4life1234@gmail.com', '+12297332147', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/sDxr3mJeVpYlAZN.wuIduaGgAUzWXZtY7z/lFzWgXIh2piJpkyQa', NULL, '2026-05-21 10:03:51', '2026-09-17 11:17:55'),
(254, '69c3b7ec-0c3e-4d15-97c7-058f87ef08f1', 'Ayeefoo24', 'Ayeefoo24', 'papii91666@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xH1mxv52w/TTBC.G7/tJwOBNs7lzYIh6OduY7sOvWXuJ5/YLrZpse', NULL, '2026-05-21 12:22:03', '2026-09-17 11:17:55'),
(255, '8ee63b88-a7fc-40b9-a102-0391cc1d2517', 'Codymo', 'Codymo', 'codymosley76@gmail.com', '+18284605730', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uEpW5hdiS1pnklMY047bZeIaaMeYjKn0nEwpSYD8RbeZOq4iBKfHC', NULL, '2026-05-21 15:43:07', '2026-09-17 11:17:55'),
(256, '9d623b05-9c4e-45d8-96dc-f9612ae34359', 'WhiteTBby', 'WhiteTBby', 'stayprayedup143@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$t./8F867VqcRXdHxio.QkefhtsR43EiB5zWRnbQx1Kwn4a2BRzjzy', NULL, '2026-05-23 14:54:11', '2026-09-17 11:17:55'),
(257, '3ecd625b-52f0-4683-80dd-02b24e86a0f3', 'Kayy123', 'Kayy123', 'kaylaclubb32@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$jIgmzsiYnFZMo8YYl8rRzuwH6d04zsQ4A875NcWtyX0/On/aQ15DW', NULL, '2026-05-23 22:56:25', '2026-09-17 11:17:55'),
(258, '8b5c0ae5-df2a-4001-a56a-62f3314e2721', 'bertaa', 'bertaa', 'zamora.alberta92@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Y0L3iKSY2TS/pM4iZStFjOo1Ad5ExtZc7JT8u8oZvKgQFEsx487WO', NULL, '2026-05-23 23:28:14', '2026-09-17 11:17:55'),
(259, '5ac5e4dd-3b73-4217-9139-52ef4cb23289', 'Bigwhee1', 'Bigwhee1', 'smithstacey19652345@gmail.com', '+12297332147', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$m1eASBrh6ltPIlzHaTIyA.BKRqboTwD4aPWFS8MWcG1YUNp/fp.Pa', NULL, '2026-05-21 23:59:07', '2026-09-17 11:17:55'),
(260, '56fd192f-905b-47f1-8564-f6b55b3a642b', 'alison', 'alison', 'bossesmori@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VfH/BfxZy9BH9UgKWDyJ4.nWYbjj3/vH4bUReW1J4GQ.sWR8s/Wh2', NULL, '2026-05-22 00:37:04', '2026-09-17 11:17:55'),
(261, 'aa0721ff-7dc7-4529-9a5c-218c91c5f697', 'blackwoodr', 'blackwoodr', 'blackwoodrene096@gmail.com', '+17605502914', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8Is73tF/cZ8JOIDh4eXJ0uMLNeBHExyLcQq77nmRuI6ImOyTdS0NK', NULL, '2026-05-26 06:55:47', '2026-09-17 11:17:55'),
(262, 'd87c14e3-b299-4274-a08a-0838024106dd', 'Yoshm77pm', 'Yoshm77pm', 'jmtag34@gmail.com', '+13235957493', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-22 11:02:34', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7MDtWX/fAEgTMcoADpWWMe1wORmgGu7IgqP91AAl2XVOxOmRS6CxO', NULL, '2026-05-22 11:02:34', '2026-09-17 11:17:55'),
(263, 'e08fbdd4-5d13-4ca4-83d6-5bb1c67ed465', 'Koolkyle', 'Koolkyle', 'k1299792@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JqsN9wkUql6K4Y0sYeAB8Ol0ayeMgP8.dEBNjzOS9b.YRbKUeTZ5a', NULL, '2026-05-22 19:54:57', '2026-09-17 11:17:55'),
(264, 'b1f93c71-f71d-448c-b309-19e652108f12', 'Carlosmom1', 'Carlosmom1', 'enjolin542@gmail.com', '+13524532886', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$rZzs8xIOLNPODLXuFr9Yyuuj5iLc43OQlEaGYEOpxuVGxe3HHcAWC', NULL, '2026-05-23 23:31:09', '2026-09-17 11:17:55'),
(265, 'd51a093b-dc65-4c9e-8ba8-0c1cd68a4d7c', 'Topodakidd', 'Topodakidd', 'topodakidd@gmail.com', '+12546409226', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CqZU20RdXLt/G6EywkNe1.OBiTz8iRpOyCUfOCba5Rw2ds9LDqRtK', NULL, '2026-05-22 20:53:20', '2026-09-17 11:17:55'),
(266, '8c9726ec-3326-4f9f-868b-5c0000e1abb1', 'victoriazu', 'victoriazu', 'victoriazupko96@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$rQosVrFeqizFkPvbSx4yBOxYsnrQEgJiV7pQrAH.QhkOZnUw14C/G', NULL, '2026-05-22 22:36:40', '2026-09-17 11:17:55'),
(267, '2c7cf90b-9486-4a61-b2ab-e40e3f2e1e2d', 'Casanova23', 'Casanova23', 'acasanova1127@gmail.com', '18065137242', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Y22.x45F4bEiWmQvyTUxbOQMfBb3M3XJtmdhBUz9IIRX4e54O/Igi', NULL, '2026-05-23 00:16:50', '2026-09-17 11:17:55'),
(268, 'ff28a374-cb5c-44f8-95e2-47b4f7f11965', 'NikkiB420', 'NikkiB420', 'snb71241@gmail.com', '1+3186088966', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-23 00:25:02', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/TkP2mMcxT5Sedvxpb159e6dUZ50sxNvDPemGIT8v/ZZVOhggX5k2', NULL, '2026-05-23 00:25:02', '2026-09-17 11:17:55'),
(269, 'a8626f41-a9e2-4d39-b5f9-9f2ec31f1d74', 'Dday74', 'Dday74', 'dayshane402@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$FhXwpFd9zjTJ8AjUAWLoKeQCN4H703FowTl3eIWvnRVMJY/pmaMO2', NULL, '2026-05-23 00:38:58', '2026-09-17 11:17:55'),
(270, '26b87e94-6e14-406c-9552-73b3d20d7562', 'Valencia  Wilkerson', 'Val426', 'wilkersonvalencia426@gmail.com', '(210) 865-2316', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1983-02-26', 1, NULL, NULL, '$2y$10$sGmyfh25RIIadRNrOk.LCuY95Tjw9BsnyfpkYu33UkxZDVuzaRzaG', NULL, '2026-05-25 11:56:54', '2026-09-17 11:17:55'),
(271, '85603717-6bef-415d-bc86-1f25b6cc0e22', 'rookstia8', 'rookstia8', 'rookstia8@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/yLHYQTgjqIDaDFK97B6Vu7vXHBTXgNNkFlM5h9HXqTUU1cpOSeUK', NULL, '2026-05-25 12:03:31', '2026-09-17 11:17:55'),
(272, '07b391e4-f206-4dcc-95d3-b31cb141d850', 'Sunshine92', 'Sunshine92', 'jessbabi92@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$TjWaphLHmrmvE5d6Z8tj4.VRrNUFHplXR8Q2TNcY9.JUXcCeHjLrq', NULL, '2026-05-25 20:53:27', '2026-09-17 11:17:55'),
(273, '7740474e-3b1e-427b-b31c-c205024dd4e9', 'Stevenmsar', 'Stevenmsar', 'stevensarmiento87@hotmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$e05KGrerLeqIUp0ojuQI/uBFqia2oF8OjMA5rJpBoZ.lfxF7QTyl6', NULL, '2026-05-23 02:35:35', '2026-09-17 11:17:55'),
(274, '8e9fcdec-a5ea-4f08-99d7-5837c410cdb6', 'Chuckz843', 'Chuckz843', 'charlesmyers410@gmail.com', '+17044990495', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MLOPbzISxjejnvdc47uNPuyOw4K6CahS.Uo36fGqJrC8fW8SOH/Lq', NULL, '2026-05-23 02:26:39', '2026-09-17 11:17:55'),
(275, '0ea1a90f-80b5-41f0-a270-8c5445667e80', 'Radish07', 'Radish07', 'redeskimo27@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ip9AuENvddMFQ.pVEiB7buPXKZ9Y2UxEkvNVZvYkpESCQr9Dh6Au6', NULL, '2026-05-26 11:33:05', '2026-09-17 11:17:55'),
(276, '2a184092-d580-4b4a-b579-99ac7eb0099b', 'BettyBetz', 'BettyBetz', 'blessedbettyb66@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/UhYh6qRwd0wQ7VW26uoHui.n5rTSTvQqb44zjgjh/MwvgMtztP3C', NULL, '2026-05-26 16:33:13', '2026-09-17 11:17:55'),
(277, 'bcfb1fac-900e-401d-aea9-052cea11e8f6', 'JOHNISHA POWELL', 'Safari23', 'johnishapowell8@gmail.com', '16615850537', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-24 04:56:07', 'United States', 'California', 'Female', '1991-03-23', 1, NULL, NULL, '$2y$10$0Z9IbWatM4cBqJ8U5x7F4.ttoeXjR9Q/mpL14KtQUQAuB57Jo1MFa', NULL, '2026-05-24 04:56:07', '2026-09-17 11:17:55'),
(278, '8a8e3d72-c25f-49d7-898c-daf56c6463e4', 'Bigrob69', 'Bigrob69', 'rbrun480@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6UsGLz1DZqFaWXS30yae9OP/J1.hWn/gJPXnghpIPxfwlZMDU.S6a', NULL, '2026-05-24 09:48:56', '2026-09-17 11:17:55'),
(279, 'ab50e797-3400-4ec2-8511-51e50d4a6b53', 'Jordan Lynch', 'Countybaby', 'lynchjordan85@gmail.com', '+12525323718', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/ab50e797-3400-4ec2-8511-51e50d4a6b53/avatar.jpeg?t=1779533135959', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Male', '1992-08-28', 1, NULL, NULL, '$2y$10$8zE9MaXprRsIwtyTz/O9XeekqkUVXlk.jbUZnQx3Nv3Ig2Djsc6tm', NULL, '2026-05-23 04:33:05', '2026-09-17 11:17:55'),
(280, '9e5a29d8-dd11-4510-a164-01a98729d916', 'Nathan89', 'Nathan89', 'n.mtz6812@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qY04WbdfI85iCcJOxl0WmeH29FpNUkvCTX3uaZziYCJRz5B43h/ui', NULL, '2026-05-23 07:49:56', '2026-09-17 11:17:55'),
(281, '6e6f8966-4337-482f-b676-4ea98a781725', 'Chill1103', 'Chill1103', 'chill091215@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$IyYQ.bIvRtCoHNt20Cx3YOge0Xhgs1cjU7A7Ojaxbi32YIuRlvid2', NULL, '2026-05-23 11:46:52', '2026-09-17 11:17:55'),
(282, '122717b1-e012-4ef4-a921-0df24d33e204', 'copelandra', 'copelandra', 'copelandrandall9@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$X3u4rbkib4cBnT2KuA8Lb.neUcoRgQ3W2/r7BnbA.Of4cpBrlsapC', NULL, '2026-05-24 21:39:41', '2026-09-17 11:17:55'),
(283, 'fc3f09e8-503e-499a-b0cf-a553e5da005a', 'Boymama', 'Boymama', 'whitleynicole40@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MCjeoEaa1aRE7iGjHFFI5OVBpuKnapZQLkBcq.EJ2he9Fpw1HytSW', NULL, '2026-05-24 21:53:06', '2026-09-17 11:17:55'),
(284, '491441ee-25df-40c3-9809-11ebf598e5b5', 'Billie724', 'Billie724', 'mindblowingvinylsandmore@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$GKLb8tnTW7OjdGMQTMs8euae5/HFeNzzhx0aWdRT7Zh4ptW5AytcO', NULL, '2026-05-24 22:52:04', '2026-09-17 11:17:55'),
(285, '3663d9dc-42ab-44ec-bd2f-9c8762770c80', 'Harricka', 'Harricka', 'harrickab8@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$EmCkW7fHzzEVY63GRv1hB.5aoHLrwOzbPHP8pxHsghi5ERHKusA0a', NULL, '2026-05-24 23:21:57', '2026-09-17 11:17:55'),
(286, 'f220b08a-fe1d-4dc3-b26a-fc3a68390141', 'CrushaWife', 'CrushaWife', 'kimberlyr.0292@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$HeYzgeHrjH44eAnRO1HrWOEq9OcSg73wnyGrhq/I0bJ0e03C.dLuW', NULL, '2026-05-24 23:43:10', '2026-09-17 11:17:55'),
(287, 'd1f4c11f-1482-462f-b822-693dbb77692f', 'LocBrown', 'LocBrown', 'nino60loc@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$79mEllARHeB6aTO4PNALNuUJzfTERUmNUfJeVN8xy1cToaX3nDikW', NULL, '2026-05-25 02:18:29', '2026-09-17 11:17:55'),
(288, 'faf887b5-95e2-474c-8e98-f0608274d548', 'Aluvit8', 'Aluvit8', 'imprettyplease@gmail.com', '17374000542', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$KatO0KgbdF0ViDnjIRP3OOHU1ygyz5o.8x48R2n8LfIDUUJyGvcsO', NULL, '2026-05-25 09:16:22', '2026-09-17 11:17:55'),
(289, 'fe58eaa8-b831-4b68-8e84-df7df43f9d88', 'Jimmy  Johnson', 'Blackie69', 'j4788713@gmail.com', '+18702790729', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Arkansas', 'Male', '1969-10-22', 1, NULL, NULL, '$2y$10$6OIvl6.CYyi7QHpC6CZ0RudFcKWXsMSDWEQqDVVNkZrGySKjnIpxG', NULL, '2026-05-25 21:41:33', '2026-09-17 11:17:55');
INSERT INTO `users` (`id`, `legacy_id`, `name`, `username`, `email`, `phone`, `avatar_url`, `ghl_contact_id`, `balance`, `role`, `is_flagged`, `flagged_reason`, `flagged_at`, `email_verified_by_admin`, `phone_verified`, `phone_verified_at`, `country`, `state`, `gender`, `date_of_birth`, `email_notifications`, `email_verified_at`, `last_login_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(290, '25b633d5-00f7-4fbc-9ded-9703e9a5f5bc', 'Stacy Ruffner', 'Stac88', 'ag4002986@gmail.com', '(423) 315-8640', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Tennessee', 'Female', '1988-05-18', 1, NULL, NULL, '$2y$10$nhEMJWxTfwLWN5fV5qEWbu5aeMkf7qFyA49vK0HMTqGNe2mTbYICG', NULL, '2026-05-25 10:30:34', '2026-09-17 11:17:55'),
(291, 'a98a9fe9-9536-4b60-837c-c9efa2579bc0', 'Goldy2601', 'Goldy2601', 'jlantrip@myyahoo.com', '+19035758114', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qjGjR6t9UE6iVSysPuFY6eGlmcetBxhRZkbi8CEg.ysqDYS94Nw/W', NULL, '2026-05-25 22:41:50', '2026-09-17 11:17:55'),
(292, '86b02c59-5054-4887-9454-b8a0375da3d7', 'Amyss77pm', 'Amyss77pm', 'a.shope425@icloud.com', '+18048446531', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Vn0uH7TDmfBT8BIstZjsPOQ0s1ZhdFjGrx9HWguiLjtNk1d/4MY.G', NULL, '2026-05-26 04:12:46', '2026-09-17 11:17:55'),
(293, '39005aab-fa85-4413-840b-48500d1abfde', 'Youngdrove', 'Youngdrove', 'chillwill2619@gmail.com', '+14302916252', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dx5q5l2aLTmVzRfawNiKmu5miYyUtGeDnsRThs4CKN3TyKirh97cy', NULL, '2026-05-27 03:05:37', '2026-09-17 11:17:55'),
(294, '962362be-c0ec-461b-b769-90dde4d2a2db', 'Amoran223', 'Amoran223', 'allimarie1789@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Apbj8LiQIhdJKY74xZKjsOAF5Z.FEF9KmzXlurvbNZNcctX1.CbYW', NULL, '2026-05-27 04:33:29', '2026-09-17 11:17:55'),
(295, 'c3b92e14-69ba-445e-be7b-05c5a2b92619', 'Yahighness', 'Yahighness', 'desareemoore97@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4.fG3WtOy.AH9mO0UXQL3e.cL52F00EYCCnqOWEPIZU8S087u6TJS', NULL, '2026-05-27 06:23:32', '2026-09-17 11:17:55'),
(296, 'd667684f-7cbd-47b7-962a-9542f43bbbf0', 'PayNonsens', 'PayNonsens', 'paynonsense@gmail.com', '+19517553943', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$rsm/8oUPvrLanPQh4nSf8ew/FoAHYhec8WCc4s/AJ028qdXnPJSb6', NULL, '2026-05-27 20:57:11', '2026-09-17 11:17:55'),
(297, '941933d5-7660-40ca-91dc-2a0d75dcfb48', 'Cdubscc', 'Cdubscc', 'cclovescc5@gmail.com', '+15308139435', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RaSdF1lnzLWf15aLrwpiwejt0OFrsHzcMOgj5fEatw0Ne27jj.GUO', NULL, '2026-05-27 21:06:36', '2026-09-17 11:17:55'),
(298, '14290a1f-a5ed-47fb-905e-8a5a3342ca8f', 'Shawn Hinman', 'Hinman87', 'hinmanshawn487@gmail.com', '+16058575317', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'South Dakota', 'Male', '1987-01-17', 1, NULL, NULL, '$2y$10$ppIJ/itC8XDxweDMIWgvuuRPfKS5UNP9ZyWcHtXlWa0aFnnrd7BuC', NULL, '2026-05-27 22:26:03', '2026-09-17 11:17:55'),
(299, '66b918cc-3bbf-4345-87b2-001547f9d526', 'Mmcleod23', 'Mmcleod23', 'mcleodm1101@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$npthEeySOmgdKm1kXp1o0O9TNGxLczK0W10YEbTz6VYedzYK0Bma6', NULL, '2026-06-04 22:16:22', '2026-09-17 11:17:55'),
(300, 'cac06b05-8671-464f-bc56-00eca9efce54', 'Mmcleod44', 'Mmcleod44', 'mcleodmelissa1414@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Wsjo30z7qs08qLn1AyDrAu1exxUal4zg/VYs6aYWXt3ll/oZZ1C.G', NULL, '2026-06-04 22:16:44', '2026-09-17 11:17:55'),
(301, 'f442a2cd-5863-4c14-9aeb-b195189333f8', 'Mmcleod4', 'Mmcleod4', 'krazyaf100722@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$FD2TxlxZJPI8YjFkPtl84.qd4BV.js8bj.oi6A.rpkWi8j.BAfTgS', NULL, '2026-06-04 22:17:02', '2026-09-17 11:17:55'),
(302, '2b8f905d-c4f1-4ab4-b83c-17a281f3e8ff', 'Wondergirl', 'Wondergirl', 'coffeyjess0614@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$D3ZOyFaZ/5k/gUVUjlyYS.JvofLyS7ogRM.un0oYEGADWspUHyTGO', NULL, '2026-06-04 22:27:21', '2026-09-17 11:17:55'),
(303, 'dc280568-ae33-4f2a-bb20-c58e8296e199', 'Pinkstar14', 'Pinkstar14', 'ilovechrissanchez@gmail.com', '+12102543916', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/dc280568-ae33-4f2a-bb20-c58e8296e199/avatar.jpg?t=1779954276859', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vPlDDG11j1YQ1RuMvXqCQu8DzZk8zSPvHfxS8qmeZyf11hBq.cOPW', NULL, '2026-05-28 01:39:14', '2026-09-17 11:17:55'),
(304, '7a1f4f70-642a-4279-b0fb-8f1c7df7dcab', 'Jesshowe', 'Jesshowe', 'krazybeautiful2322@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$jijI.6pK7tJtYKfH6e0qMu27Mp4/WmR5y5ot8hkmPPEAMGH7v1NsK', NULL, '2026-05-28 12:41:50', '2026-09-17 11:17:55'),
(305, '5fb011f6-164b-4f89-9989-20c4d95a9b1b', 'BeautifulS', 'BeautifulS', 'sgamequeen@outlook.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$cSEwNQt70YazoGUVt6wNxu9eATHogt1G30RfPGLi46nZp9uyVhona', NULL, '2026-05-28 16:52:07', '2026-09-17 11:17:55'),
(306, '53868d16-193e-412c-a9ee-e27b2fa2346a', 'erikamagan', 'erikamagan', 'erikamagana384@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$b6GrOtkVq2fIHlll9bUi2Ojhnsc.H0QsyxgnJbFdiYt4eBp3WFDDe', NULL, '2026-05-28 17:38:03', '2026-09-17 11:17:55'),
(307, 'feeabd27-be3d-4c0c-86c1-dd8ec0de4f18', 'Kristy777', 'Kristy777', 'zlsr1995.2@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7LBjqYKRnG3FAQhyWrpmp.cx6qQjfXb3mwQy8CYZZtMB1NYe9pBcG', NULL, '2026-05-29 01:11:15', '2026-09-17 11:17:55'),
(308, '1a2f4fb0-c95a-4931-a8be-c4c1942979d3', 'Emr420', 'Emr420', '1cwgemr1dwbjbs@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$jFdLV2JlkSCmNt8M4u3gWeyyfd9nFoSqS.oMtWpkBJxiHKlW1j1Fu', NULL, '2026-05-29 13:42:35', '2026-09-17 11:17:55'),
(309, 'e8a6b2e6-b934-4eb8-971a-618dac02f047', 'Emr42093', 'Emr42093', 'erinadam51622@outlook.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$oDCteVxjzgiEQSmNTONJCOC2d/ARFlCtkWyTCxE1AyypA98wxIQxK', NULL, '2026-05-29 13:43:06', '2026-09-17 11:17:55'),
(310, '3dd5eb7d-e48a-4fde-a961-d5ce6e2b019d', 'Emrabe', 'Emrabe', 'rideordie111220@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7/9.RIeOVivlpkMaCoIpv..xKvOCpOw4UYcUYeGLKCnsm6P0/J1J6', NULL, '2026-05-29 13:43:55', '2026-09-17 11:17:55'),
(311, '50adfe05-e9a8-44ad-ba68-f8d4c47dd08e', 'jokerloc16', 'jokerloc16', 'jokerloc16@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$E0Ie45/m5b00ZtMz.o8Hruts7Z3UL9ua0vzZKoEXjyPm80QY/bH.O', NULL, '2026-05-29 16:46:18', '2026-09-17 11:17:55'),
(312, '90c74f44-e927-46b2-bd9d-5745b67e1350', 'kingjokerl', 'kingjokerl', 'kingjokerloc3@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zmUvr96QFzMIzwK5KBz2aeV84DSNtpZmpNbi4e3bzDE1jm.C85.8G', NULL, '2026-05-29 16:46:40', '2026-09-17 11:17:55'),
(313, 'd37afc62-1662-40e3-aaf0-9161de72084d', 'Jacklyn7', 'Jacklyn7', 'jacklynwarren7@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZM3Lwr71w.eUGK9zF.ceVeiZbVMqAZypuFHjSDDcMbs0t4NXrLvi6', NULL, '2026-06-02 18:03:23', '2026-09-17 11:17:55'),
(314, '7dd43ce1-be3c-449a-a992-b15a559defc1', 'KingRudda', 'KingRudda', 'donpinder4@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$840N7kPpg/CO2uFPFohj8u7ivq5MLi6R2OXuAu9XYVNfyGGEX4Bna', NULL, '2026-06-02 22:57:54', '2026-09-17 11:17:55'),
(315, 'c50d458d-ddf8-449d-a292-67d12e058405', 'Tyrisha79', 'Tyrisha79', 'typarker4@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$b9eYdzAxR9Zsp9uFpypVeuIQgvtD4SXMwKRuTb2wXRcX0WxWgQPGi', NULL, '2026-06-03 12:23:07', '2026-09-17 11:17:55'),
(316, '8f396178-ddcc-4690-b160-869ae3130784', 'Armando Gutierrez', 'Malong', 'malongdeeznuts@gmail.com', '+13234747224', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/8f396178-ddcc-4690-b160-869ae3130784/avatar.jpeg?t=1780102688007', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Male', '1995-06-02', 1, NULL, NULL, '$2y$10$MfcALeEWuNYuzaHglqrtQeKkzxE6YKlwNdnjYSoGqzZbQAjmcKEHu', NULL, '2026-05-29 18:53:36', '2026-09-17 11:17:55'),
(317, '43a101d1-4235-47cb-8144-7a34d49579a9', 'Kelz4184', 'Kelz4184', 'kelz4184@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$9DGVEQFaYhXshaRCZ6fBxe3F9o0g2DuI/L9h6Q0Nh0QgqN.uXG/.e', NULL, '2026-05-29 20:09:58', '2026-09-17 11:17:55'),
(318, '374fa4f5-b957-49fd-b94b-055137436f47', 'Kelz8441', 'Kelz8441', 'kellzandjace@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YbKH0ZVHbvdcdbL5sYZphegljXed8qiq3CaWVeGi54C1CGyn8.9dS', NULL, '2026-05-29 20:10:32', '2026-09-17 11:17:55'),
(319, 'ea1eea08-581e-4a30-8acf-190b4f75c83e', 'Kianna Bogan', 'kiaudrice', 'kiaudricequeen@gmail.com', '(425) 530-9798', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Washington', 'Female', '1997-09-19', 1, NULL, NULL, '$2y$10$n3wYHuoa3BeuJm1E3t5.BOK3c4h3KXlQJNmU02u.gw/Csw.ZOyPfu', NULL, '2026-05-30 00:41:02', '2026-09-17 11:17:55'),
(320, '845a76d1-a94d-42d0-8a53-98469417b6db', 'tdsanchez', 'tdsanchez', 'tdsanchez420@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$opqVJ2HoptLXmDCzXLUQfOryaYbV44J/uS3YbcjYQB.pdn3gWXpam', NULL, '2026-05-30 02:41:32', '2026-09-17 11:17:55'),
(321, '13d1b5fa-3620-4798-bda3-98a333fddffa', 'jenterkin6', 'jenterkin6', 'jenterkin6@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JGAotxrkXQwyUaqI8X4paeAsSBsEb3VYugoyKUiOk5j4XEVm8vqUa', NULL, '2026-05-30 02:52:36', '2026-09-17 11:17:55'),
(322, '9b023e09-29fc-4ce8-9b87-a65648c0b4da', 'jenterkin8', 'jenterkin8', 'jmoneyjmoney1985@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$rtrawLziyRYDBYMnwgZb2.f/UrPhWpjAOwBqxJ.RuWMdUXcCrThn.', NULL, '2026-05-30 02:54:51', '2026-09-17 11:17:55'),
(323, 'e3dc1945-9a2e-4899-afbd-995204d8b801', 'Xxosucio', 'Xxosucio', 'xxosucio@gmail.com', '15627095344', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sf0fECCbjBgKH6/ck0ROA.pTMCcymEZ.7FqRuXxZk6E8UKYDmYeYa', NULL, '2026-06-03 13:44:19', '2026-09-17 11:17:55'),
(324, 'e06c4d2c-0335-4126-9277-ad1fcb7387c1', 'Nixx408', 'Nixx408', 'love38music@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RjZJNTfc9zu59CfflbIOfOXej7Iedk6EAiOQkJ/I4psm4AWsoH8z6', NULL, '2026-05-31 04:48:21', '2026-09-17 11:17:55'),
(325, '358bed6f-5555-47a6-81a2-f557bf6ec031', 'Nixx0427', 'Nixx0427', 'hockey408@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZlSeYiQfW1ylsxaKThyeyuUursJzWMUiuhtKm1288IDeH8mLCEWQa', NULL, '2026-05-31 04:49:11', '2026-09-17 11:17:55'),
(326, '2ca04668-7b92-4ec1-8793-670f22ad2540', 'Nix8282', 'Nix8282', 'smithgrecu0427@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$3Y/OXRkBrxN7uax0cXIjCOZ32YoznKW6vzXlgrxBUEViS9oyXBupS', NULL, '2026-05-31 04:50:35', '2026-09-17 11:17:55'),
(327, '5efba805-1221-4481-81f6-e96f60bb1c88', 'Misty  Gibson', 'Misty03', 'mistygibson27@gmail.com', '+15128458987', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1982-03-03', 1, NULL, NULL, '$2y$10$ES9zPdHXife73HahBHhFBOYK0RhE6jBcgRU6EJ9uN9tzMNow18iSK', NULL, '2026-05-30 23:32:29', '2026-09-17 11:17:55'),
(328, '9c61dd91-51c8-480c-9a43-947d61adce3f', 'Pmcrewswl', 'Pmcrewswl', 'scottwaynelatsch@gmail.com', '+18502885562', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8f126Or/q.S44ZmQbEVPOOtWdaxN14oIiitlNTWrBKglbYRH19nwS', NULL, '2026-05-31 09:13:41', '2026-09-17 11:17:55'),
(329, 'f6c28025-a0a8-4d88-b3e0-b2a8411ee240', 'Gill526821', 'Gill526821', 'goodley821@yahoo.com', '+14434666377', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$WnVSiPnu4xzVxbITHDwlQeEAa.nH/iB4slDUS04qI6YfpLMGcB63a', NULL, '2026-05-31 10:13:01', '2026-09-17 11:17:55'),
(330, '7c3d0dc6-4fbd-4686-a5c8-958a644e6939', 'liliavalad', 'liliavalad', 'liliavaladez79@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0oyXRauxA2z99IpvEi5hv.1Msx4.GjWcGvJkk8nvyvMPGOWrYq/8.', NULL, '2026-06-01 17:38:08', '2026-09-17 11:17:55'),
(331, '17470a3a-3cf2-445b-9704-b6459b36aa52', 'prettygirl', 'prettygirl', 'sweetsn860@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$kN3Jd3dHK.l.eHZz9R2ZQexHYIa6H8zJOHRBkzf8TjbW15FNOZnHS', NULL, '2026-06-01 18:44:19', '2026-09-17 11:17:55'),
(332, 'b934bbe8-8415-4596-ac4f-e1980408f5da', 'Edub84', 'Edub84', 'elj6584@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2mtg03mwt2jWVWsYMZdlSeRbB2Vsj5HyK4rEqOWTTs5aU9hUdS6nu', NULL, '2026-06-01 22:29:25', '2026-09-17 11:17:55'),
(333, '34470ec7-376e-4ac4-a970-0263d715cd77', 'Edub8469', 'Edub8469', 'vvsdiamonds84@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SLlxMDAvBAMO31X0KQjBwOol3WcWIF.xt21Caqn3B470j5z1oE12.', NULL, '2026-06-01 22:31:00', '2026-09-17 11:17:55'),
(334, 'cf310ce0-48d5-4500-9413-e6ca53deef6f', 'Edub846969', 'Edub846969', 'johnlexie28@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$w0vSTw.t8dNS4EQp7MXyQefkMLBha51I3aDLOh5QgvbVSQZqoLN.W', NULL, '2026-06-01 22:31:33', '2026-09-17 11:17:55'),
(335, '0eb28fe7-420c-42b4-b472-53a727c09e3e', 'Mygirl6969', 'Mygirl6969', 'jamara.friend@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Q3A66ctdOongBBrN5p.dAurlokvy7VaOdUUKhSpFHXpNiqU4Z1bJG', NULL, '2026-06-01 22:34:05', '2026-09-17 11:17:55'),
(336, '69ff5c4e-fe79-4779-94ec-db065999c107', 'lisa1177', 'lisa1177', 'lisafrutoz1177@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$UlA6i1Bu/wkVwr93qE0nMuI67nhouvUjvB70YoI8QyP3H24Lpi5T6', NULL, '2026-06-02 00:49:41', '2026-09-17 11:17:55'),
(337, '8f7b7876-d3f6-4f1a-bd4d-180647f1a896', 'lisa117743', 'lisa117743', 'lisa117728@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$590rae54cHAuOAfVfLYcQunWxNCdG30O8dlsaa/yPfnIK6ujM4/xK', NULL, '2026-06-02 00:50:29', '2026-09-17 11:17:55'),
(338, '99a72668-6aab-4d3d-a6c1-beae2769b581', 'lisa117744', 'lisa117744', 'elizachavez117728@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$bvn3C78oakfZUIBB2lwHF.W0bmKKgf/GPK0Ga.3WeHpjrmNywYo1i', NULL, '2026-06-02 00:51:15', '2026-09-17 11:17:55'),
(339, 'a49631b6-7074-408f-acf8-a06f41e96c6f', 'Eyebook', 'Eyebook', 'eyebook0@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$FV9D12I8.oBRNE6ITs7CoexItdMTG5AxIlZLZBqs70a9cB/iE7Fne', NULL, '2026-06-02 13:53:22', '2026-09-17 11:17:55'),
(340, '1545211d-65e9-4728-a3da-f761a11900bd', 'Eyecon', 'Eyecon', 'eyebookofficial@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/SZ964pAuKiQDk/BLlcfXOwt48G9aw04GtVrXc.Xay0IQ0RgHuuDK', NULL, '2026-06-02 13:53:56', '2026-09-17 11:17:55'),
(341, '45d5d317-3ff3-4d49-8743-8187ceef2e17', 'Bthomas893', 'Bthomas893', 'tdsllcbobby75@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CXkUg7r2.0gnJHygl/pCWu2hpfkY3JBK9Bpxqpsirto6XDhQkJIem', NULL, '2026-06-03 14:53:50', '2026-09-17 11:17:55'),
(342, 'f5195e0c-54f3-483f-a84c-9f448989b6a1', 'Bthomas133', 'Bthomas133', 'thomasbj8937@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$UxLfcEhEax6IAXshivkyM.amiRdGq2tD1.HhDjeDVq290hfVMflim', NULL, '2026-06-03 14:54:38', '2026-09-17 11:17:55'),
(343, 'f0880f54-ca3b-452a-b93e-d089023d738e', 'Harmony Hopper', 'Harmonyh', 'harmonyh2380@icloud.com', '+18312474446', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/f0880f54-ca3b-452a-b93e-d089023d738e/avatar.jpeg?t=1780431873069', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Female', '1980-02-23', 1, NULL, NULL, '$2y$10$l6JMrK7Nl9vJU2DwRDahY.c2p9RMz5LBNg6q6G37I5IV/1WaUTLoa', NULL, '2026-06-02 14:17:28', '2026-09-17 11:17:55'),
(344, 'ab77dc55-5a20-4f34-ba64-48d7889147df', 'Bthomas197', 'Bthomas197', 'aidasantossantiago@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$U8Wmt5hhZLYZi4IXGJqPqOKx5rBMFN5iZRNa21g0vri1dTyaVis.W', NULL, '2026-06-03 14:55:17', '2026-09-17 11:17:55'),
(345, 'ab46f4af-d368-43b2-9358-13fed9cb44f1', 'Bthomas75', 'Bthomas75', 'tjoe27012@gmail.com', '+15054134180', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$KD4KMLT1GxXnYrcWvUykluBYdV2SyyGY8CPUN2JF1Zpt6h18xzHqi', NULL, '2026-06-03 14:53:07', '2026-09-17 11:17:55'),
(346, 'e3f5af2d-72b6-4e5b-8e03-4a927f3206d1', 'Janie09os', 'Janie09os', 'ljdixon2222@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tryNBqTbFFvu4T0ovnmC/OVfSN4mCaBksOt84D/iryzzCucft8hdK', NULL, '2026-06-04 05:39:36', '2026-09-17 11:17:55'),
(347, '03873753-5d13-4b90-b138-305e905a5341', 'Camsmom916', 'Camsmom916', 'hayuhay504@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dPXQKtaAkJxAwuFSzKI7w.kBrnAk/KuEowz70cUPeOfw/KTqDB1Vq', NULL, '2026-06-04 05:48:14', '2026-09-17 11:17:55'),
(348, 'ee930f8c-49d6-442c-a236-d8e62ea9fe8f', 'desire2544', 'desire2544', 'beautifuldisarray33@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8WYX9q8xVr73L3Vp7hcfH.OHtlCrowmrtPoaGNXOJ3kxCgkjvIo8W', NULL, '2026-06-04 17:32:55', '2026-09-17 11:17:55'),
(349, '1720738a-7dfd-41ca-8284-8ac97d943bc0', 'desir254', 'desir254', 'dh254@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$UaSqrZZ.FrBcWsBv2hIH9ucCeLOWYvSWI/kLtTWWhc1Z0sQUSqvhe', NULL, '2026-06-04 17:33:30', '2026-09-17 11:17:55'),
(350, '49498a8e-163a-4606-b984-0c0069e9dec9', 'pmfreddy85', 'pmfreddy85', 'pmfreddy1985@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$T4ctSNiktAbbQjoqHayjUez8FMjCeRawiDn7sHoMBl5yMgbHAl95S', NULL, '2026-06-04 19:13:33', '2026-09-17 11:17:55'),
(351, '99e702d5-8aa7-41d6-b661-36ce204d1830', 'Desiree Harwell', 'desire254', 'desireeharwell254@gmail.com', '+12542295252', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1985-08-08', 1, NULL, NULL, '$2y$10$0JkhQ/wnwNJToLTAGhBYuuZDX8LvZlhzsqd.mmILALGekpJUvMMwu', NULL, '2026-06-04 17:32:23', '2026-09-17 11:17:55'),
(352, '742be7c0-fece-40be-aae2-1a98ee6eab37', 'Queenbe251', 'Queenbe251', 'geminicburton@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8bYeVc5z0RCoLLydkx1TEOVKi.CgYR1viiU0R2mHQMfBSCSUCTuzW', NULL, '2026-06-04 20:56:05', '2026-09-17 11:17:55'),
(353, '52e10e85-3048-44e8-b2c7-3976548b1839', 'Queenbeee', 'Queenbeee', 'geminiburton6881@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5/KI6Iqj2vT7fx6061W4mO1/VWf3i4UKt99gPRuh5PsaRgpc.Qbpa', NULL, '2026-06-04 20:56:35', '2026-09-17 11:17:55'),
(354, '32f07481-e2f7-4f8a-ae89-b227089e9bf8', 'Queenbeeee', 'Queenbeeee', 'blackismymoodtoo@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$a8YhcvnPn1KuPf42.xnzouMB6hjFwE.bDWMvsxsi63jRaqc2EgULK', NULL, '2026-06-04 20:57:11', '2026-09-17 11:17:55'),
(355, 'f8c00f34-db62-46b7-ba01-8a2cc2fcb94c', 'Kdru26', 'Kdru26', 'kdrurymjk26@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$XSi5j1yjd21ZLp5q3qTyZeqJsAD2rYmebqTx80kEX6HxR6GkM1Wr6', NULL, '2026-06-04 21:37:54', '2026-09-17 11:17:55'),
(356, 'bc1ca838-456e-46c4-8f06-38216e1790b5', 'Crystal Burton', 'Queenb251', 'burtoncrystal81@gmail.com', '(251) 513-9426', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Alabama', 'Female', '1981-06-08', 1, NULL, NULL, '$2y$10$gjnU2Wc6J.QheQWLf7haI.Dxima45MKAeC68r.dV1pJd2Pv6XQ2ji', NULL, '2026-06-04 20:55:20', '2026-09-17 11:17:55'),
(357, 'dd11d7bf-3f20-4f70-b863-8c2ae49e7d68', 'Kdru266', 'Kdru266', 'kdrury2193@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Of3.Zvwzc2McT9Er.QzVNO3B5mJMnMi0yS1S1f6uMT9oPV1PNfuve', NULL, '2026-06-04 21:38:30', '2026-09-17 11:17:55'),
(358, '652c2202-59de-438c-9857-4d835fc3b1b8', 'Diamond90', 'Diamond90', 'diamondvvs00@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Q./IGcgLIS91DgIXSk1Z4eLV3JTNOAJWfDFVGpOIh5Ympdy/ueBLW', NULL, '2026-06-04 21:51:20', '2026-09-17 11:17:55'),
(359, 'df904d07-2788-4ce2-8292-eb64a19a74e7', 'Diamond112', 'Diamond112', 'buddhastwinn2020@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YASIZR84rf8C1BiLsreVmeBrW5V4F5nReMRhxJgjvH3hCXtsF4pkm', NULL, '2026-06-04 21:52:19', '2026-09-17 11:17:55'),
(360, '500f5fd5-46a2-47a5-b436-36eeef1f5723', 'Stylezzzz', 'Stylezzzz', 'stacyfultz1973@gmail.com', '+14124301521', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$nw3EHXrTVyIguaNmI/8TuegHRPuBY.qK8GhyCWsPtFvsrxDbc.4v2', NULL, '2026-06-04 22:50:52', '2026-09-17 11:17:55'),
(361, 'fae37b4f-c1b9-4e52-b45a-25cb6368dbb0', 'Hrusovsk7q', 'Hrusovsk7q', 'hrusovskytj11@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$AYnqFB/MDEXglZDcno0xRu6VuSd9m0zy7cOo5VLFyp4fECvDpMRl.', NULL, '2026-06-05 00:52:49', '2026-09-17 11:17:55'),
(362, '2907d401-058e-408c-8445-549a609a8d50', 'Mrruden', 'Mrruden', 'randorude@proton.me', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/gfZu0gR9nIh6xcpB1Tr5u.V2T1JeLZ8bK8pxNxr3RRDV7ME3BFKS', NULL, '2026-06-05 05:01:21', '2026-09-17 11:17:55'),
(363, '867f6002-93b4-4310-ade4-a65d16cf4368', 'Mrrude', 'Mrrude', 'randorude@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$gOIpuYPeXC7FC/E2HKHvj.mdot/WNSPSkyGIILfIPS.kv2CEJ7EKe', NULL, '2026-06-05 05:01:53', '2026-09-17 11:17:55'),
(364, 'd8129f3b-2ac2-4624-8cae-776c6fe15a7b', 'RandoRude', 'RandoRude', '2dope4dis@proton.me', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$FulaojE1FioXyU9iSyr7m.pBIoSPy4uFxvn4K8enli2mZPkWMs2ti', NULL, '2026-06-05 05:03:41', '2026-09-17 11:17:55'),
(365, '1f2277e4-b67b-4cc1-b94e-d71f0f0ae54a', 'SauliGot', 'SauliGot', 'rfarley9213@gmail.com', '+12142269921', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$kN9N1Ay1glj3tM1QL7XUteoEKOvTgUN5a4Hrgg.hJSOZuMkb5Nm8.', NULL, '2026-06-05 05:04:55', '2026-09-17 11:17:55'),
(366, '2ceeb4a0-da4a-4eb9-9038-77fd3e37c9a2', 'Jv1719', 'Jv1719', 'juddyjr03@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JpdSmqhQtFQYKPXsUEWGheS2sSs4IFximAAqU5h.LaEt2C1ercRE6', NULL, '2026-06-05 06:27:00', '2026-09-17 11:17:55'),
(367, '36d5e587-4083-4590-a546-6742ceed9478', 'Jv1719xx', 'Jv1719xx', 'juddyj8623@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$3vTMLSz75JQHKcvqq/10neK8QdmYZd.stu.tZJ6w7MhS0hwGSrg1C', NULL, '2026-06-05 06:27:31', '2026-09-17 11:17:55'),
(368, 'd0055fdc-a91e-4ce1-b342-6c93cf3875f1', 'dtlivingda', 'dtlivingda', 'dtlivingdadream8795@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$KiI3G1WhFw/QFfSM9XJQ/eqMo9EobZueGLOviSTMWQefqaFj5IpTC', NULL, '2026-06-05 13:35:56', '2026-09-17 11:17:55'),
(369, 'a49e03ea-09a5-460d-9853-1b29d652bfea', 'Deebaby98', 'Deebaby98', 'deedee5oh3@aim.com', '+12093553274', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$TSFT4pu7obzCg8TLi0Q46OwyZNCFS59bANjRvaljldueCizYiippq', NULL, '2026-06-07 15:24:43', '2026-09-17 11:17:55'),
(370, '06136ba8-859a-4aac-b1eb-d62b5d93a51f', 'Joshua Billips', 'Jbilliz90', 'joshuabillips35@gmail.com', '(336) 426-1754', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Male', '1990-09-19', 1, NULL, NULL, '$2y$10$PxmuwOEXX7c9DUcVpAGIauZdNWeI90FslU7bn9AgA02UufVnmPxLq', NULL, '2026-06-05 13:55:13', '2026-09-17 11:17:55'),
(371, '34b34386-3571-4e0a-87f4-8472f85f6ee4', 'Jay998', 'Jay998', 'jarvispennix074@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$IFeFl7EXP5H1HT12swQa/uyrKcFCWQORoqKAtkJtz3S55ypFKfmJe', NULL, '2026-09-03 15:22:11', '2026-09-17 11:17:55'),
(372, '3cd5de66-7781-431a-b734-2a7c8690615d', 'Needcash', 'Needcash', 'clemson4lyfe247365@gmail.com', '+18437691119', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$oP5Pnc0cYk7IpRfkMCKIn.6e4k5iEn9YyorsYd2fUN1GYCNUtsIeO', NULL, '2026-06-07 15:40:32', '2026-09-17 11:17:55'),
(373, '4e726941-f00a-4143-8234-411c5556de35', 'Jessicca  Herb', 'Jessherb', 'jessiccaherb92@gmail.com', '+14847692981', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Female', '1992-09-01', 1, NULL, NULL, '$2y$10$y5o8vdHv6BxvT8pNSFHpQuaLe2CFzDXA/h9qveL5naV/P3a7eVMCe', NULL, '2026-06-05 19:53:09', '2026-09-17 11:17:55'),
(374, '62c8fa93-0e6d-467b-ba64-b3e74fb1ee30', 'aaron7018s', 'aaron7018s', 'aaron7018stacey@gmail.com', '+19804374306', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0/bABYJor6u.QD69m/NaFuUQYQnvy4hPR73VvuQvjjdld2.qPHIve', NULL, '2026-06-05 20:17:40', '2026-09-17 11:17:55'),
(375, '2497f9fe-fd98-4837-97f4-b5d229d50d0b', 'AstaraJad', 'AstaraJad', 'dawncoogle@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$G7uMUAsSwqvG8yQFyHb7..LZ3YFCX6MCuhrZXb8BzmgZwE01lC3ES', NULL, '2026-06-05 22:17:32', '2026-09-17 11:17:55'),
(376, '4e6012d5-39c8-4e18-8d06-124aa79c780e', 'AstaraJada', 'AstaraJada', 'dawnmaycoogle@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0a/CWwkpZbC7.ALDy6V4r.VzcbbZSbAtfm9zye4PpSvFGHFBICEWW', NULL, '2026-06-05 22:17:45', '2026-09-17 11:17:55'),
(377, 'a6141a68-02b8-403c-8a49-cc61c9495f74', 'AstaraJade', 'AstaraJade', 'dawncoogle2@gmail.com', '+12706172908', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$iqHzP1YfCxf3yDYo8PWGO.5Ri49XrL9NgyeECwbHIA6M.RED3cxIy', NULL, '2026-06-05 22:17:07', '2026-09-17 11:17:55'),
(378, '37d2317a-29a4-4f99-921a-43769c31fdf5', 'Hgable12', 'Hgable12', 'hgable1992@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$eRMJT8IaLKlmWCW3OoyflezC8eUiHYon/J80dgtnq1MDtfTnfFIJS', NULL, '2026-06-05 22:54:54', '2026-09-17 11:17:55'),
(379, '761efbc5-72c6-4494-a692-8b3449d08c30', 'Hgable53', 'Hgable53', 'haleygable39@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$QDdchWYrigeGBhJ40nwJqen3ey.G6xpM3kMPI7mXTdDKOIuNr30ku', NULL, '2026-06-05 22:55:23', '2026-09-17 11:17:55'),
(380, 'e3d35562-8531-4721-8140-8256c790c03b', 'Amber123', 'Amber123', 'amberhyder267@gmail.com', '+16783280486', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$3t7HTLUHE00KcdmKm0aCqOnGtDOTRd2n7VXCWpfRODnt7aYXP0gau', NULL, '2026-06-06 13:05:57', '2026-09-17 11:17:55'),
(381, '245c62ba-655f-4415-85ef-5fa292a33262', 'Meybey85', 'Meybey85', 'meygant85@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5dL5/po9NpqNslx.NUR1xOb2Q1y1ekAVBKqMDVBpkMx1fSEusp4ya', NULL, '2026-06-06 00:23:11', '2026-09-17 11:17:55'),
(382, '38a8f724-db08-47b1-96c6-b54a149d5315', 'Meybelle', 'Meybelle', 'meybelle85@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$.ssSXHDio7TOMKsi2LzZu.T7/e0Z3.kgRU7/S50z3jOgGybCsFoFW', NULL, '2026-06-06 00:25:21', '2026-09-17 11:17:55'),
(383, 'd3653de6-7955-47f5-bea7-fcbc43626345', 'Meybelle85', 'Meybelle85', 'meybella85@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$BM9b3v5ecgG6gXEPkIuJOe948d4uETwotW2vJY.MjrNI5JfDYXgYW', NULL, '2026-06-06 00:28:37', '2026-09-17 11:17:55'),
(384, 'ee84585f-0b84-404a-bafe-605fdb4e5b37', 'PppArker', 'PppArker', 'pamparker811@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$9IdXRf8cj80JqDxxhyee6O21bqbzPZ.vdOZzcvBBWnrp.l2mdMbQK', NULL, '2026-06-06 01:12:59', '2026-09-17 11:17:55'),
(385, 'ad94ed24-d607-405f-8958-234b510306ac', 'Pamela', 'Pamela', 'hannahpamela420@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$03bxTqt1K4mQCopPso2pTe/1uqofANmQEHk/UwzCLjBWC1Q.0GTuS', NULL, '2026-06-06 02:59:24', '2026-09-17 11:17:55'),
(386, '716628ad-2284-4119-96bd-72a5e5bc9d1a', 'BillyQ', 'BillyQ', '420billyqueen@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$AF39rHj3jeL4Q8hvEH3/ju60SRj5fFpZs5Lf7AoTFv3/mw23T32d.', NULL, '2026-06-06 02:59:58', '2026-09-17 11:17:55'),
(387, '31f7a380-9623-4ee9-b1f2-1007e045a64e', 'Nonames444', 'Nonames444', 'skaterdude454@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5dAowSfZgIdTTN8wQJ7GZuDoazdRaCAFCpMDeVCF9itAuYnhdn2Mm', NULL, '2026-06-06 03:22:56', '2026-09-17 11:17:55'),
(388, '5aae5f30-629f-470e-81c6-2ec3282c7a02', 'Rambo757', 'Rambo757', 'bythe757@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2dXy9lMdMeBrNw18LcHH9e/ADon/OBjfRf0mfgkvvY46ys.ItXjHu', NULL, '2026-06-06 08:48:53', '2026-09-17 11:17:55'),
(389, '03514ddc-ec0e-49d6-a175-f0c006ec796b', 'khullender', 'khullender', 'khullender0905@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$IiCdbLjdfQx/Bpf8Z5yEeOBZkxmX3E154WpnP.xAd8ZJUxNi70xHG', NULL, '2026-06-06 09:46:48', '2026-09-17 11:17:55'),
(390, '335bc9e0-ba85-4b3e-944d-33c94799f427', 'kevnkar426', 'kevnkar426', 'kevnkar426@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$S06P89VLj3aqQN3.Dxrh5OAJLUD5.TrxbQVU8PWSkJ3NwQaIroPw2', NULL, '2026-06-06 09:47:02', '2026-09-17 11:17:55'),
(391, 'b2f6cc2f-adff-46c5-afb6-a1b0d16ba707', 'Amber1234', 'Amber1234', 'amberhyder930@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qOsU3AirYulxGd1hD6qtvOQ0LGao9NUduEtib3oWKfa/UJ/L9Ke8.', NULL, '2026-06-06 13:06:45', '2026-09-17 11:17:55'),
(392, '9219b8ac-6c12-4dbf-abc7-3103af2ed902', 'Scotty', 'Scotty', 'scotdalegarmon@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$EBfMUL93PYQswilR/NoKxeuMuHcIr4mrU8JheSB9RQ1elml7s98kq', NULL, '2026-06-06 13:37:33', '2026-09-17 11:17:55'),
(393, 'f84b6232-5d8a-4777-b0e4-91574a037e29', 'Stephonlam', 'Stephonlam', 'stephonlampkin37@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Yib4axqR9GJv2unO8qCu5esIesYicEuGMx8Vzws9oRAkoUjsPERiC', NULL, '2026-06-06 17:44:45', '2026-09-17 11:17:55'),
(394, '1f7a5d1e-3d0d-4178-baf7-3918b66fc6e0', 'Mwaugh97', 'Mwaugh97', 'm.waugh1031@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zZR2skFso7.2Ak2TiysrFulgbZxPq1p9BDS9cKHMACXz23l8yPRUy', NULL, '2026-06-07 06:28:06', '2026-09-17 11:17:55'),
(395, '3a0a967b-01cb-4380-ac07-d63fae68a168', 'Michael40', 'Michael40', 'michaeljj8632@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Wv8tnHgFNxsu7OTINAJSbewPKd1x6qOIBSn0UUPpnn/kI.uhAUeZC', NULL, '2026-06-07 08:05:16', '2026-09-17 11:17:55'),
(396, '041f5c9d-a689-42f0-9a39-6f28e09883f0', 'Smeaglejer', 'Smeaglejer', 'jeremyengle2989@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Faz50GauXlLmUvcDtVZ5KuFRJmQhc58LKrMi.AdOkWQ19HR8CscEa', NULL, '2026-06-07 12:10:31', '2026-09-17 11:17:55'),
(397, '377f69d8-bcd4-4d5d-a523-6469b88d84e4', 'Smeagle198', 'Smeagle198', 'englejeremy1989@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fd6YCUKp6TH147MI2MK6OOAzp84fYoPzVEdE4qT4rPjMkdzo80x/K', NULL, '2026-06-07 12:10:57', '2026-09-17 11:17:55'),
(398, 'a4fbb233-e199-48fa-8af0-227e9a68483a', 'Smeagle19', 'Smeagle19', 'smeaglebama@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$U2v/hEpIa/Is/xdAt8uKjOUNXvMRtuTOz9Ga0VUc4PhimpUuFFNgC', NULL, '2026-06-07 12:11:25', '2026-09-17 11:17:55'),
(399, 'd3fb63c2-0e95-4c70-a7dc-863424f5b013', 'Smeagle1', 'Smeagle1', 'smeaglea.k.a.bigdaddy@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$46jeQX/6J68LecLc8tibH.UCgWnWZ5hHKnULvazpbqykaDZMo.QaK', NULL, '2026-06-07 12:11:45', '2026-09-17 11:17:55'),
(400, 'ef132fd9-0299-46a7-8299-9b06be3c53e5', 'Smeagle29', 'Smeagle29', 'michaelengle97@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZrQLACMI2MFHx5x0UOF3c.WER5n7Xg99FzguMBUK2YkpGD/HAYOEe', NULL, '2026-06-07 12:12:06', '2026-09-17 11:17:55'),
(401, '2f82cfbe-94bf-4d2b-88bc-016a201ba41c', 'Smeagle2', 'Smeagle2', 'jeremyengle19000@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tKGDEFdyqc51npnekZlX5ulIQw/KsPX2WYMt.K4.ZtfsyjaJTy21.', NULL, '2026-06-07 12:12:26', '2026-09-17 11:17:55'),
(402, 'a78abd4f-e44e-4115-b548-81c716bcd2c7', 'Smeagle9', 'Smeagle9', 'lovelldanielle81@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$BrAre1cZf6B8va/3zmwnVuVZ3./sEoZKWAsQBc3sRWsnRYG/pvlJm', NULL, '2026-06-07 12:12:48', '2026-09-17 11:17:55'),
(403, 'a1370c2d-51ae-41b9-b054-db8e1f327155', 'Smeagle89', 'Smeagle89', 'lovelldanielle1995@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$KeTTxGD8WC/k4jCkIyLT6.I.9FiROmK4QlHZxqWxa04NWRecOXGZu', NULL, '2026-06-07 12:13:20', '2026-09-17 11:17:55'),
(404, '71250752-0581-4e10-aadf-5d154e234d86', 'taymoney25', 'taymoney25', 'taymoney2582@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SHVJmotSvI0CLLiYFHuW9u8WKZW4RwKoq9uQ0zBLhHGk5rW9oMIry', NULL, '2026-06-07 13:51:23', '2026-09-17 11:17:55'),
(405, 'fe24b0e6-874c-4413-a30e-1b8787a8e17f', 'TheMan78', 'TheMan78', 'thatguy186482@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$f6JOhbdDuF/Z6c2sw0uVp.cQns2qhEeyQzd2Gs0k.S5f6cZihS0Wi', NULL, '2026-06-07 15:23:48', '2026-09-17 11:17:55'),
(406, '38a2699e-d77a-4891-82bd-a9494e2c5190', 'Peacedove', 'Peacedove', 'peacedove028@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7Dldl1ySEzadSjKYsKcql.oIoOLZckZK2zE275bUjWh9MRGlMEFSS', NULL, '2026-06-07 17:52:32', '2026-09-17 11:17:55'),
(407, 'f172a8c7-c6c2-4e99-8233-c79e9cf63316', 'Puppet83', 'Puppet83', 'meettoniceyou83@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$NiajOjFZncCEK6UvQS0lEejDTo/XV3rOJXJGfhx5xbk37cqtAG4j.', NULL, '2026-06-07 17:53:01', '2026-09-17 11:17:55'),
(408, '8823f78d-86d1-4bbd-acb4-fd2ef6849295', 'puppet', 'puppet', 'shaferlyall888@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zhI0CxzLJgWkDLqeKr0iUujbGpoxqcsKEhja7QXcxVjBr5gdA0qlm', NULL, '2026-06-07 17:59:12', '2026-09-17 11:17:55'),
(409, '0d60de5e-336e-4be0-8887-fde5457323eb', 'Jdavis83', 'Jdavis83', 'firenthehole41@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$QIpIj73je4tgLDZZ8CmU2.pzc28DY123gt57XZsAgiaBoGInw53Xu', NULL, '2026-06-07 18:00:11', '2026-09-17 11:17:55'),
(410, '90c952ad-2075-4d74-a3b1-2f07f35899f4', 'Menotyou', 'Menotyou', 'seeknowevil83@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5De.8lQ7HB/irEXGAGwLI.LhPhC3vpXRyDecpb.pperlicmEeuDke', NULL, '2026-06-07 18:00:44', '2026-09-17 11:17:55'),
(411, '3e0551d4-9941-47e5-a38d-6327b9e8d209', 'Letitgo', 'Letitgo', 'beyondwhatusee028@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JbfpiR6..8iaLsK1VHu2yujI/QYVne9NPnQvunwjMgtcTq.3Avpoy', NULL, '2026-06-07 18:02:10', '2026-09-17 11:17:55'),
(412, 'bef4a300-dd94-46de-af5b-7052ab4439f8', 'Lynn83', 'Lynn83', 'caitlynlangford05@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RgS55yk9ClbQASy5Z9wvEejHUayjqSAoXrGME3fhVM3Qn6QT4cW5W', NULL, '2026-06-07 18:03:56', '2026-09-17 11:17:55'),
(413, '532bd457-f1e9-4a7a-9041-35d87b8be06a', 'Peacedove8', 'Peacedove8', 'notthemamaw083@gmail.com', '+13529494475', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4ljKB2y/58e3V0uGUk5NIe5tSfmadYABD9wtyTgME0c12V0C2e3D2', NULL, '2026-06-07 17:51:45', '2026-09-17 11:17:55'),
(414, '5d8845cf-f431-4f11-84f8-df120274efd5', 'Bugboss78', 'Bugboss78', 'dwilliamsjunior.senior@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$U4NdxEl/6T95PpnF9MGdoui.HMzuLuup3dwuK6TOXxYn/jliEtDjW', NULL, '2026-06-07 20:02:46', '2026-09-17 11:17:55'),
(415, '0f895a02-67dc-451c-886b-c97210722dc3', 'Stitch2316', 'Stitch2316', 'sjones231623@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$NsWgp04U2gQ34hTTtZEFJuMJF4uZ9EvmR/hCzcWXwPzNuctkyTmnu', NULL, '2026-06-07 23:42:47', '2026-09-17 11:17:55'),
(416, 'b0c28bce-ef79-4b2b-8980-cb7cc3bd61a8', 'Stitch2323', 'Stitch2323', 'jones231623@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LVyCSK6fyukneErK3uroI.EZR3n4ofQd1AYFYinVZ1siVMYvSQZZW', NULL, '2026-06-07 23:44:06', '2026-09-17 11:17:55'),
(417, '2e32341b-9788-483c-b2d7-f4e1a32c0c6e', 'stitchj928', 'stitchj928', 'stitchj928@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$.IOUPmGNPCwhVG.y5XS7le7dVHrqXVdlgE988CPPb6K4fQ3BWEjYW', NULL, '2026-06-07 23:44:17', '2026-09-17 11:17:55'),
(418, 'ff484a83-949c-4cb1-946c-9edb42210adf', 'Stitch23', 'Stitch23', 'jonesstitch23@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7tCaqAU.FChRjxUrAwPYFOgztLfuy6zRyTaWyCnI0CRsdOqfSfb/K', NULL, '2026-06-07 23:46:11', '2026-09-17 11:17:55'),
(419, '6d33ebf8-eb13-4834-bffb-b842b6fbd898', 'Ceannaire', 'Ceannaire', 'ordnanusaile@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$C8zJsaLDUwpPjshYY4u5K.pMAR0A8ipqPyGYWjDugSaLTgB6G5Kkq', NULL, '2026-06-08 00:17:54', '2026-09-17 11:17:55'),
(420, 'f2f84333-65f9-4429-aafc-22596664b412', 'CarlaLexie', 'CarlaLexie', 'carlaapena@gmail.com', '+17199859662', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$klaKsEdlHA0BEsNQqReGPOpS7XWEYsAybJn6zYV9L7Q8OKDaI6o0u', NULL, '2026-06-05 15:03:04', '2026-09-17 11:17:55'),
(421, 'eea75436-4e58-4ea8-b3a9-1e55fecc582c', 'vallie25', 'vallie25', 'valeriecopes6@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$jnRkdLc3cwKeDiFq5ULHsePys/jZi6LvkhnPW6bFzFcwfDM/tP/W2', NULL, '2026-06-08 00:34:41', '2026-09-17 11:17:55'),
(422, '89c34580-ea9a-4c61-a16a-00c0b306fd6f', 'vallie2577', 'vallie2577', 'valeriecopes2023@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sjZh6NRlef60pXir8CZxUOgYj5e8Jxvv7rLVe5NZwxzkXkC5S8h4q', NULL, '2026-06-08 00:35:17', '2026-09-17 11:17:55'),
(423, 'e465c33b-579c-4be3-811b-1df68d3f47ea', 'vallieem', 'vallieem', 'veechacop@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$aelFgoEjwb4zqnZeZCFzBOCmFoxW3zUYapQE.8rQXYSxdFSXAbWP6', NULL, '2026-06-08 00:35:54', '2026-09-17 11:17:55'),
(424, '7330a114-05c4-4a01-96c7-c5e2dc9c54a4', 'annanns85', 'annanns85', 'annanns1985@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$coZWVMd7SvAgdB73uGBUM.OGtv/Szxs9xYedKiOnl/urFSKVmfWMi', NULL, '2026-06-08 03:40:04', '2026-09-17 11:17:55'),
(425, '0dd4fdca-bb84-4009-b097-9864eb6015b7', 'panther143', 'panther143', 'tipinkpanther143@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$N.0BYuTdF0N0XBB/AruZ7O0OF24XkvA6xnyWFd.fsC5IMEl4T63c2', NULL, '2026-06-08 03:40:38', '2026-09-17 11:17:55'),
(426, 'e2cf9e17-e0c8-4343-a33b-bb0167c982db', 'valhadenuf', 'valhadenuf', 'valhadenuff1@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$f3z7IbQCzrBtqqaIV1qPTOe5TiuC4uC1QdtI.fdeMscYEkjAyEkKy', NULL, '2026-06-08 03:41:23', '2026-09-17 11:17:55'),
(427, '73537321-626b-47d1-a84e-7d30f999f4b4', 'anns8314', 'anns8314', 'anns8314@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ddzhiro9/l4Stj7FYhow7.EkITo3GeP53BL2U93CFdxAGCqLElCa.', NULL, '2026-06-08 03:41:56', '2026-09-17 11:17:55'),
(428, '382a74cb-fb60-4d12-bc4b-f24abb0c0ed7', 'Toba0324', 'Toba0324', 'mikeikslittle@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4zLB5NfkMQPPxw1rbUFMPufDKSEqgVDM4U.JdywVgoE/R6zSbI.ey', NULL, '2026-06-08 07:29:24', '2026-09-17 11:17:55'),
(429, '741b67ec-d621-49b9-ae87-19afc1b7a898', 'cw24goodgm', 'cw24goodgm', 'cw24good@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hp6IiOQjA42iu98LIbb.4O/R2uFX11W5.P43aBQmgAp8Whsv6DG2K', NULL, '2026-06-08 12:12:07', '2026-09-17 11:17:55'),
(430, '2503b712-63c2-4e0b-a42a-1226b307eee6', 'Bojakk', 'Bojakk', 'yusefyahweh@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$jU.mKBTu3IvHSyrVKiIDHemVvZmA3QHPIN0NaxjVjawLiO1CumLu.', NULL, '2026-06-08 12:57:11', '2026-09-17 11:17:55'),
(431, 'a3d11f6c-ea70-4311-be16-0b77525d5b84', 'Kirbygirl8', 'Kirbygirl8', 'rachelandreotti269@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$k8f9Fi6jDkt8tWEvszStbOI2mHZLPmEdTZ7ptIMyjgR03.kX0VsIy', NULL, '2026-06-08 13:53:16', '2026-09-17 11:17:55'),
(432, 'f9a26b22-fb2f-40c2-9b51-291d2f5bd905', 'Msnoble86', 'Msnoble86', 'rachelemond86@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2Vj5xsjBDZ0SsUDItERXPOCAuBoklczMta68aY5nlT69QK05J/7cS', NULL, '2026-06-08 13:54:12', '2026-09-17 11:17:55'),
(433, '5e166624-a364-4ea6-b62f-1e16d31a1376', 'TxSoul83', 'TxSoul83', 'tarroll2323@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$blpDhYlQFToSBY2LFGkafOKaaJDyritJ7.Sjq5sze2bu2Jx9eu/xu', NULL, '2026-06-08 17:06:33', '2026-09-17 11:17:55'),
(434, '95ab5156-0c93-4ff9-891b-a6a054894ea4', 'TxSoulja83', 'TxSoulja83', 'tar79603@gmail.com', '+13168898363', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$g6BwsxXUfn0ER5Qew73FM.hBPoAfhklLAkGjBqk4eP6vqzIATcdIq', NULL, '2026-06-08 17:07:13', '2026-09-17 11:17:55'),
(435, 'ab02aee0-ead1-4200-b830-16004f493443', 'Alexsone1', 'Alexsone1', 'rseagle@cvhnc.org', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$C2BypLa0Kz.cQME5ht5axOtjlJO9B6XAhMUL/.uA/tFmZzKcHvYYu', NULL, '2026-06-08 18:32:20', '2026-09-17 11:17:55'),
(436, '096299dd-1170-41f1-a83a-3db98bdb0a9e', 'Crimdella8', 'Crimdella8', 'cooperdemetrius39@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$BbeMkjsoSAxo2SBRd93YqOD.1WdlZYq./Bgh34f3liT/BVyZm9.c6', NULL, '2026-06-08 20:28:12', '2026-09-17 11:17:55'),
(437, 'fbec1d0c-96f2-4d7d-8bb7-bc5a47026130', 'Mandipandi', 'Mandipandi', 'amspang78@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dnIpmZZm6CrqE9Q6HsKqp.W6XctUM1GihjqylxFGmyAtZXpuj6xiG', NULL, '2026-06-08 21:06:28', '2026-09-17 11:17:55'),
(438, '50cb7b6e-b94c-44f6-9b58-e16c5cfb3fa8', 'Kimberlyre', 'Kimberlyre', 'kimberlyreed332@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$g2Sy4xebkHAd3rwErH2uUOWLMFujdxwUCF2WrWPml0193oakfTEkG', NULL, '2026-06-09 01:40:26', '2026-09-17 11:17:55'),
(439, 'fb6aec2f-071a-4b24-903d-fd6340495687', 'Joenval', 'Joenval', 'joec55153@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7Ca2UR7mTJOXAB/hyjSt1ejWqPkjKQysOdC6eisgsqG8BWYGwpWAS', NULL, '2026-06-09 06:44:03', '2026-09-17 11:17:55'),
(440, '4d866a60-3f45-4aee-8fd2-92c2f107e6da', 'stoney69', 'stoney69', 'aymeestonefield4@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$czeCgcUaQUamY/2x2lrlXut.Umpq1/Ed1HkzXW3tgE.ktUlkaEgKO', NULL, '2026-06-09 11:56:52', '2026-09-17 11:17:55'),
(441, 'd9027ecb-7c6a-4a85-8dfe-95b8192ee5bc', 'stoney6969', 'stoney6969', 'stonefieldaymee69@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$auVa3pMIZqn3JniCIl5sIebqyhz.sKwTc/lK7yQ/MDMa/7eT6/lGW', NULL, '2026-06-09 12:03:00', '2026-09-17 11:17:55'),
(442, 'ec1116a0-0edb-4325-96b9-cd679064600d', 'rosanna26', 'rosanna26', 'rosannafrith2022@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uJrQfAaj6x1kUjCi32y9P.qEt7KaSQ2HEB.9S50cm9Xj0fd2TrLF2', NULL, '2026-06-09 13:40:07', '2026-09-17 11:17:55'),
(443, 'bd256d6a-48b5-42fb-bb3a-e5861faf5a7a', 'rosanna', 'rosanna', 'rosannafrith19@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Jk5b/h2UvIr3wGhMT0fuou6wq1Lx/PgLpAOmm0.cn2q8GMl5gVP.q', NULL, '2026-06-09 13:41:06', '2026-09-17 11:17:55'),
(444, '37e5f460-e1f9-4044-9970-0397958bc34d', 'rosanna27', 'rosanna27', 'rosannafrith2026@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$o7dYXydKjt5mrP5H1jyGHOmYgCToV6.2AuWpUMLp4ZOoi5JDBoci6', NULL, '2026-06-09 13:41:57', '2026-09-17 11:17:55');
INSERT INTO `users` (`id`, `legacy_id`, `name`, `username`, `email`, `phone`, `avatar_url`, `ghl_contact_id`, `balance`, `role`, `is_flagged`, `flagged_reason`, `flagged_at`, `email_verified_by_admin`, `phone_verified`, `phone_verified_at`, `country`, `state`, `gender`, `date_of_birth`, `email_notifications`, `email_verified_at`, `last_login_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(445, 'c15da770-d2be-4f1e-b458-fe55be645bd9', 'RobLow87', 'RobLow87', 'robertjoseph62080@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JiHZji8R5aepg4z5tzsaNeSnWu9sNBpw5ztpwkGXsUfQS6HjrqzjO', NULL, '2026-06-09 16:37:33', '2026-09-17 11:17:55'),
(446, 'bca9ab81-4cc5-492d-85f1-a27d4311d783', 'RobLow80', 'RobLow80', 'jrblackrob954@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DbZpU.radMuUXJPOgEfg1OAJum9jxiIJg3jLk.HaQXGCP0dS/4LGC', NULL, '2026-06-09 16:39:07', '2026-09-17 11:17:55'),
(447, 'f3641ebd-a63c-4106-befe-29b69947c052', 'Robert42gr', 'Robert42gr', 'jacuzzilow1804@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZulGWoyfT3zDHQHqQX4R2.g8PYcaIWZMQLSV2YTHIxiqUZbsC9.Te', NULL, '2026-06-09 16:41:13', '2026-09-17 11:17:55'),
(448, '291ba61c-9ab8-46dc-8de4-fd82421a0b4d', 'Denise1960', 'Denise1960', 'karenjohnson1234@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MGKE3gHGAE1tHkHVXZQjV.I0FEV8kzKiJw1wa0q61bJNtv0JLPrNm', NULL, '2026-06-09 16:48:03', '2026-09-17 11:17:55'),
(449, 'fd968854-2d5c-4632-b606-813cc6d0a97a', 'Stoff40', 'Stoff40', 'realstoff38@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Aokv.yjg6aEr91juU/Zns.lBXYlLj6EpCxHnVjVxxea9/CLqfDebq', NULL, '2026-06-09 17:52:39', '2026-09-17 11:17:55'),
(450, 'f6de4630-74c2-4214-8017-27fdafdd2409', 'Stoffy40', 'Stoffy40', 'realmike39@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qJX6OHbE2Aw.RjiDpeUrMe0FMnXHxnY1G1qQ5yUvU28VhHgWzzuDG', NULL, '2026-06-09 17:53:17', '2026-09-17 11:17:55'),
(451, '701a23fe-1b61-45a8-bc5e-831636137cb0', 'Stoffy1985', 'Stoffy1985', 'realstoff40@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uaFc1oKRhahs5Gtg41mbeOlPlVoUBDL0ah7M/M3vbZrHeznyUE4te', NULL, '2026-06-09 17:55:20', '2026-09-17 11:17:55'),
(452, '30247515-f437-4ec0-ae79-30a8c9b2e015', 'joycelake9', 'joycelake9', 'joycelake933@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$BRtynjXWPC1Ui2qqGXWJk.fWN9OCN1syRhS7mZ3bK.0THZVL6pmh2', NULL, '2026-06-09 20:50:56', '2026-09-17 11:17:55'),
(453, 'cf9a012e-4434-492f-ab59-33353a0305b2', 'Doddda336', 'Doddda336', 'souriyeth63@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Z8tIMeyU1s9mxK1xuFpt6eRjthbdTw0bgRO0F9k6rf69nxcXQIYra', NULL, '2026-06-10 02:04:50', '2026-09-17 11:17:55'),
(454, '7c05257c-ee0a-4de9-b539-d9ea499e48e9', 'Dodddda336', 'Dodddda336', 'souriyeth@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$eikyDFNuhJv9ZCEiGXSYb.RFdtOzXw02E1Ka7uHpKaKV4dJl.eP..', NULL, '2026-06-10 02:05:53', '2026-09-17 11:17:55'),
(455, 'a8458dcc-05f7-4caf-ba91-7d022f9b1636', 'Hgable54', 'Hgable54', 'haleybug67901@gmail.com', '+13163890128', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$PMNq/NqBONmXKtknplixR./3cItKP.dGHZcS2YRaCcCTC3XmwDsni', NULL, '2026-06-05 22:55:51', '2026-09-17 11:17:55'),
(456, 'eda88db0-7e73-4b57-aa68-9d1d5238c004', 'Conner1982', 'Conner1982', 'allencon607@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VEGUlIHYyN4EhIjTXMSgKO2HoO7JUy0VkbcNJSm0iqaefbzK1fVgO', NULL, '2026-06-10 07:43:23', '2026-09-17 11:17:55'),
(457, 'd861fe05-ad2c-4591-9d7b-251ac13333a6', 'mushunavin', 'mushunavin', 'mushunavincelarkinslakatos@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mgYrGKDZEPIlrLVUVZMOYunlShzCStx3oV.l7mHVH1qK7bWZZKXYe', NULL, '2026-06-10 11:23:07', '2026-09-17 11:17:55'),
(458, 'aae09097-3355-44d8-948a-7a2681200c25', 'mushunamon', 'mushunamon', 'mushunalarkins0@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$EB5bJHW7uWmnzt2M1I51p.LmBWR4mGNBYt/jxMamZMo5JXqSb9KX2', NULL, '2026-06-10 11:23:56', '2026-09-17 11:17:55'),
(459, '72f4ed7d-7bf7-44f8-9414-0a692c01084b', 'Joel9091', 'Joel9091', 'joelgonz966@gmail.com', '+16613464676', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LzJm6d74Yi6WQYTvUfHdAueOTe0VJaO.u0hz8VsbKcCq50MaykUpS', NULL, '2026-06-10 11:36:58', '2026-09-17 11:17:55'),
(460, 'b27d136f-eca9-468f-baf2-0b271cd43a50', 'WildboyYC', 'WildboyYC', 'wildboy51709@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uSJAkhNhL0jvmQ2g1ibyqOeTid0WJPIH92Z4cuZEu35Z9vTuZRddq', NULL, '2026-06-10 14:14:54', '2026-09-17 11:17:55'),
(461, '040d57db-a843-40c3-84a9-22aacd7c9f5a', 'WildboyYC2', 'WildboyYC2', 'jerryyoungg51709@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MJet/Wr2mflcEINprOmVEOgWR2QbpgDtVdO0tf03UYlZtpiMjj/ES', NULL, '2026-06-10 14:15:58', '2026-09-17 11:17:55'),
(462, '9f2dd84e-cf31-4d5c-b927-481b3afe507a', 'scott133', 'scott133', 'scottstincleandtattoo@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$APnpCYNiEpNlTmpB3N/LdeZJ2RiPSaUkH2WJJ1cOyVvH4tmZpz3eW', NULL, '2026-06-10 16:07:06', '2026-09-17 11:17:55'),
(463, 'f41ab6d0-f584-411f-a7f9-6ba0076acbe4', 'famrob133', 'famrob133', 'famrobscott@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SmWsejrcW/kemBKprMbKD.LZE.9qqAc76YsZUyf2iKtm14xPK7yUm', NULL, '2026-06-10 16:12:54', '2026-09-17 11:17:55'),
(464, '6f7b0ad0-a301-433b-a73d-7b8e9244dffc', 'QueenJ74', 'QueenJ74', 'moses1974jackie@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VfGeNE2QI3NHwCjRi708KukfZwBvg8Tfcm2zKMOHBcMx9RSwnpiSS', NULL, '2026-06-10 16:18:41', '2026-09-17 11:17:55'),
(465, '3204e77c-b2bb-4479-88f1-cad7d55df65e', 'Moneymaker', 'Moneymaker', 'ruilin202634@gmail.com', '+15598789142', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZkjFDUZSr62pdFAr50nBU.kQ2cWHVffO8O7NZRHFHRVCYhu5h.D/G', NULL, '2026-06-10 13:21:31', '2026-09-17 11:17:55'),
(466, 'ba529983-36b1-4888-a347-9dbb7093923d', 'walkerjayd', 'walkerjayd', 'walkerjayda08@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6aIEHMODkZEiLZAlaOtNROm.urWfrObJGqQ34UjkODaYRDFyFFPS6', NULL, '2026-06-10 19:24:56', '2026-09-17 11:17:55'),
(467, '413fff73-8771-42cd-8d75-17ec03409866', 'GatoradeDa', 'GatoradeDa', 'bigbankgada@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4gglMrEyLB/rzuA9ow1ZVuFyXWAhNcKjxm7coqe.OrhZPiFCeYWMu', NULL, '2026-06-11 01:10:19', '2026-09-17 11:17:55'),
(468, '89355487-1ece-4b13-a0e3-2df96e645b1d', 'BeatGeek', 'BeatGeek', 'beatgeekllc@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$K.tAdTBeuz8HpOk8GM3eluZVfCZO5Kx8nLiVTSXJlEimU9Vqe23Z.', NULL, '2026-06-11 01:10:45', '2026-09-17 11:17:55'),
(469, 'a3d86c8b-56a5-4c79-a433-0ecdcf1bcc47', 'GatorBoi44', 'GatorBoi44', 'desitaye83@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Zf9KJk43BbaG6/k4diXnIuHq2j5tzwESKtNYmAfLA0As8yRwTfCIu', NULL, '2026-06-11 01:11:22', '2026-09-17 11:17:55'),
(470, 'bf6f3aaf-52eb-4263-b756-c9f11d08f912', 'Adam Pavel', 'Adam87', 'apavel20@gmail.com', '+17158216434', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Wisconsin', 'Male', '1987-10-13', 1, NULL, NULL, '$2y$10$0aWQiilAauRfnhVOzu/FyuOF/fqTxcF.a0IHWGlmLooVpOjse3dMy', NULL, '2026-06-10 19:38:48', '2026-09-17 11:17:55'),
(471, 'ef85e286-ce64-4bf3-8a50-e25ab4abc73e', 'NilaJames', 'NilaJames', 'quiniliajames84@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xjFniydRf.X6Qcmcv1GgnuAGhZSHvRaY9AkQQ4z.RKLzBxRqUvAsy', NULL, '2026-06-10 21:19:18', '2026-09-17 11:17:55'),
(472, '06ef1f35-ddab-454c-ae27-6eff670e4dab', 'Tweezy', 'Tweezy', 'ytonya45@gmail.com', '+12705772908', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vcEt.Y6yTArD8E5bniRFWeaKfrFA2GI4jddA4lVQFg/uks16a69Iy', NULL, '2026-06-10 23:53:37', '2026-09-17 11:17:55'),
(473, 'cc589c45-6bb8-4477-8870-f408b1614559', 'Jennbeas', 'Jennbeas', 'jennbeasley1109@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$Eaie3qsSygTX0vdA6U9mPe9Eu7K5ObsZXr57I5DCg2v44L.eW2tg.', NULL, '2026-06-11 02:35:56', '2026-09-17 11:17:55'),
(474, 'b302f37c-1e89-42f7-8ad0-0f63d232dd71', 'Jennbeas26', 'Jennbeas26', 'jennkuklar1109@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$D46v6M/f7n1uvAahIxzy0edfJKyjzc3wLWbmpHZiA0K/wJrzfEiEW', NULL, '2026-06-11 02:36:36', '2026-09-17 11:17:55'),
(475, 'b4150b87-c1b0-4dc7-959a-3fe5816d4dc8', 'kennethsuz', 'kennethsuz', 'kennethsuzukiboy86@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$NIVFPb9yHSdeB7aVUpOeyeyorIN5oKv26PNkOO4tq2Z/RPn1Q82x2', NULL, '2026-06-11 07:22:28', '2026-09-17 11:17:55'),
(476, '2841aaf8-ac7a-4dad-9a9b-ca91c0252f67', 'Barbie2280', 'Barbie2280', 'barbie2280@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RWakGLWMOz8h7dnZ.2DEk.teHQ2F3uKz6sy8V/uTC5x/LQelDW4DS', NULL, '2026-06-11 23:38:06', '2026-09-17 11:17:55'),
(477, '6751757b-6667-4abb-a3ec-3330e500f63b', 'Bellini802', 'Bellini802', 'mscapricbellini@outlook.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/q2vCA/3q2AqcSF.CW7SEu4JxT9x//wktjcUrj07.qIPWv0K365Sq', NULL, '2026-06-11 23:40:38', '2026-09-17 11:17:55'),
(478, '5aeb804e-c8f5-4033-96e6-c0904441a229', 'Luisaries2', 'Luisaries2', 'christinabellini1@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qppf2a77slEtc4Hcm8u2u.9IIG91Lvwox77BT2RYvB289dZxQIaZq', NULL, '2026-06-11 23:42:12', '2026-09-17 11:17:55'),
(479, '0f6d2392-dab0-4ef9-919b-00534de5ea01', 'MrRayRay98', 'MrRayRay98', 'rayvilletorregano5@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6PoJ1maTWCanW1E3SsZb8uEDyOVFDeyXf/WtaZaizYu15ZFFZ9l8e', NULL, '2026-06-12 02:16:21', '2026-09-17 11:17:55'),
(480, '67196046-87d2-41ed-b0c5-ac568a59485b', 'MadameSno', 'MadameSno', 'tamarasprinkle058@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$HdhR5UEJoHTQpDoPGfSxv.tZBlsbs/ABB..2VOSSEENWjo6KdDsfe', NULL, '2026-06-12 02:53:38', '2026-09-17 11:17:55'),
(481, '2575913c-008c-471c-99cd-7a29bf466623', 'Sanchok26', 'Sanchok26', 'robertkaysandra974@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$V8/qMqXf52.DlmIBxX5loOdIYoNk097Uy7FAkv9od5KjFi3XOlvzG', NULL, '2026-06-12 03:39:02', '2026-09-17 11:17:55'),
(482, '10d1c489-19c0-4387-8635-ef8c466af0c9', 'Pualoke', 'Pualoke', 'pualokelouis@icloud.com', '+18085171399', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7zQKC9Mi9m2Qq5noxYvG6uaZkW7vi1QskL4KhZ4P9qj6DPGHZKkne', NULL, '2026-06-12 13:34:50', '2026-09-17 11:17:55'),
(483, 'a6f0c960-b410-492d-a742-ddc59cb189de', 'Heidijones', 'Heidijones', 'mineznotuok@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$bzhyhShuyXgNghdwM2V8HeQtWk1xmOTq.XCt36a51AK/wP5kRamEK', NULL, '2026-09-03 17:20:28', '2026-09-17 11:17:55'),
(484, '5743889c-4e8d-41ca-99b8-041875e9fc28', 'Fancygal', 'Fancygal', 'fancychallenges@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$TTYxMh3C21r/9sjenGzyGe7EAfXTnUvLDggYRi/ePa9xaA/9G7lty', NULL, '2026-06-13 00:21:35', '2026-09-17 11:17:55'),
(485, 'b7d6b12e-9c60-4a8c-91a7-8db37ec62312', 'Akb4eva', 'Akb4eva', 'akb4eva@gmail.com', '+19104608565', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6c/AW4ZMCd2LiwJmJLxl4u4C5Q3d2wWd0VoY5rYTcsT46xny94nzS', NULL, '2026-06-13 00:19:48', '2026-09-17 11:17:55'),
(486, '08fa9d86-903c-4d86-9959-4e27113128e7', 'BamaAries8', 'BamaAries8', 'dewaynestevenson53@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$rVZMvMZeImlb6MogcMJrOuMv45MLGBU2EPZUzgzB3uXQ0oE6GxWa2', NULL, '2026-06-13 02:41:33', '2026-09-17 11:17:55'),
(487, '925d1cd0-f778-435e-b1f8-a65f694da38e', 'Sugamoma78', 'Sugamoma78', 'sugamoma787878@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zpaK5uP/1XWgJm0Vaz3aXeb0vPwDHQip6IRx6DQJt1e2DqY6HGoOu', NULL, '2026-06-13 16:04:34', '2026-09-17 11:17:55'),
(488, 'b2d4b264-6aa1-4ec4-a5fb-2a48b4cfc8b0', 'williewill', 'williewill', 'williewilldo77@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$E4Gaw6AZfjPUmcrCcdfzmuo5S1KyHfQLh.V9TZTIcraO0dp9syemy', NULL, '2026-06-13 21:44:56', '2026-09-17 11:17:55'),
(489, 'ac97fed8-1a8d-424c-9c93-0f17d1c87972', 'Kirsten27', 'Kirsten27', 'kirstenkimble0@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$3eLMI.Scy1plA6HnovwkvO.HLd59bd5H3ArGc/ZCzhQ/v4VRF4FTW', NULL, '2026-06-13 23:16:03', '2026-09-17 11:17:55'),
(490, 'dcec2cbb-3f14-427f-8e84-5b72a6cf2f47', 'AliciaAnnG', 'AliciaAnnG', 'alwaysbelieve7927@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$PNtn3Ojd6JVwtT/k08CUbe.jqICZffcALhP7DN7mTPVSfO5c.s0GO', NULL, '2026-06-14 02:50:36', '2026-09-17 11:17:55'),
(491, 'd0d0f14e-3fbc-47bd-843d-f7745cc45914', 'kaytconner', 'kaytconner', 'katenextdoor2794@yahoo.com', '+14789983271', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$NlS3xn2ost4EGlgrls7HcuWDhc2Wgxo2.7Ja1TDQoMcUgsI6qMKbS', NULL, '2026-06-14 06:21:49', '2026-09-17 11:17:55'),
(492, 'e401ea2f-685e-49b8-ae29-85e085a99caf', 'Acxx94', 'Acxx94', 'adisonaac94@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zE0wUfY8IE2uteaQS0c6pu22JNFZNKe65hihgDXTeT3nq9OhJUDry', NULL, '2026-06-14 13:12:01', '2026-09-17 11:17:55'),
(493, '4f8a97f5-7ba2-4d51-9694-a1dacdaa18d6', 'Acxx94xd', 'Acxx94xd', 'adisonaacxx94@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8Co/buP4b.hQUjTa6IIZquMxawYuZvoyKURpBSsgnR9X/BFxP3Zqm', NULL, '2026-06-14 13:12:30', '2026-09-17 11:17:55'),
(494, '1fe9aabf-bcd1-4e34-8736-364a3f010832', 'Tim74213', 'Tim74213', 'tim74_213@hotmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dKWtzexcpKaYPcjwMUctGeg85IVXQuutB3gcHSVdNOHCPw0vRjpbm', NULL, '2026-06-14 13:29:15', '2026-09-17 11:17:55'),
(495, '18239a9e-2d1b-4d7d-a0d1-5b960960dcdd', 'Bizb84', 'Bizb84', 'bizbarker74@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YyO3/VNb89NgswR4A2mDmOd0p5oAazgRSk5x4VGWDit.4AoxBj.Wi', NULL, '2026-06-14 13:30:39', '2026-09-17 11:17:55'),
(496, '72aad9c4-e534-475b-ac94-a02a2a9cd40f', 'Bizbarker', 'Bizbarker', 'bizbarker213@gmail.com', '+18594946349', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8gOQhm2MULqc135e6iR0KePE..icH6vUOvoTdiCgocrmYCK6tYwUG', NULL, '2026-06-14 13:29:56', '2026-09-17 11:17:55'),
(497, '43e4f9e8-bf6f-41fe-9e6a-7345b4c515eb', '5iveStar', '5iveStar', 'ese5stargeneral@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RorDTFd3IfKCB5aczi/fAOOeByttJJamWInrwBDw6PFNDM1hvNU66', NULL, '2026-06-14 16:46:43', '2026-09-17 11:17:55'),
(498, '1e05b3bb-f15d-4e69-8210-996c137071ab', 'Sh8sh8', 'Sh8sh8', 'tteosasha@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MxtrleLwa0Ptd7TB6NmT6.1H7FEDlnSLpkD3.En66st/0OCqbvVsO', NULL, '2026-06-14 16:47:29', '2026-09-17 11:17:55'),
(499, 'e6af85a7-85f1-4536-bbf7-4a59058f48d3', 'SashaD', 'SashaD', 'sh8.sh8.t30@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1Zt7xsGDpq0N0OGV8q/6Ie8SjYB4bv.XRkTpKjFEIOTjqStJPc9um', NULL, '2026-06-14 16:48:09', '2026-09-17 11:17:55'),
(500, 'd58e99a4-1a08-44c3-8ea3-0438e37f73ae', 'Sa5star', 'Sa5star', 'fivestar@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$gdzO0YbsVw8lzAbLVOyNwu6RKJOWw7ik20K7ubXx2FOhOjyUSws1K', NULL, '2026-06-14 16:49:08', '2026-09-17 11:17:55'),
(501, 'c49d39d6-eefa-4d9c-877d-4b97f8fb48c5', 'Sugarlo433', 'Sugarlo433', 'apollooscar20@gmail.com', '+18303090133', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$g7N2MhvXOBP9jmedekccSuj.IEcOcQbwwUYI9KRpVcImRGQwsHAMC', NULL, '2026-06-15 22:17:43', '2026-09-17 11:17:55'),
(502, '791dadf0-87ac-4cd6-99be-bafe94bb1653', 'Ashley Whittaker', 'LilShorty9', 'ash6341@outlook.com', '+12148665473', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1990-01-23', 1, NULL, NULL, '$2y$10$PEav8By8b9evm4MkQzwEAeIe3KcirrbpE5x5d1m4TMWoG1/FTu5Ji', NULL, '2026-06-17 05:53:43', '2026-09-17 11:17:55'),
(503, '5360f263-63d4-4124-8080-4dc527723a89', 'Mark Mineo', 'Meekus', 'meekus0714@gmail.com', '+15127123297', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1986-09-19', 1, NULL, NULL, '$2y$10$XBe4qTpPjXIHKOoNIB2c6eWe.um9YCg15WeSBSxw301/9JGYyFwoC', NULL, '2026-06-14 20:27:43', '2026-09-17 11:17:55'),
(504, '954bf435-00be-406f-9f48-cf732f8f1e32', 'pwalls1956', 'pwalls1956', 'pwalls.1956@gmail.com', '+13525540302', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DOF4MLfsVuafdQS7CVPyDuphlrhaCKZsAoiy/NfC0zxvkBKeU.z0e', NULL, '2026-06-14 21:20:18', '2026-09-17 11:17:55'),
(505, '476b6d0f-bea1-4476-b194-2c36fc5ac7b0', 'blj7400gma', 'blj7400gma', 'bljsms7480@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$9Wb0SFvhsZD9TKFrzIW2RuR7HiJWokyOiF5D/MMs2.Phue8Dj6LZC', NULL, '2026-06-14 21:57:19', '2026-09-17 11:17:55'),
(506, '23e6ba4d-ed0a-4dae-83c4-5ec3677f8483', 'SmarieC308', 'SmarieC308', 'smariec39@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$5gGDqAmhaB51VWK7qqVWnOe8gR5RRQR9OgrToXSBujNVwKzQFfPHi', NULL, '2026-09-03 18:02:52', '2026-09-17 11:17:55'),
(507, '132958b8-2283-4aff-a843-067889a30798', 'Natalac', 'Natalac', 'bambiporkchopdaboss@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$9fC1eDVrJ00UEhQ7lqyuGObXMsAYweY0UAmPkZpU0gNtPyFvL83YO', NULL, '2026-06-15 00:37:51', '2026-09-17 11:17:55'),
(508, 'be4807fa-d18b-4a48-90ad-094bf158ef8b', 'Blackboy77', 'Blackboy77', 'alvin.j.goodman.jr@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$IDlMflmqpLZPoGFIvVCja.usq0.4gwUDK1LU.VUtGkO62C/svWA6m', NULL, '2026-06-15 05:05:56', '2026-09-17 11:17:55'),
(509, 'd0b7cb0d-0cf3-494c-ac39-1286388e1eab', 'Blackboy00', 'Blackboy00', 'a.j_goodman@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$PyElxVo8UoiGNEYDDyoshuQvDckP3tmog9u/./y6kHpq2rM8TC0KS', NULL, '2026-06-15 05:06:32', '2026-09-17 11:17:55'),
(510, '14e584ca-1c27-4920-acf1-a1abf268aaea', 'Crazyman88', 'Crazyman88', 'krazyboy199200@gmail.com', '+12055479554', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$TAyx9K/tEgNE2j3LQ3i4vO9PN1Lf2vpX6cIfMBBPuzrxO5deFdb/.', NULL, '2026-06-15 06:10:41', '2026-09-17 11:17:55'),
(511, '8aadeae9-f7a0-4a57-a31d-1ea4a0f71af1', 'Supahslot', 'Supahslot', 'supadeez2002@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$GQTnSKvaTnNghMKjMWGgAebGvDyuJndPJN9pUTaMpb7JpyzAsKNSu', NULL, '2026-06-15 19:51:26', '2026-09-17 11:17:55'),
(512, 'c489c87d-0314-46db-ae30-edcdd643a13c', 'Shyboog88', 'Shyboog88', 'msyoucangetit90@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$1yzmtgzP3spEiPCKE2sjbO.4dRwV2b4ppXdpQf7zT31bTFDQWx3KK', NULL, '2026-09-04 10:48:10', '2026-09-17 11:17:55'),
(513, 'fc9dac6a-080d-4bd2-93ce-4823dfa421d0', 'Sammy626', 'Sammy626', 'ornelas_samantha@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MLZGWwHzKOUf/RuwZMfRgeYj0ISN1gEdsYe2DTRb5wZeMwci.skwa', NULL, '2026-06-16 02:11:05', '2026-09-17 11:17:55'),
(514, 'a90ace52-18da-4f78-854c-878176c4ef9a', 'Babyjaq91', 'Babyjaq91', 'babyjacq1691@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Wqf34ixxW7py9BJ.6E.9DO5R7QD3lhrmSTpWlQh8YP8.px7XdFbIG', NULL, '2026-06-16 11:35:25', '2026-09-17 11:17:55'),
(515, '6e80cef6-b9c0-49b3-8c94-a1a558e0497d', 'Babybre78', 'Babybre78', 'bmpuente2013@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$cmuTZ/xjijNDSeFmJqhVguseIxreDD4tG9XuMSYh1/QKlvMNoUrcC', NULL, '2026-06-16 16:12:05', '2026-09-17 11:17:55'),
(516, '674007af-ceea-4f61-90d2-51855776926f', 'Bibisissi', 'Bibisissi', 'brandiedwards617@gmail.com', '+12299216707', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$09B6I0iYC2Xcvx22XONMhePQhrJbx4QQX.FvTbO/EoaUZZxECeZ0C', NULL, '2026-06-16 17:01:52', '2026-09-17 11:17:55'),
(517, 'c72fc5a6-cfb1-4a95-b4e9-4822fdce3903', 'Misty524', 'Misty524', 'woodcockswoman@gmail.com', '+14699844686', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DZPBwQMP4WzbQLqCWr1Q8e2MpeW8HRhX0UNuD4TL1HM/VYYmXm0zm', NULL, '2026-06-16 18:11:44', '2026-09-17 11:17:55'),
(518, 'b0f319ab-30d2-4318-9347-d23fba0c74c8', 'Tamtech', 'Tamtech', 'tlpickenplus1@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$G7RttvRtt1Fjv33fFuNft.YIpo9B7JymcHRpESTzO9Zjyhwi/eA6y', NULL, '2026-06-16 19:10:08', '2026-09-17 11:17:55'),
(519, '43f35318-b0ae-4612-948a-cde38a7288b9', 'Jewelz83', 'Jewelz83', 'jujureagin@gmail.com', '+12292849538', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YcFaZVXpygk9.WC3xN.dHuUSU.UA3otmc/k46V.zsFMnm7bd/PTCm', NULL, '2026-06-16 19:11:44', '2026-09-17 11:17:55'),
(520, '86358396-928c-41e2-8557-bc304a041dd1', 'marshallwo', 'marshallwo', 'marshallwoolis895@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$iBAo1YSrPH4Lhv64Id8y4.BJ0fUsnsLmdJoG9z1fRW0apttXpcyLO', NULL, '2026-06-16 23:21:50', '2026-09-17 11:17:55'),
(521, 'e6ee4a48-5c09-449e-b169-2d87c5ad817a', 'K80babiie', 'K80babiie', 'k80francis31@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ag3iESBRNPPmH6U7qbcbPerOtknttmWMmVsOB/9./hRZpZ6zSz1BO', NULL, '2026-06-17 01:02:40', '2026-09-17 11:17:55'),
(522, '0151c19c-f335-4d33-92df-9464a7a98021', 'Roderick12', 'Roderick12', 'hebertshane46@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RNhDAzhYAMIKSSb3hXOcH.2SR/nebIt7CGaKl/fbNFMfN2Da64yae', NULL, '2026-06-17 09:57:16', '2026-09-17 11:17:55'),
(523, 'de63c908-2882-41ff-81d2-f39ce8aa6fac', 'ThatLeo84', 'ThatLeo84', 'thatleo8481@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JpKfld0VdTQwm5pSVlL7t.h/HFsi5nw/Ey1/ATcTsB0CiU3zYt6B2', NULL, '2026-06-17 10:58:48', '2026-09-17 11:17:55'),
(524, '809059a5-5f2f-4984-956d-8411cc0501a3', 'Andyyy', 'Andyyy', 'zandermanluv1@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$H7FjlcJB6HWhUnfCRCBa/OV46nFpWjGd2i.bI8pqXfxGZy5AJ37me', NULL, '2026-06-17 15:11:06', '2026-09-17 11:17:55'),
(525, '36940f67-4bee-4f2f-9a07-4eb31f608b53', 'MellyMell8', 'MellyMell8', 'mellclinton1@gmail.com', '+14808532868', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qQvfbUCBXLevuVY5W9X/B.KI9f5ji8GnrqujWQt3UhsC8qa4nsP/W', NULL, '2026-06-18 01:03:48', '2026-09-17 11:17:55'),
(526, 'd197b0dc-8668-47c0-ade5-9dd5a3d0a044', 'Ald1477', 'Ald1477', 'dillardalex10@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5lh6272jw9pZP1gcoHPoOu/JbyWztmP.WW1/LC/Ct9rDz1quFYH1i', NULL, '2026-06-18 13:18:45', '2026-09-17 11:17:55'),
(527, '075ae118-08a9-4069-93cd-11467bf86041', 'tevinbolde', 'tevinbolde', 'tevinbolden30@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Lu.USWSX5G0umf7SIvfNAuWMyBDv7U5LoA/OfanzlK3nsIN.f.GEa', NULL, '2026-06-18 14:02:08', '2026-09-17 11:17:55'),
(528, 'ae1af2de-4519-4b76-ab51-e40fa4777112', 'BigCityFW', 'BigCityFW', 'robertshepard2024@gmail.com', '+16822212306', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$bQJOkwzU7Nz5S25t/oSPKu00bRgYicg41B1ewh3nE1VHDQdA46dbu', NULL, '2026-06-18 18:51:22', '2026-09-17 11:17:55'),
(529, '650fdd47-cad0-4174-bbdd-5bb0f6ed1c6a', 'mylifeblik', 'mylifeblik', 'whitleynicole13@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Ar/qlAaG7UWELs1DpuFldecptfY5b.gWa7DheZR.QS1t1wunfgXme', NULL, '2026-06-18 20:30:08', '2026-09-17 11:17:55'),
(530, '880ecff3-4b5f-46b9-a8cb-6c72a094fd98', 'Lilhotrod', 'Lilhotrod', 'gabrielmag931@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0myAYKLUhg5T1W3UIu/LOOCS5S7ikRaODZ.o5ovzxeMlD8GPYoeQq', NULL, '2026-06-19 03:45:53', '2026-09-17 11:17:55'),
(531, 'bb171902-dd8c-4117-8286-6a1a9218f75c', 'MrSpoonDog', 'MrSpoonDog', 'goodaydenn@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OAfdhuRAkx/7giU6rhPhTO5BjO5.qXtxufZRePwdgyLktalFhOj9.', NULL, '2026-06-19 05:22:48', '2026-09-17 11:17:55'),
(532, '4cc15664-696e-42fc-a605-131968915512', 'Timbo2967', 'Timbo2967', 'timothyhardin1990@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$HcPYfWe6ZG0TwiwfynIVWuzqI46gUwVYhVIBqGSTacq01qmC12tqW', NULL, '2026-06-19 06:32:27', '2026-09-17 11:17:55'),
(533, '6258e24b-2ae2-41a1-8110-0ceb28f4ec42', 'Timbo3203', 'Timbo3203', 'timothyhardin529@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$gqk8eKSH08FdrBCh9WDCh.mEo.dEf.SBuxAtXjXOsMr.5/h4A3Oeu', NULL, '2026-06-19 06:34:07', '2026-09-17 11:17:55'),
(534, '99f51d46-00cf-4843-8531-7ef605055df4', 'LadyG23', 'LadyG23', 'juicybootyboi1826@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$svkn.scPDS93iZo33Df0Ou6mvfE34d/oowILbF9eiy5mMvSzCe3SO', NULL, '2026-06-19 08:33:07', '2026-09-17 11:17:55'),
(535, '640259ab-9592-43a0-8b4d-3725bc16093f', 'HUNGLOH', 'HUNGLOH', 'yuirroyalheinous@gmail.com', '+14159000344', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$iN3mhr0VhiSp9ZXDr8TkEurBefmCe8pQoIW0pMj1yJVy9XLhHIPUO', NULL, '2026-06-19 10:54:59', '2026-09-17 11:17:55'),
(536, 'd13cabf8-8be3-4256-b0b8-d023bcda6dd8', 'favelastep', 'favelastep', 'favelastephanie089@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fncucxY2Qak8FaG0RgvLXOVLDAdL/3f5wYlW13Whd678y4NnNvAh.', NULL, '2026-06-19 13:18:19', '2026-09-17 11:17:55'),
(537, 'aef5e93a-d84d-470a-b0ce-ea7ca0b3829a', 'Martin5151', 'Martin5151', 'kimkimpalmer1975@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$.cEED.QfRzW0XRYbMHtXhuli7Db2eiGkAAtY6Q.kN6QxH78V6Gqfi', NULL, '2026-06-19 16:59:48', '2026-09-17 11:17:55'),
(538, '3b69b85b-75b7-476a-ad94-02659ce2eb29', 'lakeitav75', 'lakeitav75', 'lakeitav75@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$AuVSuS.b5xDtf1HBGD7tfOQVQnbxCIqKD/FKUGLQ4saUTCsamZjmO', NULL, '2026-06-19 17:08:09', '2026-09-17 11:17:55'),
(539, '2ef2a87f-3f0e-4a6e-8e1b-aa022d7dfcb5', 'mitch69MPg', 'mitch69MPg', 'mitch69.mp@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Yp.oJXpxV5hmNtwn/UMDyuTpon54NBgOluTpUh6W1mIPZStzAjgbG', NULL, '2026-06-19 22:00:30', '2026-09-17 11:17:55'),
(540, 'c68d7eaf-1d51-4798-b1c8-9a4690692f7a', 'Jasheenm', 'Jasheenm', 'jasheenmaddox@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ykIGvJgIEeAbBgLhTL8n6ONaCLL77mOPD.h19Ttu7Zxvko2EHgtzu', NULL, '2026-06-20 00:40:21', '2026-09-17 11:17:55'),
(541, '56aa7183-24e6-4333-a6ba-0566bbac5afb', 'Kirsychap', 'Kirsychap', 'kristinpeters5454@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YdiFdudkeII6IAWFP/zqfetOtxjJkLpYXEyBuvT8iVdIBMprrIL2u', NULL, '2026-06-20 01:21:56', '2026-09-17 11:17:55'),
(542, '385cde3e-567d-4a93-87e3-3fcf81c85490', 'Jean64', 'Jean64', 'jeanwakefield64@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Jvp5v8O9gMI3M1/Y1qBIV.VpSsfXE2RMLHlyGtnzaEwq.bGt/dzc6', NULL, '2026-06-20 02:21:25', '2026-09-17 11:17:55'),
(543, '809833cd-f084-4516-9907-bfbb82b3cdc1', 'Csuttz', 'Csuttz', 'csuttz.mts33@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MafxNGFX7PRkewKY2b5mMunotPjHvO.alk1XMomEU8J6sdtlegEbG', NULL, '2026-06-20 15:40:25', '2026-09-17 11:17:55'),
(544, '0063bebf-d504-4e6f-8e5c-74b55971a301', 'DILF311', 'DILF311', 'meyernicholas777@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tIkMLaa6lXqEIu/l5GqbXOGHhm6PjgPx8DV0ANCnZM7ZvlgRTqK3e', NULL, '2026-06-20 17:18:29', '2026-09-17 11:17:55'),
(545, 'fe15bf1f-310c-4c9f-931b-fa9d26bb1d98', 'DILF31189', 'DILF31189', 'nick11389911@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$wEQMQz4TGRhp0X2sEwgCGu6HfjFhpZbMcUW3UHQv8bIwQQ12zCzh2', NULL, '2026-06-20 17:20:19', '2026-09-17 11:17:55'),
(546, 'cd3bc8bb-6e6a-4996-9b53-5da1000e039c', 'Sprunki20', 'Sprunki20', 'bleedking.409@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SuLfQotr1ONUgnzJ59l2heEhd1nKxx8pjhI6yUHccUqpthTx5mZyO', NULL, '2026-06-20 17:35:36', '2026-09-17 11:17:55'),
(547, '72955d0c-ae3b-4e9a-aa54-9cf032d198b1', 'Funsize80', 'Funsize80', 'lisaportillio@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SGvi8Zi4dQC9bOSCGLX76.T7ZxTzYQpt./.4yjE7Iarv1Yaz194aC', NULL, '2026-06-20 17:49:46', '2026-09-17 11:17:55'),
(548, '06721f4e-5d86-4c88-8b51-b19d00bca328', 'brownjacki', 'brownjacki', 'brown.jackie6262@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2lB05KwDzxqFib2so8XuheUqMSonwv5SZL7hRtY0cCVIvvoSrD3Su', NULL, '2026-06-25 00:28:53', '2026-09-17 11:17:55'),
(549, '52d831eb-6200-4077-9879-d7b4dac441db', 'maximinopa', 'maximinopa', 'maximinopadilla5@gmail.com', '+19366752842', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vR7D3GS0j99o7O8Q3pOg0e9CmLA7/IM92xKp9tIYYj0nlSQtSwlFe', NULL, '2026-06-20 22:12:57', '2026-09-17 11:17:55'),
(550, '12d9ca8b-7543-4e37-b74f-42f3774a6459', 'bebehguurl', 'bebehguurl', 'bebehguurrlll@gmail.com', '+18087615247', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$V6uHt8CVAVpmezOXT21AwefqHptEbkDSwlo/.7LW4MZdVlEvD24Sq', NULL, '2026-06-21 00:40:08', '2026-09-17 11:17:55'),
(551, '57fb7a61-b018-4f57-9f89-37249870b0a9', 'Foethalove', 'Foethalove', 'foethaloveofjaaayy@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$PpzAth75/X5jKBSofYY5yOS1fPBzJlTdzo061S4E0DB9wcqCik8AK', NULL, '2026-06-21 01:52:38', '2026-09-17 11:17:55'),
(552, '9cc4b9d9-4780-41a8-a165-1ea43971862d', 'Sonyag80', 'Sonyag80', 'sonyaguiterrez143@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$L/g8b2BKx0QbW3igXFHJmOhIK7NhrQ4/Do4Y9LFlAPC98tSlMox0i', NULL, '2026-06-21 03:47:13', '2026-09-17 11:17:55'),
(553, '7010c523-c95d-4176-a1d2-ad1c20d2fa2b', 'Robo198666', 'Robo198666', 'rbooth1115@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5LL0YsnDfQtpozdcjIH7X.auHE7Uk39YZZ5g2ExuKgJwvvYxa5jLa', NULL, '2026-06-21 06:26:06', '2026-09-17 11:17:55'),
(554, '7872ba20-e6c3-49b2-be5e-8a32f1d9d8ea', '1mochance9', '1mochance9', 'ericwinston8379@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qcr693zMA2rpUbszEyLWxObWXMKfmIkblMirrjSNSNAzzFnu4n7sG', NULL, '2026-06-21 09:31:15', '2026-09-17 11:17:55'),
(555, 'd0cd0c68-db58-406b-b8c6-9c541f369df1', 'leon69', 'leon69', 'leonstansifer69@gmail.com', '+17016515825', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$54XBXAdbtTcwmxw0ugMOWu5eAFvt.E5fVCevLYIz/5dHZE4oio.Au', NULL, '2026-06-21 12:48:19', '2026-09-17 11:17:55'),
(556, 'd1b5c798-e49a-45dc-a2f6-2d7be82e5986', 'Trin4nich', 'Trin4nich', 'trin4nich@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$NvtMc6X6CvLxS5U9/oS2setRocq5l.gXv2Y3nDuaRV3RL1VbfOzyK', NULL, '2026-06-21 13:22:09', '2026-09-17 11:17:55'),
(557, '1370c387-b625-4e0d-95ad-4b762d2322e5', 'oestreichm', 'oestreichm', 'oestreichmax273@gmail.com', '+13083603294', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$cVN5ecdkXniFhZEwGMfvVu38A7Ji/2r9RyEq64hFYm0qI.EVBX9YS', NULL, '2026-06-22 21:08:11', '2026-09-17 11:17:55'),
(558, '22b1ae6f-562b-4bd9-9a71-8fc5c905316c', 'amberlee23', 'amberlee23', 'brittanylovesharley9190@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CQDxdq0jx6xMsyOSHopTwOP98w/0O9H6RmQ66KK8fQnmSACbN8zvC', NULL, '2026-06-22 21:40:00', '2026-09-17 11:17:55'),
(559, 'cd01686b-df30-40db-a611-40d8bd25949f', 'Ravensmind', 'Ravensmind', 'obsaddicted1007@gmail.com', '+15805041383', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$P2YXPaFYOLODaIoGFNBYwuf3DhMU6OgL2lnsFYWlavykP900IPn1m', NULL, '2026-06-23 00:09:22', '2026-09-17 11:17:55'),
(560, 'c3547a30-c585-4e5d-b785-9e03b23828c0', 'Sexychel26', 'Sexychel26', 'michelllynnt@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$AoI2XItxDyt8N3MW.TvOSuj123x7GGMzcldKMcyEtJEcAFqLiOWV.', NULL, '2026-06-23 02:40:41', '2026-09-17 11:17:55'),
(561, 'ec968575-0033-428e-a33f-87868bce61c5', 'Penny Chaffins', 'chaffip', 'plchaffins@gmail.com', '(386) 389-0554', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/ec968575-0033-428e-a33f-87868bce61c5/avatar.jpg?t=1782072554947', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Florida', 'Female', '1965-09-03', 1, NULL, NULL, '$2y$12$iOjnYTNAK2ck18yR8U15YO/4cTkkuL5HOiVEXiuh94qBYvc8Obz5C', NULL, '2026-06-21 13:43:18', '2026-09-17 11:17:55'),
(562, 'eee38cc3-d5f7-46f7-88c3-c2a3bbf9a4c1', 'Tduke352', 'Tduke352', 'williamduke9696@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$enKm7iStBtKu/5FP1jsmHuGsexj0wcPc4tHb70rHznMrdkW.5B.yy', NULL, '2026-06-23 03:35:24', '2026-09-17 11:17:55'),
(563, 'c50e5f53-2133-4844-98f4-4ba502280361', 'Robert Hribal', 'Rh631640', 'rhri1982@gmail.com', '+16083529303', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Illinois', 'Male', '1982-09-25', 1, NULL, NULL, '$2y$10$txZIClUuMmsvLNLtizPnuu5Ku995Nby3wv7gJXqXalO/FzvkZ/8B2', NULL, '2026-06-21 18:32:20', '2026-09-17 11:17:55'),
(564, '3cae7732-3ddb-4557-85ac-336affc44a06', 'Bowman138', 'Bowman138', 'bowmanwayne768@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LA33jtylzhg.kJFx5DsAreWm8W6QKFitCUoYq6mtTNfuQ3Nkuo0Ju', NULL, '2026-06-21 20:11:38', '2026-09-17 11:17:55'),
(565, '5920bcd9-5af5-4ea8-bf07-1ec8cd309724', 'Michael83', 'Michael83', 'sanchez83michael11@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JNus.ymy7I9Ro2vqIw3MsOBint1YIRQaz7tADpAeeue3wO3zqeKAK', NULL, '2026-06-23 03:52:25', '2026-09-17 11:17:55'),
(566, 'aa30da08-4f47-492b-a82f-e403a6880af4', 'SoeCold', 'SoeCold', 'soecold430@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$XdE55Uv5LvBPaNIfQhYUseP2XBSJWokIzpFzhKOaTW55A8HK1npqC', NULL, '2026-06-23 06:20:45', '2026-09-17 11:17:55'),
(567, 'f450c1c3-0a0b-4777-aa93-c092fd8733bc', 'Erin Tinsley', 'ErinKc777', 'erintinsley698@gmail.com', '(864) 357-2595', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/f450c1c3-0a0b-4777-aa93-c092fd8733bc/avatar.jpeg?t=1782102291123', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'South Carolina', 'Female', '2026-06-22', 1, NULL, NULL, '$2y$10$ACfrfxwyFsOAI965YU8QeepD4JLh6UlUZMrXJWtcQ809n/YXuMfrG', NULL, '2026-06-21 18:27:08', '2026-09-17 11:17:55'),
(568, '490cfd74-ae97-40be-9c53-3808844fd2f5', 'Reddbone48', 'Reddbone48', 'tootieredd2025@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$73GrUpNMXFlfOoAq3jlfY.w/iitS4dBgZxzc3rrKEOK6QcosLO8QO', NULL, '2026-06-22 01:17:01', '2026-09-17 11:17:55'),
(569, '4bbf73cb-ba56-42d3-a3db-d07117bd02fa', 'Blacbaby39', 'Blacbaby39', 'virgillakeita02@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$h1PUW12CbNUy50eioas1pechTudr2ANp0O6ZLUF/JlN/xkva290wq', NULL, '2026-06-22 02:48:48', '2026-09-17 11:17:55'),
(570, 'd6eddc8a-cbce-4f0c-8b76-39b88986e54b', 'Tdmoney', 'Tdmoney', 'tdmaug85@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mUBJK3Fjfgq1ALA8l8jYmubR9JrPYSCaDFVjCFL.DCj0/R0RUknOO', NULL, '2026-06-22 08:27:41', '2026-09-17 11:17:55'),
(571, '00435085-6b34-4866-bf81-403cbdc53c29', 'Jrtolliver', 'Jrtolliver', 'julietolliver0@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$KaHM0U3xvfOjADf.830VJuV9aYynazlyL/HxxqwFbelkiNLX7NUXm', NULL, '2026-06-22 10:02:38', '2026-09-17 11:17:55'),
(572, 'cda341e0-06c6-4a6f-bacb-d49000136ce3', 'victam1992', 'victam1992', 'victam1992@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VjT.zkfNQKcPvp4ESuNcmuCNVB1c/n8Hv1CWWh5JgwjLFunUpE3Jy', NULL, '2026-06-22 11:47:32', '2026-09-17 11:17:55'),
(573, '8d29f927-2b4e-494f-b586-1b37390375cd', 'wrightjena', 'wrightjena', 'wrightjena5@gmail.com', '+12254935425', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DhHQ50BDW6jnxvEaTP/vZeKp/FGCjgvSCcSyVfwnlW6KMjHNvMKGy', NULL, '2026-06-22 13:42:12', '2026-09-17 11:17:55'),
(574, 'd5305fc4-5211-4cda-b743-c69c8ab28779', 'Buddmart', 'Buddmart', 'buddmart1981@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$L8HRLjDaPSlYrf9BzcNH9eKw.wsZeaIgKn9xnXnxYCuuhvBrvPvI.', NULL, '2026-06-23 16:44:04', '2026-09-17 11:17:55'),
(575, '466a6042-75e3-47ab-9165-96cf14de8f01', 'Rednose', 'Rednose', 'kissmygrits6924@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$kCTjMo/w1WTI/8snDXXjV.Mqt9xmWGP2otYGo6StHutTHpoETJ.7i', NULL, '2026-06-25 16:37:18', '2026-09-17 11:17:55'),
(576, 'e316b505-3649-4621-bff3-1486d75a85a4', 'Glen22', 'Glen22', 'f90612387@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JAJUWfFRObg9ObgmziNU7ORvFAk0UZpA4kg6jxCemjE/qL/nKoIse', NULL, '2026-06-25 21:51:45', '2026-09-17 11:17:55'),
(577, '6fd783aa-825a-4b1d-a05f-d5ac7d0c1724', 'Kelly Lopez', 'KellyB327', 'kellyberry948@gmail.com', '+12543140552', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1973-03-27', 1, NULL, NULL, '$2y$10$O9j60jkBi13tUPUuT3n7W.fuwpbSM88gbbQ1COBwnFDLQnGpy9xei', NULL, '2026-06-23 14:51:16', '2026-09-17 11:17:55'),
(578, 'e9181810-7c2e-47c8-a84c-5debe6cb2361', 'Dylan Birmingham', 'DylanBham', 'dylan.bham@ymail.com', '+14793328023', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/e9181810-7c2e-47c8-a84c-5debe6cb2361/avatar.jpg?t=1782173079246', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Arkansas', 'Male', '1993-02-25', 1, NULL, NULL, '$2y$10$hzxLpm4mR7tBfR6CEcxCvu2ufdNOIBLPdXZ2648jqR3WF32Rtzwku', NULL, '2026-06-22 17:54:27', '2026-09-17 11:17:55'),
(579, '198cb2f4-640f-4ad1-9ed0-506683ae3495', 'Jaimeea13', 'Jaimeea13', 'laylagirl4578@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$PhXfX1WFmINxmLZwI5hsB.2T7zobYlbCIIafiiGQEnIjxSuXROnDq', NULL, '2026-06-23 23:23:25', '2026-09-17 11:17:55'),
(580, '48d3a0b9-ed63-4644-ac8e-add6f24bb339', 'ReyRae', 'ReyRae', 'randiwhorton5@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$HjUOo88ygcqqJTNqHhtJeeFuy09dcBuhQq54oFaqokNVJJM0KEovi', NULL, '2026-06-24 05:23:02', '2026-09-17 11:17:55'),
(581, '1983e518-7219-420e-b2d6-adb890bb10d6', 'luckielean', 'luckielean', 'luckieleanne11@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$q4ix4N.DPa14QZhK6GjLPOuJphCjGwoK8ormQ2x9RkwNTUah83NqK', NULL, '2026-06-24 15:19:13', '2026-09-17 11:17:55'),
(582, '165c1428-2a3d-48e6-b194-4447cbeddfa9', 'Pottslean', 'Pottslean', 'sue62960@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$nHQj8WvXLJ.eAlp48Xgo0uWLtbpfUotgneeOB2LEoz5PowsUkU7Vy', NULL, '2026-06-24 15:20:16', '2026-09-17 11:17:55'),
(583, 'c0739406-2f8e-4712-a8e4-af7369e892aa', 'Leanne', 'Leanne', 'leanneluckie4@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$BJJw3w48TDaJwSe73SQYNOtZhomwiZUFoVU4DoRArm1ggJJ2RKvme', NULL, '2026-06-24 15:24:47', '2026-09-17 11:17:55'),
(584, '985cd31a-9cf6-45b6-aac1-67b0caeca496', 'elisa103', 'elisa103', 'elisina916@gmail.com', '+19045789623', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CgmCAcIfQ1mMlK/rVjlgLuC1jwNfVTg/xBbTRdDSEyqckWH3DbVn.', NULL, '2026-06-24 16:31:48', '2026-09-17 11:17:55'),
(585, '81380b18-00b7-4c42-b6d1-a0aec10329bf', 'Cognac17', 'Cognac17', 'bjicorey@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VvF94zr2ghyDAuL95BRvCexF//2uhyfkeAZr/3uLW3kTjR1JzcC7W', NULL, '2026-06-24 18:03:23', '2026-09-17 11:17:55'),
(586, '240699bf-6ec3-40cb-aad6-a6aefc6a2d58', 'EazyWest', 'EazyWest', 'israelnavarro699@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$yvUXQ4RSTAoywS0fbloPguR6Z/t5SHwP8TxO5eoqtJHlyaLX8XuDq', NULL, '2026-06-24 22:54:35', '2026-09-17 11:17:55'),
(587, 'd6d0e296-75a8-4f53-bd23-90265bb99411', 'Kate Prater', 'K8lyn1286', 'k8lyn1286@gmail.com', '(945) 371-9793', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/d6d0e296-75a8-4f53-bd23-90265bb99411/avatar.jpg?t=1782374663341', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1992-10-15', 1, NULL, NULL, '$2y$10$f1yjUpidyZ1WDMnORgvpmuXmEXCdY9tK0Wn6vvw6JSFNauclafoFu', NULL, '2026-06-25 01:57:49', '2026-09-17 11:17:55'),
(588, '99414d63-0948-46eb-bde8-04f3383464e9', 'Malachi', 'Malachi', 'malachiterry0509@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$X04wtkhlhjPjYuCP97Ug9utajGIEszm8WTAIdz0.Rd5S503XmbkD2', NULL, '2026-06-25 08:47:04', '2026-09-17 11:17:55'),
(589, '1b2d471f-8e70-40e1-8d71-0f9d7f6c63f5', 'Doggy90', 'Doggy90', 'oliviahjune2019@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$23DKpT.JkLDPIYtyLqzTpe8QMUqccLGoNGfn84ZJAPxrTs0Ayvl4K', NULL, '2026-06-25 15:59:39', '2026-09-17 11:17:55'),
(590, '9834e0c2-31e6-42a7-8061-7ac105e9b504', 'BigD1467', 'BigD1467', 'drs76031@gmail.com', '+16822225751', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Z/NImIkMlpU7A92v5CEB9.77ArjCS55UVNBYD0fkT20QuukGoNJeS', NULL, '2026-06-25 21:56:27', '2026-09-17 11:17:55'),
(591, '14962f4e-cb76-4481-9ac7-0e8ac0cb0d16', 'Tommyyum81', 'Tommyyum81', 'forevercazey02@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$j4gfQzWlP/YR5IAo8XSmsu0DyEAD6GiuyXUXc6nUyzcSaIkrAvrh6', NULL, '2026-06-25 23:51:00', '2026-09-17 11:17:55'),
(592, '85d4786a-46ef-4c46-aa74-b818e4f95925', 'deannapost', 'deannapost', 'deannapostol82@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$XEWlc7/pQEEci.rRq0ZXfeBl5zee1NCymHDN6R1iVIsJ8eGbtjKXS', NULL, '2026-06-26 00:46:11', '2026-09-17 11:17:55'),
(593, 'a7564e09-979b-4930-9633-4912d68b5b6a', 'Kaiguy1', 'Kaiguy1', 'kingkai7171@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$yIEOPdUKf2OEGAenIQGXQe.A4JY1RIQ06zEEhafwL6IZx3ab2YuIC', NULL, '2026-06-26 00:50:24', '2026-09-17 11:17:55'),
(594, 'c726264e-230c-4836-9391-457f86f4d73a', 'Rudown', 'Rudown', 'jesseavl559@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$N.0QtUXhwIdeR90/2IBNiugwoB9DYKBQURaSOaV.3y7mymVYferFK', NULL, '2026-06-26 15:01:45', '2026-09-17 11:17:55'),
(595, '7376eb4a-34f5-423f-b10f-9d77b8b2a402', 'Lilbugg8', 'Lilbugg8', 'misslilyduhh920@gmail.com', '+15593109369', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Female', '1988-09-20', 1, NULL, NULL, '$2y$10$kNKPn4YrFrV1qgEGlfdVKOs20NXFdxiU98u7/kF8BeY2w8/K3a11O', NULL, '2026-06-26 19:24:43', '2026-09-17 11:17:55'),
(596, 'e039daee-c6c3-43b8-828c-9be3ecbacbdf', 'gouveiabra', 'gouveiabra', 'gouveiabrandii@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$3rxAZsXFG9GTfGZU1hUmaO5xeNHOAmtxGxsNINQ1KrPf.eT4/fXxS', NULL, '2026-06-26 22:07:32', '2026-09-17 11:17:55'),
(597, '789ccc47-77c1-497a-bb1e-428595417bd9', 'MarcusD', 'MarcusD', 'mossburge2025@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$82cBMvleg59HQKnjAaW8keCC37/md2yRGqpHemGo8ZRKV05NN9Yw.', NULL, '2026-06-26 22:38:34', '2026-09-17 11:17:55'),
(598, '7fe843fa-eca6-4f39-8b1b-d321452b815b', 'dmleavitt6', 'dmleavitt6', 'dmleavitt65@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$w4sjC7otUgaINYt2rnE2COMB/.AnIX7iBu8ZTu60Z0BBhGPiWmMzK', NULL, '2026-09-04 21:56:23', '2026-09-17 11:17:55'),
(599, '4e4ec88d-802a-4082-86c2-2a1c6ab398f1', 'Sean909', 'Sean909', 'seanalmendarez4@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$bViAL0rIjrCTwDGEtcmjgumtK3rp.Fsf8KTF.8BViGotK6s2cwiWS', NULL, '2026-06-27 02:17:20', '2026-09-17 11:17:55');
INSERT INTO `users` (`id`, `legacy_id`, `name`, `username`, `email`, `phone`, `avatar_url`, `ghl_contact_id`, `balance`, `role`, `is_flagged`, `flagged_reason`, `flagged_at`, `email_verified_by_admin`, `phone_verified`, `phone_verified_at`, `country`, `state`, `gender`, `date_of_birth`, `email_notifications`, `email_verified_at`, `last_login_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(600, '791f1b20-3764-4440-9899-0d8d018bba0b', 'Jere666', 'Jere666', 'sanddd32@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RNzBYgdtr.emyylII3i6RePSsdbbsxudG4j8Ci2EHtqNy2JcLZ8g.', NULL, '2026-06-27 08:13:38', '2026-09-17 11:17:55'),
(601, '425d15fd-b01d-41c1-a9b3-d45f602ba1f0', 'anorma123', 'anorma123', 'normaaraiza192@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xTUvtSiROjV0lq3.y2Hyt.3LPxpqZsh1DQ4DPEH.Qi9by714eOy02', NULL, '2026-06-27 08:16:45', '2026-09-17 11:17:55'),
(602, '340d3e8a-360d-4149-ab0a-f8ee625f24d5', 'Dcarda13', 'Dcarda13', 'davidc18211@outlook.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5IcKf7MRu0pulRWyFU5Xt.PIgz8Tp8SX22gMRoCn7gswmZD8VLxQK', NULL, '2026-06-27 13:13:55', '2026-09-17 11:17:55'),
(603, '64da582d-d360-4bf8-88fd-e9c7c3cbf038', 'Raelee', 'Raelee', 'fordfelesia@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mMiZrp59ANk/PbgqdG89Z..8jCK0Jh0yMEjA.0rrTqbvJmirWhsIy', NULL, '2026-06-27 21:29:07', '2026-09-17 11:17:55'),
(604, '90155cbd-4454-499b-bc0f-f314f3535224', 'Dollarr542', 'Dollarr542', 'rogerdoller92@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$oePLogE9SZzGCuw78GWSE.JfpNT1JWe/l9qcU/rZNMW.hF8eswsCe', NULL, '2026-06-28 00:00:38', '2026-09-17 11:17:55'),
(605, 'd89e4670-2791-4a4b-ac21-d317a1fd2633', 'Trayday37', 'Trayday37', 'travycarushing8@gmail.com', '+13182654817', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qVfIW/EGluRQunk7716gfOY1gqOd1nogEi7rsg2F2cfdjBL1aJSli', NULL, '2026-06-27 23:41:32', '2026-09-17 11:17:55'),
(606, '0496e6a8-99cc-4bb4-a496-68f6579d8a53', 'Blessed760', 'Blessed760', 'bendecida4991@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7PRIFHvgo5RfA1w76AMrXe7amydZYWeAHuCk/nESkGeJksPKp76ry', NULL, '2026-06-28 02:08:05', '2026-09-17 11:17:55'),
(607, '5f321401-c3ac-4867-bd3d-9bbbaf0808c2', 'Derrick78', 'Derrick78', 'grissommark229@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7feISo3Cq/Lmklgi1NGJnOF.MFC/QIZk.HD6bueZgEnS9IY/ZOak2', NULL, '2026-06-28 08:46:34', '2026-09-17 11:17:55'),
(608, '28b02afd-0278-491d-b396-de85935078bb', 'Buscvin74', 'Buscvin74', 'cherokeebandit74@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$UCOfGHQTcEur.grzKlCUNuha5S8eYu1lhkA1at8x2M4eOr0u7yavO', NULL, '2026-06-28 08:55:01', '2026-09-17 11:17:55'),
(609, 'e4ad1aac-47cf-43d7-877a-8076f63b9df1', 'Luvpup80', 'Luvpup80', 'stacyfreer65@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$EGeff/7MoUGvwSmiIZGAXes8OnORcCqz65UvsWRxMksw1f7B0PQGW', NULL, '2026-06-28 17:16:33', '2026-09-17 11:17:55'),
(610, 'ebe4880d-edd0-4471-814d-d444a647a3fc', 'Bonita91', 'Bonita91', 'kiararauls3@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ueveCw7ovQRfLepJmr82/eJASs5SRvu6fz3PxJorthN31WGC2dLOi', NULL, '2026-06-28 20:09:27', '2026-09-17 11:17:55'),
(611, '0f3e2eaf-8dd3-474f-8c80-aa96c79d8fac', 'Brownbeaut', 'Brownbeaut', 'bonitadasher1991@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$iZcKtShTsQRT4LbQqSHlb.NxWS/fLzbEs1uxby/TgdOgq5.je9WDK', NULL, '2026-06-28 20:14:04', '2026-09-17 11:17:55'),
(612, '5e0f4bde-4b20-4b53-986c-b5b88f1ecbee', 'fit2thej2b', 'fit2thej2b', 'fit2thej@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$p7JiX.oxM/vsWzBUDgk.ee2s.YGGF6WOV2vmQgt1mRLlwIOTj3oda', NULL, '2026-06-28 22:34:48', '2026-09-17 11:17:55'),
(613, '7678380c-1092-41b4-bbbe-0fe915bfcc44', 'Steven8594', 'Steven8594', 'steven.johnson85@outlook.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6I6AJoTV50LGmkFp3Tq1neiRJpxeznlh0zdHDftT.Zv4gAHbTc5qe', NULL, '2026-06-29 00:06:12', '2026-09-17 11:17:55'),
(614, '6a1cacb7-c402-4317-9ea9-0d27ca90070b', 'Kandia89', 'Kandia89', 'kandis620@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5lY1.8fhUYUdn8pb0/Yd8uMWD7spwFACRlHkyxXY9FilmycRQ6CMa', NULL, '2026-06-29 01:27:53', '2026-09-17 11:17:55'),
(615, 'd11067f1-a69e-40bf-9710-17a3bdf127e9', '5207418', '5207418', 'padrontim176@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Bsj7n6XWB/CwR.h7AHtDKuXrJPjT7thmMWxjnlsXr7EebBkBTnkFS', NULL, '2026-06-29 03:19:35', '2026-09-17 11:17:55'),
(616, '8a9c9162-96d0-4a59-a96a-316106040ca5', 'QueenBee88', 'QueenBee88', 'faith.mulligan@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VmPzWSjWny95YDifVpH1oue5kcj3SOQ8ncT1LVZDPmsMkqr4Envse', NULL, '2026-06-29 03:36:52', '2026-09-17 11:17:55'),
(617, '3922ec2c-3039-4b1b-8a91-c39fce62b638', 'king1991', 'king1991', 'luccyleo91@gmail.com', '+14793533866', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$e7u6/3zdT2vEbtEWaVtD8e6ajpadqcnpnxMQgfuenCgdHthcQrHqm', NULL, '2026-06-29 09:52:37', '2026-09-17 11:17:55'),
(618, '5e7c77b9-2323-4596-86ed-6e7688747e4f', 'oliverstep', 'oliverstep', 'olistep6@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fpS1zAMekQevesJB3ehugO00hWewME18f9uHtDxmWghDSu8LLBala', NULL, '2026-06-29 19:45:02', '2026-09-17 11:17:55'),
(619, '013893f6-2f1b-497a-bcc9-7a805d8506f9', 'LiphIzLiph', 'LiphIzLiph', 'joy749953@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uXNq1Q8T8bJ8k4xevT1S3.j/fI6tYHOgwnaNZx4JxcsrfXbtqHQue', NULL, '2026-06-29 19:46:27', '2026-09-17 11:17:55'),
(620, '1ddff408-938d-498f-8c80-d565fdd89811', 'Letmekno', 'Letmekno', 'polkrandy356@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4rRYxcFnx7UnabA0quws5Of6XVI0CI6ApuWD3riAXw7U1JM7U9vLW', NULL, '2026-06-30 03:25:23', '2026-09-17 11:17:55'),
(621, 'a93778ae-afce-4282-a38b-7474e8a50bc3', 'Donjay', 'Donjay', 'donetta229@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Czg0WyR8aT0U4wikGDmyN.bXiD2doglC9bxADRf5T3SZMd1gA5.Ky', NULL, '2026-07-01 04:08:55', '2026-09-17 11:17:55'),
(622, 'f071a306-85b4-41c5-8008-40f19587a01f', 'Cjlwhs', 'Cjlwhs', 'cjlabonte1@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DhvenPMmPYAVZNOBoRO6.uL2gL/nzyO6fprkHG8IVWOU/sMwrtcgW', NULL, '2026-07-01 21:33:23', '2026-09-17 11:17:55'),
(623, '3c04bdc1-c3fa-4231-acb6-ea11eeebac09', 'ErnieG', 'ErnieG', 'ea69696981@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZKTpjt0LJ17QE7RDjR9oseBlkVGXbwADVuth16YIqiWQPgymHhOpy', NULL, '2026-07-02 01:40:56', '2026-09-17 11:17:55'),
(624, 'f84b017f-6db3-4a59-8b16-35c1a5cce2ea', 'Nolaniknok', 'Nolaniknok', 'nkogassagoon@gmail.com', '+19077172621', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Jj0aZeQ3UDv1829WvwmJw.Vq/Ghf.O/FtoNvEA24HohBg8i.GxZKK', NULL, '2026-06-19 09:43:02', '2026-09-17 11:17:55'),
(625, '36fe9036-1fee-4050-a189-cb98767808b4', 'gigihewett', 'gigihewett', 'gigihewett52@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SPoIDrCrDIQp2Zu9N9H05.QVLy96bMpnuHVTN3OXMtFUV2PKuDqiW', NULL, '2026-07-02 02:16:15', '2026-09-17 11:17:55'),
(626, '576745cc-7a9a-4cd6-81ef-977f90db777e', 'Givove72', 'Givove72', 'dray19684@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$QeysFK.EruX.LSL.bvTeA.bnXVsR8R5HhP4oyCdeGoSuFWKpevhWG', NULL, '2026-07-02 02:19:06', '2026-09-17 11:17:55'),
(627, '33b81f2e-9433-4b51-873d-b19e191be3ce', 'jasjasbby4', 'jasjasbby4', 'samheidt400@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CRHv25Azs4ygFMwXeHCEdO1co3LBdyaDIapltrRlumBOYxCdcv6ta', NULL, '2026-07-02 04:37:26', '2026-09-17 11:17:55'),
(628, '360f2537-c171-4a26-9bd0-0e8180803207', 'Lyfe4480', 'Lyfe4480', 'gboundd80@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uX24GCMDgTuYJHCHZOLc0e5eOa8D4tWSvl8PYDUKwuIE1pwBmeduC', NULL, '2026-07-02 14:49:54', '2026-09-17 11:17:55'),
(629, 'e2d3a4b4-4e93-4e3b-9ac0-b631c0a6f820', 'Optimal', 'Optimal', 'ikilledgoku@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$TIVCdHaJlkCHFDNVtuszFOK7dWD.4ld9VpRviJy7ul/Crke.FHVvm', NULL, '2026-07-02 15:28:21', '2026-09-17 11:17:55'),
(630, '44f6cd4f-1f4d-47d2-9cf6-f400f7aa324d', 'BigbagT804', 'BigbagT804', 'tiffanydollar72@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Li4coZDYoajiqqTFJuKUIOnO8NSOZPGfYiWp1MsHwN71EOwFehqzO', NULL, '2026-07-02 18:53:50', '2026-09-17 11:17:55'),
(631, 'e2de7cbb-c9a9-403c-8131-df09abceb9ed', 'Erika1111', 'Erika1111', 'lostmyphone8880@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$phRp3FIOxD/Z3Nz3tVyiyOf/OTb3ieNjeJddsMX1eql3S9wMeZzjm', NULL, '2026-07-04 00:46:20', '2026-09-17 11:17:55'),
(632, '242b5cee-04b6-4b23-b95c-8d822e5e8f9b', 'SyflYbnr', 'SyflYbnr', 'ttlodies@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qoauVAf0Q3DGwnbegVdJTOma8rv2DqT9b0uDmozkww/QUvhRVRA.e', NULL, '2026-07-04 01:00:26', '2026-09-17 11:17:55'),
(633, 'fba53bf4-9129-45a0-ab4d-1c35aa119203', 'Bigbag804', 'Bigbag804', 'dollartimelife76@gmail.com', '(804) 619-2155', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Virginia', 'Female', '1991-10-12', 1, NULL, NULL, '$2y$10$IcS8Blsi6lnBxKnE8w8CmOI66e6MZse6dIrmPXFTQKTaa9T4Tc65m', NULL, '2026-07-02 18:51:41', '2026-09-17 11:17:55'),
(634, '003b8087-7aa3-4ad3-b462-7b942e7831ff', 'aceanthony', 'aceanthony', 'aceanthonysolis@gmail.com', '+18303088402', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Mk.jLiYRtRCSjibSU4BfF..aczLOcJO0.n9u1fFvj4NiIKAE6kbX2', NULL, '2026-07-02 21:50:59', '2026-09-17 11:17:55'),
(635, '2dadf297-e053-4e76-bc49-cb0aa57d598e', 'shellcasi8', 'shellcasi8', 'shellcasi8201@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/A5tTExyOay4ddptuF6xSuu8GZ3tTIhUdouGn.rrUA/Mf/LwaAtlu', NULL, '2026-07-03 00:44:22', '2026-09-17 11:17:55'),
(636, 'db1c2721-2031-499c-a55b-fc244ac8c4e6', 'danialle37', 'danialle37', 'danialledodd1188@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vSk1bj7a/4qmF4PbpVQM6OUskFBge9H9QlSTAitQyLQK6zuxNN8jW', NULL, '2026-07-03 01:42:07', '2026-09-17 11:17:55'),
(637, 'b3fadcd7-d050-4c4e-a444-89856e80ba1b', 'Chantel84', 'Chantel84', 'morgangreerchantel@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5EoHoYb/RidlvHrBK2.prOEbT0wRLGkCpbknqfpN5nYqBOICxhBPO', NULL, '2026-07-03 07:45:14', '2026-09-17 11:17:55'),
(638, '613283d9-8026-4871-a823-44f958883d85', 'whitneyrur', 'whitneyrur', 'whitneyrurak18@gmail.com', '+19185069978', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$Bozaklx7d2D2gVz.F.N/we/HiNVbiO7cDhU6AgVWwbd7QVPcI2Qxa', NULL, '2026-09-03 19:33:26', '2026-09-17 11:17:55'),
(639, 'e6af4e34-564e-48c2-8cb5-1f41eb0ab4dc', 'Mjgiles78', 'Mjgiles78', 'madlove2931@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VkbT/Zq0L1BXF4xTnjIfUOeIzAIStfUHkFUREkMYA1ayJ16wq2rFG', NULL, '2026-07-04 01:48:43', '2026-09-17 11:17:55'),
(640, 'f3a575b2-1fbf-4078-a968-91e69c516a33', 'Freckles43', 'Freckles43', 'prettyfreckles82@yahoo.com', '+15012952558', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$NSKbHSOUVHpTlZKqVJ1aheQhPQh5Trh0ddoE/A8m.CPFpLkrTvsVe', NULL, '2026-07-02 03:06:40', '2026-09-17 11:17:55'),
(641, '87f93d3f-0609-43b0-b38a-4b739b4ca369', 'HeatheA86', 'HeatheA86', 'heathersonnier007@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$3cnUtjDijG.PISMW2oWOaejTVv2P21OVIWDtyPhPRi01AU.eCMnqC', NULL, '2026-07-03 22:05:01', '2026-09-17 11:17:55'),
(642, '12316c14-1190-4951-adfe-9d62422d65d2', 'brittni888', 'brittni888', 'brittnibarnes888@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fBjueG/QrovsbMxsjVpmXOpB9F/HDrRqCsUh.0F/6.lSXYiZmKpkS', NULL, '2026-07-03 23:22:43', '2026-09-17 11:17:55'),
(643, '8702f015-789d-4fbc-af26-f0dc6374e941', 'joshuaj120', 'joshuaj120', 'joshuajones122517@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$q8nUTsZs5e0DYjbJjgjsp.VIJV2SNnf5MRKamjLn6kGKrgSAy8Nf2', NULL, '2026-07-03 23:48:24', '2026-09-17 11:17:55'),
(644, '1f882802-4cfe-4f08-9aca-c0d6f14d493a', 'slippery1', 'slippery1', 'ttlodies0@hmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uggMR/8uR5o27/U8rDUzNOCo69Or2dIAuVBKi43NPYzyKSpEd3lEe', NULL, '2026-07-04 00:09:40', '2026-09-17 11:17:55'),
(645, 'a1f42a48-d0c6-45d6-96b3-7aa377be7f5f', 'Mkatdon22', 'Mkatdon22', 'mkatdonahue22@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$GvK/5Xlp8fQRM7dgkEseLeVMdaZ60jdAVIS56IFOgttcpWm6d7olu', NULL, '2026-07-02 00:57:08', '2026-09-17 11:17:55'),
(646, '9f7dd192-7ba3-4c5c-b892-536286ac204b', 'QingWavii', 'QingWavii', 'diajanaegraham12@gmail.com', '+12528010432', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$wd83DylpyzWMu9lqT53QD.C6oyiJCKMfQghosaZZxn/z8UptdVnOu', NULL, '2026-07-04 07:19:09', '2026-09-17 11:17:55'),
(647, '58629e79-0ab3-4472-98b4-d6b284d8f025', 'Sappington', 'Sappington', 'charlenepainter80@gmail.com', '+19312611047', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CYcRFUDKtPnOQgHoDZTRN.7hXZZ.LtVajepELTGXI9EaEuo.rrNT6', NULL, '2026-07-04 06:24:39', '2026-09-17 11:17:55'),
(648, '152bc546-8b18-485d-8845-c1576710819c', 'Jonnyboy59', 'Jonnyboy59', 'jonnyboy5973@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2Fo6NnxbKRw/t8vXJFtILO8K4AmVOqXxEdcIvoNMA0QYlLHtFTMei', NULL, '2026-07-04 13:35:27', '2026-09-17 11:17:55'),
(649, '6c82cf85-bfc3-40fc-bf10-adffa113e34b', 'Mikeymc12', 'Mikeymc12', 'mccabemike44@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hrXdmR613je65Cx85dbIBu7foaw1hvj5HqxVJtygOb5A/2hz1zJX.', NULL, '2026-07-04 14:48:15', '2026-09-17 11:17:55'),
(650, '04b1c23a-a8f1-4aac-a145-53e6080f4ca3', 'Melmel247', 'Melmel247', 'melissaleannem@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7.yBhHYNYpwcuMv46gsb1.Plj4SJ2bAyprLNp1fO3KpxzikJ/2IS6', NULL, '2026-07-04 18:45:50', '2026-09-17 11:17:55'),
(651, 'de2a5005-a46f-418c-8f0c-05c4b3ea12a5', 'Ericmatthe', 'Ericmatthe', 'ericmatthew8706@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zfG9itIdBOt.HjkHrLfXUODqa3Ku4t8Jb4zALcj5/u7DJgZfh1Mm.', NULL, '2026-07-04 19:27:20', '2026-09-17 11:17:55'),
(652, '258cdcec-8955-4f43-aa0b-2ccbad35ccbd', 'Dewayne7', 'Dewayne7', 'lewisddustin21@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sZ9lCO0iDakUP2ZrYEJee.4vNejhVkXbtuy0aveV7/VQlZouSApuS', NULL, '2026-07-04 19:56:53', '2026-09-17 11:17:55'),
(653, '7d347d50-81c4-44d4-94f5-687c3050f961', 'Benjismaw', 'Benjismaw', 'sherryshields46@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$nVoV.kSu.bJb7IBd7.aH3O2HC3.VAZeLIvWuHcxL22Y82i.vFiojC', NULL, '2026-07-04 20:33:08', '2026-09-17 11:17:55'),
(654, 'd65e9553-a58c-4d1c-b9fe-54443c446c78', 'lakeyshac7', 'lakeyshac7', 'lakeyshac7@gmail.com', '+12138172962', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$lzvrAl5hUof38gERm8YBEeGwduSRNAFI0vkiZK09hdBQWWig9tPcm', NULL, '2026-07-05 09:02:39', '2026-09-17 11:17:55'),
(655, '8919a75b-ef42-443e-b041-fbf47c696b7d', 'Alishiae77', 'Alishiae77', 'awebabe4@gmail.com', '+18033039345', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$BfSwcDo4q9pegnS255HDyuOEe1Jev2SH9zjTEVD3GhkimIsTdJv2q', NULL, '2026-07-05 14:26:00', '2026-09-17 11:17:55'),
(656, 'f163b2d4-2742-46e1-8e34-14ab304355a2', 'LewisDL', 'LewisDL', 'lewisddustin0331@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JJau/gdZMu6UjELP0/oC7eBpvYXRVs67z9v0QBLZ2znZnTEJTEkY2', NULL, '2026-07-05 15:52:33', '2026-09-17 11:17:55'),
(657, '0d070518-05a9-457f-86c1-2bf84bfaeca5', 'MelissaS12', 'MelissaS12', 'servantezmelissa207@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Uslmb6vDwAmZ5J1moS1WkeAuV49mZYI9LZdnXWjLFNoVqm0/e4dG2', NULL, '2026-07-05 20:12:19', '2026-09-17 11:17:55'),
(658, 'c181446c-e4d2-447c-8d23-81f568172c03', 'Martybean', 'Martybean', 'beanmarty50@gmail.com', '+14172076008', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$27dKZRVlG0JRiikBubiVrusddzSZB4KgL8vjq.ZlMPUeC2MKNZlba', NULL, '2026-09-04 12:15:26', '2026-09-17 11:17:55'),
(659, '7af4c703-2fff-4579-a641-3890a3620252', 'Kaylalea92', 'Kaylalea92', 'kaylalea1992@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VIoadQtw7jVj9IFc0yogXuUetVcXvsxMRHft8ROx3ZEQxIYHeGLMu', NULL, '2026-07-05 20:15:30', '2026-09-17 11:17:55'),
(660, '53670eb6-62b8-41e5-8e30-78f1e7ae6b2d', 'Miiamii89', 'Miiamii89', 'basoerica2@gmail.com', '+18284175694', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$Q0RlZ/.QgkRfKKIm3Ur8KevSY9xIawBedvN1c0kNXZuJgm9UNHqxu', NULL, '2026-07-19 21:27:51', '2026-09-17 11:17:55'),
(661, '4e0f93b4-910c-45e0-95af-f96c224eb0b8', 'dylan Cochran', 'dylancx3', 'dylancochran2013@gmail.com', '(730) 228-8400', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Illinois', 'Male', '1993-01-08', 1, NULL, NULL, '$2y$10$.ulPbKYQACwuWgEHhMqwSO6XlDJHW3rU6JhaeLLniRHsKJcW2C/Fa', NULL, '2026-07-05 20:12:55', '2026-09-17 11:17:55'),
(662, 'f0934e13-1691-4697-8f02-62f5719dca80', 'Michael', 'Michael', 'bellmike2378@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$S2h7l0t6WXD3FdBjp0NduufJK4OOSAGSEXkZYgIgHKyk4d4n5Mz1u', NULL, '2026-07-05 23:00:57', '2026-09-17 11:17:55'),
(663, '6f169735-90d2-4bd0-a893-60387b486a99', 'Zindoohill', 'Zindoohill', 'jjhodge240@gmail.com', '+18327070646', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$k4aFF0pN9CYVG2o2gQSUdeXJA7Ld7dGD7WybqjPFgEb5CXkfxZ8Gu', NULL, '2026-07-06 05:27:43', '2026-09-17 11:17:55'),
(664, 'e4abb37c-bccd-4b84-9177-6ed4b01bc3e2', 'jonesant', 'jonesant', 'jonesant115@gmail.com', '+12294129137', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hy7G5glJRWDmxBv/xLiFIe.5QdI9wZkfd5twKvXDDSbcq8G3so7vi', NULL, '2026-07-06 16:47:37', '2026-09-17 11:17:55'),
(665, '4a0d47df-8681-4edf-be69-45da35e797fc', 'Thinoibh94', 'Thinoibh94', 'tbautistah94@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2gWMkuNeo.Tp/GjZrM4GRungl2HdQpmt61R6eyetYjXOVcSXox/uu', NULL, '2026-07-06 19:31:35', '2026-09-17 11:17:55'),
(666, '0ce6ea63-3eaf-4af0-9b3a-2401855b44e2', 'Galapache', 'Galapache', 'beltranbere610@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$bO.hMXZkyxDtIJ0DHaeMQuoIZQxrBK4xSqI7iN.ZV05J2t9ciFETq', NULL, '2026-07-06 21:38:08', '2026-09-17 11:17:55'),
(667, '797e5ee2-7691-40ea-a44a-3929e2e370ef', 'robertk', 'robertk', 'robertmorock3@gmail.com', '+18134175670', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-17 21:47:15', NULL, '$2y$10$cTVeWEpy4PR9.l2ugCmEP.DHiTVGWdRTKQIvdtptcrpDW1A8YTkOm', NULL, '2026-04-17 21:47:15', '2026-09-17 11:17:55'),
(668, '7c4e11cf-e959-4213-b405-df0f222ab6dc', 'Bammalamma', 'Bammalamma', 'bigboymikey08@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$80q.WmXN8iy2Oppa639KSuaaSFFwHMDwR3hd4iV8Ajrrv51ffpweu', NULL, '2026-07-06 22:05:09', '2026-09-17 11:17:55'),
(669, 'f18f1856-e94e-4602-ab5f-fbac0ab9a6a1', 'LilMama90', 'LilMama90', 'coskeens90@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1IF5xzQL0l.w8J5lep37GeqWxkla1QXfJy5F0aYHKo3VewcSOmNAu', NULL, '2026-07-07 00:20:30', '2026-09-17 11:17:55'),
(670, '4d90d53b-dcd6-410c-8fed-66e523d79b2f', 'Okiechild9', 'Okiechild9', 'ashleeogdon80@gmail.com', '+14796297025', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$aggmhfjXNnnWInzY.fSSVuNtpKxrLBkBoMpJ7RDNxRsySJ5wqDRim', NULL, '2026-07-07 01:19:08', '2026-09-17 11:17:55'),
(671, '4a95a35f-2df2-4e99-b629-9add1d3bd271', 'lulu094', 'lulu094', 'lulurorolala094@gmail.com', '+18087476131', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$EbTfZc/tvxEWdp0nFXFlXeBbE0b5oaiXXRXWNefP49/DrVClkfXjS', NULL, '2026-07-07 03:52:13', '2026-09-17 11:17:55'),
(672, '1d07af9c-f800-4136-9b8c-b5ad9ab426cf', 'Smash247', 'Smash247', 'baddywitdafatty247@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$XuhxbGrp84Cqh.7Ld1ICFObQ0ZGTTib5OIZiUZt8XbUmss4Gsvde2', NULL, '2026-07-07 05:17:18', '2026-09-17 11:17:55'),
(673, '0edcbbc6-86c6-4320-b8e3-083c95ee891d', 'eedwards01', 'eedwards01', 'eedwards012494@gmail.com', '+16064899362', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ygvl7Ct3SdAyeh756iQzieIMelxgTWTHlWeD9gmBw/XlQyqZMlvd.', NULL, '2026-07-07 05:31:11', '2026-09-17 11:17:55'),
(674, '7cbcc382-d1db-4b8c-b30e-d6442e76f6d2', 'Jeremyt24', 'Jeremyt24', 'torresj027@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$oHq71guq1igGZwbQA/rZ5u.qjA3116gSfJ1iaDKeeWLANOKMombHO', NULL, '2026-07-07 15:08:13', '2026-09-17 11:17:55'),
(675, '33b54262-f659-458f-8602-9d473f1380b0', 'sextonjosh', 'sextonjosh', 'sextonjosh1983@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$knJQPEbDCGrLZ1LBTZN2fuLvGgP/2l3tZU6rarRMv8gGJ0CWBLnDm', NULL, '2026-07-07 15:33:20', '2026-09-17 11:17:55'),
(676, 'da69422e-d0ea-458a-9a60-a0f7e06836af', 'Handsome86', 'Handsome86', 'e6177877@gmail.com', '+14094230257', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SU4H66jsgvdhx8X0RlQ75.st1oGUyIz3rvPv.qFHXcvH0adxd20E6', NULL, '2026-07-07 18:29:01', '2026-09-17 11:17:55'),
(677, 'b33b2281-a59f-436a-be75-5931cef2aa78', 'leachumley', 'leachumley', 'leachumley0311@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OVX9.txmRzZZfi6/KGBUruqQIcW9V1x5WnRK8cEwDmYr2xdlDxNJa', NULL, '2026-07-07 19:42:38', '2026-09-17 11:17:55'),
(678, '143b0c4e-21a2-4a54-9ce5-0b1709759989', 'Hughes', 'Hughes', 'mistyhughes155@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$.9nJS6cYj3nSaWxbG3gfgeBkgZWE8quBviMUxa8anlkxhjJMJ29yS', NULL, '2026-07-07 21:20:29', '2026-09-17 11:17:55'),
(679, '330684c0-4983-4a8f-be7e-156a827b966c', 'delmarjone', 'delmarjone', 'delmarjonesred@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$75LhdDcSUGL5BdzkLeZmpuMMzUSwp08Q4yfekFnaI9GP73N.Jt2a2', NULL, '2026-07-07 22:33:37', '2026-09-17 11:17:55'),
(680, '6b55038f-c51b-49a2-a06a-e356232622fe', 'Karmalove1', 'Karmalove1', 'lilbittygirl15@gmail.com', '+16627921154', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$K5k6cJS45rqpZLJGSTjcMeMOnARtLTima8zPMo6RB.fxUVXdwq3JO', NULL, '2026-07-07 23:13:13', '2026-09-17 11:17:55'),
(681, '583a204d-467a-46b7-9396-5b8618f7604a', 'msawesome', 'msawesome', 'suzieq7949@gmail.com', '+14699409580', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Nm0KXmm9mV4rMX6OUPbmRexLibVQg33EZoyayQ0Xai2aOG8mVsyI.', NULL, '2026-07-08 01:12:56', '2026-09-17 11:17:55'),
(682, '31dee1bb-fcc4-479c-b8fb-09e66de017ec', 'Mlcooper84', 'Mlcooper84', 'bammalamma84@gmail.com', '+12052696729', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$oBK5sBktp.jN305Zr2UBQOpH0dTKsYDSdq4IIlimmcJIa5WL4M4Me', NULL, '2026-07-06 23:52:58', '2026-09-17 11:17:55'),
(683, '28d31edd-9f3f-4499-8cbb-6c1cd4f190da', 'grumpybeas', 'grumpybeas', 'grumpybeastclub@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$KeGfQ4kzEb91DCkfA1rNC.twtl5UPFILKrMhWGwLsVm2684Po8Ey6', NULL, '2026-07-08 16:01:00', '2026-09-17 11:17:55'),
(684, '267d3b4e-9259-4550-a198-8cb611b65702', 'Ashleytray', 'Ashleytray', 'ashleytrayal@gmail.com', '+13462243245', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VuggFPH1h3vLrCy4Ppspweom3I1M4PXmhgLOtkpKHd0rq2zC/QoNG', NULL, '2026-07-08 17:35:10', '2026-09-17 11:17:55'),
(685, 'b465e88c-5785-4ffb-a453-a284a273d40a', 'Queenjacky', 'Queenjacky', 'lovemy4brates@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$y.a1b0gCrOwTM/SpvbryheJXqwIeQ22N98R0y9IDIeNcAeEZEToau', NULL, '2026-07-08 18:44:52', '2026-09-17 11:17:55'),
(686, 'c7422933-67b1-46f9-bce3-7b7d4951ee43', 'Ragertagz', 'Ragertagz', 'lowefranklin61@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$rjSBT8zauqJBLKhf0GacxesZp/5cYKeMoMGBpoKRykAUiqDMdgor.', NULL, '2026-07-08 22:31:46', '2026-09-17 11:17:55'),
(687, '60c1949a-cf3e-43dd-9e23-a7cdee27b8f5', 'Aundrea Gill', 'Peepie2326', 'aundreagill17@gmail.com', '+18704894835', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/60c1949a-cf3e-43dd-9e23-a7cdee27b8f5/avatar.jpg?t=1783564441298', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Arkansas', 'Female', '1997-07-14', 1, NULL, NULL, '$2y$10$WOOGXMFH9D3cwIO210AjCu.IaZu0D4F/RM513kDdGKn8kqOgpnB.O', NULL, '2026-07-08 20:27:17', '2026-09-17 11:17:55'),
(688, '2b94ad5a-c599-4604-8a57-9d71310f755c', 'Naynay', 'Naynay', 'benfieldamanda42@gmail.com', '+17046412322', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZSHvXsPEKqasW.YGXjVgX.4R4jSsVH6zkAF/lFk55rTnUhxbZ72Um', NULL, '2026-07-08 22:40:57', '2026-09-17 11:17:55'),
(689, '30b2d00e-b921-40f5-a30e-55e110002f27', 'JKazi69', 'JKazi69', 'takiawilsonbiz@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OL4Tq0HxhEICCO5Q8ZjmreQDbZXBGyL40gLaiNyMO05.qXed8weQ2', NULL, '2026-07-09 13:25:26', '2026-09-17 11:17:55'),
(690, '748938dc-9221-4393-8d6a-ea7cec937253', 'bosleyjamm', 'bosleyjamm', 'bosleyjammie@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0FiDVp7Pe7trxoPl8xPMQ.Gk9ju//UAsc0QlKnLMIYNAZOF3BQYZi', NULL, '2026-07-08 23:35:58', '2026-09-17 11:17:55'),
(691, '645b5230-070b-4785-a45b-156c478973cc', 'jared Stuhr', 'Stuhrjared', 'stuhrjared315@gmail.com', '+16083974338', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/645b5230-070b-4785-a45b-156c478973cc/avatar.jpeg?t=1783569255192', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Wisconsin', 'Male', '1993-03-15', 1, NULL, NULL, '$2y$10$/Qj4ERgSJX3i8vTyGX9cLORc8jIPq0yZ2yN1vVSRA7OwFhk3XlMdO', NULL, '2026-07-08 21:15:24', '2026-09-17 11:17:55'),
(692, '7fbfccb1-f071-405a-b559-102ecbd45643', 'Kilocourie', 'Kilocourie', 'karnyxx@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$s5eOboiU9Rv40tDiGTRnS.lgYojByV3JHT19CPJNRXbDNtM501efO', NULL, '2026-07-09 00:54:53', '2026-09-17 11:17:55'),
(693, '0daf0a0c-0382-4474-8b5a-e6f9df231834', 'aaaaasssss', 'aaaaasssss', 'littlea9696@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$C/Z6egxnrcypgFBDnXGEae.t/hdnlFiKCKOZrKPJ6haZBIWQHLr4K', NULL, '2026-07-09 01:27:55', '2026-09-17 11:17:55'),
(694, '42b6d5f0-f531-4830-8b6d-a4a7361a2a0c', 'Lillec', 'Lillec', 'cormier.alicia90@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5u8arDo85TYxPsbwEL7aSOwSgIbsLLyyHPB33Vmq9DaCEy2AlYvuW', NULL, '2026-07-09 01:38:02', '2026-09-17 11:17:55'),
(695, '8ca68bc7-fcd0-4861-836e-b6fafafc061a', 'brendakinz', 'brendakinz', 'brendakinzie3@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$a3ZQp9d4SH7/biN/smdwAuFfme5cLnLT1MnmIY9p9ASiOWVXfduoy', NULL, '2026-07-09 01:47:06', '2026-09-17 11:17:55'),
(696, 'ea86622e-0d45-47c9-aad9-cd4486c3fee7', 'Brittnee Castillo', 'Tibbyy', 'jujutana23@gmail.com', '+19104039206', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Female', '1990-01-02', 1, NULL, NULL, '$2y$10$fLrWD3UWV.dytkulM5e8/OUnIDpXGXXNjGQ3BmxIfmEhsvYTAgDMy', NULL, '2026-07-08 22:29:49', '2026-09-17 11:17:55'),
(697, '39efecc2-d35b-4b9d-80fa-82a47caba8db', 'Peanu33', 'Peanu33', 'yamayabattle@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$bWqZOsyUIBA6YZjZfGmgwufHz0WAIetCk3xmrC3HxhdROgmZHPHNm', NULL, '2026-07-09 04:41:10', '2026-09-17 11:17:55'),
(698, '6b24923f-2ea3-4f80-90bc-8696170afcac', 'Banditbby', 'Banditbby', 'alyssiapaquin94@gmail.com', '+19183065627', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$48AyLAyMkHZDHgc99wdN5.sHCup02QNv2mIBCjypMCd78AKEWvVWu', NULL, '2026-07-09 05:17:33', '2026-09-17 11:17:55'),
(699, '5044ac10-e5bd-4a49-9a20-6e684c27f732', 'david232', 'david232', 'lisarayner1122@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Htt2RVZxF1rzSPNhaMAQ2.WGM3bA.36NWRXc.ntn0PRlOJMESFJ9a', NULL, '2026-07-09 14:45:09', '2026-09-17 11:17:55'),
(700, 'e6dee7f1-ea8a-47f5-96a3-a375a6424073', 'TeeteeMari', 'TeeteeMari', 'fostergirlforever@gmail.com', '+12542462110', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/e6dee7f1-ea8a-47f5-96a3-a375a6424073/avatar.jpg?t=1783598968193', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YjYvyZIR999qTJp21spbOOGJjenpN7rIcmi1R6wReJOJdgcnH1w3.', NULL, '2026-07-09 05:37:39', '2026-09-17 11:17:55'),
(701, 'e79e30c9-9541-42be-af70-e5df1a4aff51', 'D4DONE', 'D4DONE', 'chitownnative21@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$PMGn9C/kPmiRvJwPz4uEtuEyohHBA29jwLyUfwK4SMU7a4Cpv.kuS', NULL, '2026-07-09 10:22:47', '2026-09-17 11:17:55'),
(702, '0356b45f-42d1-416b-8da9-773e75c58da7', 'Shakota23', 'Shakota23', 'jeansshakota@gmail.com', '+15722701231', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$lQhG6HXHNLzMa/dLmiC5y.ONkf34LFfDIuZQtxnI2cRt6XrqE0/Au', NULL, '2026-07-09 10:23:49', '2026-09-17 11:17:55'),
(703, 'eb69de6d-f12d-419e-af76-eb26aa1d65f1', '6setceo', '6setceo', 'blackgangmuzik@gmail.com', '+13347773031', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dlFeOOSanYb7g0GchUtsQel9jLt1B3n/65t5CXoBQD1dIQUC7dety', NULL, '2026-07-09 15:09:36', '2026-09-17 11:17:55'),
(704, 'ed941a4b-4827-40f4-9c03-0525c48d10da', 'Jeseree21', 'Jeseree21', 'queenjeseree21@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dHCx3DCXqEJ2.Vz/W0z4JOQXC9n6zLxBbaxMOJiFYINXCwQ65Pz1W', NULL, '2026-07-09 17:37:05', '2026-09-17 11:17:55'),
(705, '22324194-d3c2-446c-9633-f5f283852125', 'Mjeseree21', 'Mjeseree21', 'bryanajeseree21@yahoo.com', '+13374245513', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sn1JxUbhXXLmAwYImsYegu9Lj5m4trlDwTqJYVnu1kEXp/xTGatQK', NULL, '2026-07-09 17:36:33', '2026-09-17 11:17:55'),
(706, '0e0554ab-5289-4200-ab53-62f97259a6b5', 'Heath9', 'Heath9', 'fsudayone@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$pqACDUo1rSWHFnK/L5R4cukoYjQgJfyBIp7Out5jdWJlhKQ6c3WCq', NULL, '2026-07-09 17:43:04', '2026-09-17 11:17:55'),
(707, 'acf5b64a-c171-476a-b620-5990de89980f', 'swampgator', 'swampgator', 'shiverrichard1@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$VcrO14ycQqdHtLGKvp6vYOEA.MuFgpn1f/mlKOnu2XiN/o6Lqpiy6', NULL, '2026-07-09 21:25:17', '2026-09-17 11:17:55'),
(708, 'e4999f1d-49b2-4d5d-b9de-b0056517bea7', 'landa1', 'landa1', 'landa@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$KuaLKmQXezd0WMBSXsKZwe4HYeb3e7KXgNqZZmb2RqsDn86ftRmcm', NULL, '2026-07-09 23:40:15', '2026-09-17 11:17:55'),
(709, '2a772452-439d-4687-b897-7476362b175a', 'Bryan Shirk', 'Bshirk91', 'bshirk91@gmail.com', '+12534484264', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Washington', 'Male', '1991-10-10', 1, NULL, NULL, '$2y$10$/1Vjo3LW/yxEzpRp80otiubLa//rrzr4YWT4NhDxnzzs.Nutp32k6', NULL, '2026-07-10 08:44:40', '2026-09-17 11:17:55'),
(710, '21c26725-006b-4b79-840a-1ba0c4c0ebc2', 'Chrisppp', 'Chrisppp', 'colbertchrisjon8@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$lXkUgHZ9hB/SYkuDbSB5rO3Us5EWohzokRYrRMt802Z4sf6pUSWiC', NULL, '2026-07-10 10:52:26', '2026-09-17 11:17:55'),
(711, 'e801325a-7d38-4934-a599-5bf598e5952c', 'Chrisp', 'Chrisp', 'chrisjoncolbert16@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ece6WZ6XHcZntLh64gzfWeq3QVYeNFt..U9e/Tc0fVWu0E/P9chgC', NULL, '2026-07-10 10:53:14', '2026-09-17 11:17:55'),
(712, 'fe3c28c6-a3a8-465d-8792-1df3bda7d3bc', 'Kristylynn', 'Kristylynn', 'wattskristy75@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Np6vekT9sJhfF0crpsLu/OGXeddzsbXq7GMjCg8Y4gd00q8sa5r86', NULL, '2026-07-10 14:00:42', '2026-09-17 11:17:55'),
(713, 'ca7d31b2-b63f-4834-b00a-b1bcc234fe17', 'Nessajean', 'Nessajean', 'vdub2397@gmail.com', '+18167723651', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$WaF/DPYtqXPbc3rzJY.91OqdZCsYedvm9gN/dXbI1augHm8Zfnsg2', NULL, '2026-07-10 14:08:33', '2026-09-17 11:17:55'),
(714, 'b53713e7-21a3-40fa-b20c-6b4a2ec4df49', 'Tap4fk', 'Tap4fk', 'pjimenez1027@yahoo.com', '+19092364082', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-07-10 19:46:07', NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Fq0cFODGOGmuzAAeMSxDz.QbAJYBNpS/9UU6kVs6jBXZ5fGqrbLsu', NULL, '2026-07-10 19:46:07', '2026-09-17 11:17:55'),
(715, 'f107180b-b512-4bcf-bac6-28c987da7c8e', 'teresakidd', 'teresakidd', 'teresagodwin5452@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$eHzWHyvqJ.bFhidzkJqZLufZMFUEV6T2XQJ3xykhGCZNEphrUJDs2', NULL, '2026-09-05 16:12:42', '2026-09-17 11:17:55'),
(716, '9003cfd4-005d-44df-8827-a4fc7a64a773', 'Phuker2512', 'Phuker2512', 'n.h.m.12052@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$plqn3FTniuYPG6Swfc87IOIe88pp/iPvyx1AyOMAtR2Q6WJqDxR9C', NULL, '2026-07-10 20:49:13', '2026-09-17 11:17:55'),
(717, '3b0b234c-ac88-4890-a77b-7bafec1f4b29', 'SundaiMart', 'SundaiMart', 'dsavage0427@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$oxvriYhNhyN/qAoiph4q4eguIsPlr/3xG3zGZgJYui8/drvSBriL6', NULL, '2026-07-10 21:35:21', '2026-09-17 11:17:55'),
(718, '626fd0d7-f6fd-4aba-9755-60b7dbdeec55', 'Bdeen2', 'Bdeen2', 'britdeen22@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$TTnAkDxYV/qN13p4Z/8SZefETsTtYL3baiKzuSoyPLDXgv08gZtTm', NULL, '2026-07-10 22:12:20', '2026-09-17 11:17:55'),
(719, '90bfd365-9bb1-46ee-b046-b9c9747d17d0', 'Krissylynn', 'Krissylynn', 'krissyledford.vi@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$660hp0MdvcW3xA931t1rhO8Fk0n/WPvp36QXnTf6PaGobtcE6oju.', NULL, '2026-07-11 00:51:08', '2026-09-17 11:17:55'),
(720, 'bed17748-f2e8-425c-a0ff-9818ef2715e6', 'ItsmeZ', 'ItsmeZ', 'itsmez07@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$XRPgUrKlTdXzXxu1vp/AdOaBhvCHvJi9Bq7ry55dbgO7THOEIffoO', NULL, '2026-07-11 05:43:19', '2026-09-17 11:17:55'),
(721, 'f46349b3-6b97-4e3b-8291-6dc2d867e4fb', 'amosatofig', 'amosatofig', 'amosatofiga1@gmail.com', '+18085834766', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$o66tuLUYMhTsnCXcw5Hxlu2NvqjEye2TkiKDfcQHmoEpO/VlFXcva', NULL, '2026-07-11 10:06:34', '2026-09-17 11:17:55'),
(722, 'ecef8762-cfdf-44ee-91a3-29314a934cc7', 'Brandi Tallent', 'Popwow420', 'branditallent5@gmail.com', '+17046925818', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/ecef8762-cfdf-44ee-91a3-29314a934cc7/avatar.jpg?t=1783102919840', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Female', '1987-10-06', 1, NULL, NULL, '$2y$10$8U53wUqhQ0.nMKHg/UT.qulY5If8SZ.cJ.0Q9tuHDfpj//96AtlsG', NULL, '2026-07-03 12:17:41', '2026-09-17 11:17:55'),
(723, '70ff38f8-a6ed-4454-9b37-f37c6c692f16', 'Bigsav123', 'Bigsav123', '410sav410@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7gBSFk6KVH9LySv6dh9lWeJbR8ffIQ4HSrF0oG6TysIEXRmDMA/My', NULL, '2026-07-11 16:27:20', '2026-09-17 11:17:55'),
(724, '23a2914d-a3d0-4d37-9583-f004b9f1e6e6', 'toyaodums', 'toyaodums', 'toyaodums090@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YJ7y3xmtkD/DPfa2GGOD4u6WSnMSgN4L5Lzhudd.FmtwQWlgbqEhm', NULL, '2026-07-14 02:42:56', '2026-09-17 11:17:55'),
(725, '8b65224b-3fef-44e9-9590-4b53123f48a3', 'Steve1269', 'Steve1269', 'stevengonnakilleveryone92@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$3Qq8fHSxq5DAzsBuz0ykquHqcil2Cft77IJIMZNHrIyPdDSWBbq86', NULL, '2026-07-14 03:54:52', '2026-09-17 11:17:55'),
(726, 'af20e570-d484-4ae4-b785-05dc3c0206da', 'Jvricho', 'Jvricho', 'psychosharky69@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$r4dTVURvVpj0S0DXpIme4u0drcP6QotzI4/w2rgzEr41tFLAWWaxu', NULL, '2026-07-14 04:41:18', '2026-09-17 11:17:55'),
(727, 'ee20f277-ba97-4484-b42c-07d8f543541b', 'Samiie', 'Samiie', 'samanthavazquez171@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$kpacjnwd3V1lQAioQl1wDOfKwcDALPn5m.x5ZPsQ3f94PeMPT7I4q', NULL, '2026-07-14 05:55:05', '2026-09-17 11:17:55'),
(728, 'c5071857-24f4-4441-9adb-5ac4de65b248', 'Bigbuffy68', 'Bigbuffy68', 'doylemack176@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SRpvtnEAZgS2dFjUsWk9IOGMq1ns1sNtomIvmr1llalglB7aCB0BC', NULL, '2026-07-14 06:12:51', '2026-09-17 11:17:55'),
(729, '9d1bf0d1-54cc-4be2-a181-60849f523c49', 'Ernesto Pena', 'Ernie555', 'ernestopena305@gmail.com', '(727) 998-3352', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Florida', 'Male', '1990-03-22', 1, NULL, NULL, '$2y$10$MVa.ncfPj3GGDlnPRpltH.qK0/hCteEyadun5GlUuFe5EUbTMuS.i', NULL, '2026-07-11 16:31:39', '2026-09-17 11:17:55'),
(730, 'd7e6aa29-a82a-4c70-8636-989c92234b47', 'Celestemar', 'Celestemar', 'triplepnc@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$QZQmr7562SnBtEUvlTS6/uXEddHPqvhx5DJiDm8YP7nUxGiaWX6Ra', NULL, '2026-07-11 17:33:05', '2026-09-17 11:17:55'),
(731, 'b67aa90e-7742-4845-80c4-c29ea52ef716', 'Freeplyfel', 'Freeplyfel', 'artaubabe@outlook.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4UTCCogp4AribFb85CTL/OZrmtnkOgZ9wShdANyUGZf4bryTFAsmC', NULL, '2026-07-11 18:37:23', '2026-09-17 11:17:55'),
(732, 'e833b43c-dafd-4b19-9d62-a4d5c0685212', 'Freefee', 'Freefee', 'feleve11@outlook.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6.FpjSUuu5bqy0hl6dfIvOcbnqQg8YLxm1wN1XBMZwd2QZ3vKu8Nu', NULL, '2026-07-11 18:40:49', '2026-09-17 11:17:55'),
(733, '979fca6c-4398-4a25-b2b4-1bda7d5f7f6b', 'Shorty74', 'Shorty74', 'jeffreydicicco799@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MZpfI7EonHYQj84u1KbgheiW4xF6voT6uNCRCfeQMsS4X3zYY/0gO', NULL, '2026-07-11 18:56:42', '2026-09-17 11:17:55'),
(734, 'cb233308-eafa-44b6-befc-bc775eba823e', 'unkdeezy64', 'unkdeezy64', 'unkdeezy64@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YJozOSHIuJdS9Umws0vJRuI83IKnCsCCYdSTRSMcfIVpmm0MHVUxW', NULL, '2026-07-11 21:36:03', '2026-09-17 11:17:55'),
(735, 'ce503860-2955-405e-9b86-d92bc99b8eef', 'Rtgc2006', 'Rtgc2006', 'thomas.lawson1990@gmail.com', '+17575931193', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tyEUmxDC8KfMHhjEQuFzm.GJ0vHEuxd01eOAtNY1pAJ8tX5d5mKMC', NULL, '2026-07-14 19:31:35', '2026-09-17 11:17:55'),
(736, '72030682-57c9-4372-849f-635330744ab7', 'Grc19971', 'Grc19971', 'mattgarcia971@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hwysjXIbhyfAQqvQHIAV/ucR28RkmFWgReFDYYGGks5j2g8VHEN3q', NULL, '2026-07-14 13:05:47', '2026-09-17 11:17:55'),
(737, '5cb58961-49a4-4f93-b404-ac05f2d0666f', 'Stetso Wagne', 'Stetso90', 'stetso78@gmail.com', '+14322575564', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/5cb58961-49a4-4f93-b404-ac05f2d0666f/avatar.jpg?t=1783834059873', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1990-07-31', 1, NULL, NULL, '$2y$10$/3A1f82mr/XzMJGqWXrfH.zDNI/5hhP5z76l65kzlDXbFWZfaKXSC', NULL, '2026-07-11 23:17:57', '2026-09-17 11:17:55'),
(738, '47bf1a27-d1a1-4d25-826a-2c3c1ec2fcba', 'CalineL', 'CalineL', 'rachel.loven81@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hMpNrqIfjrTachCHT9q8p.U8HBleT1BYu0AzPKR9i.MTAvXI3qz6S', NULL, '2026-07-12 00:34:47', '2026-09-17 11:17:55'),
(739, '44297c72-d4f9-407d-90d3-0dfdab642ffd', 'Guan567', 'Guan567', 'yuppy567y@gnail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fSNJ1Q0Vwq3HlQP3Fh7oY..Cwn7SjsmI1/mokxSWt08iupW4MpGCa', NULL, '2026-07-12 06:11:37', '2026-09-17 11:17:55'),
(740, '1d89377f-bc66-4722-b5b5-be1c44cfe10e', 'Monstaniml', 'Monstaniml', 'beetlejuice0990@gmail.com', '+16146236368', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7uyREkiN9Blbbd/SY5bUDuk9spQEvzQOIODFB0TVvSnl4tjbQzosG', NULL, '2026-07-12 14:10:00', '2026-09-17 11:17:55'),
(741, '0c3a71af-1766-4bd9-9142-2009be28756d', 'anthonyis', 'anthonyis', 'anthonyis819@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ztFqe6MklXlPl8xyRqtu8udan2xMJJgJq2X9Nz9q8wxty9u1JKL7.', NULL, '2026-07-12 14:13:10', '2026-09-17 11:17:55'),
(742, 'b9bf02ef-287d-420e-a6f6-d2a0b27488c5', 'GaryLee79', 'GaryLee79', 'garyleewatson1979@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$360TE009UZcS2EglhffodeeP5TZLBttu4MdvMTLRKfm/Uj54606U6', NULL, '2026-07-12 15:21:08', '2026-09-17 11:17:55'),
(743, 'bc13091e-1a92-498f-bf42-30ef5ffb8fdc', 'Royalcho', 'Royalcho', 'knightshoops4@aol.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$WPwkNWt6ztOIVUn40YwMZ.fT.wif93ws5P.qup0nqDK3fXlQ1GJTK', NULL, '2026-07-12 17:53:33', '2026-09-17 11:17:55'),
(744, 'aa9edb8b-9bb4-4b2d-a1f9-084a02db8f68', 'Joseph0506', 'Joseph0506', 'j41070093@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7R4kZU7Nv83R1OKRblBpE.giq/MyycwdCjlEef1.b3vrPVgwjzKMe', NULL, '2026-07-12 18:03:31', '2026-09-17 11:17:55'),
(745, '61997280-1bca-434e-acea-9c145814a83e', 'LaceyCole', 'LaceyCole', 'hushlacey@gmail.com', '+18702889512', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YSlKa7uelGNB1q3dkGe8/u1lXdK1ImQkr1j/am1fJ4NNnPiIVyb4e', NULL, '2026-07-12 18:50:53', '2026-09-17 11:17:55'),
(746, 'd26d43a1-c7ac-4dd7-8b53-1c0128ff558d', 'Justin93', 'Justin93', 'justinrayamzl@gmail.com', '+18179944578', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$i6Tz8awLewxJThQk1A93g.8yOEHW3WjbVNWEcwSojsMRfZy5xAsDe', NULL, '2026-07-12 19:44:30', '2026-09-17 11:17:55'),
(747, 'd906d2c6-300a-4115-9fae-d9ec63be6745', 'Jeremy Ornelas', 'Wormo75', 'wormornelas@gmail.com', '+13614071272', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/d906d2c6-300a-4115-9fae-d9ec63be6745/avatar.jpg?t=1787128281424', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1975-12-12', 1, NULL, NULL, '$2y$12$9nYteDlwoNAUTgXUztBwF.fGl6ltni3CA/W5zlxlZ0/qBxpiYTv1a', NULL, '2026-08-19 02:12:10', '2026-09-17 11:17:55'),
(748, '677ebb65-9930-49a8-b822-d4199b5124bc', 'Jacob  Metcalf', 'Jmtclf2025', 'jacobmtclf2025@gmail.com', '+12345296133', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Ohio', 'Male', '1993-03-22', 1, NULL, NULL, '$2y$10$AnQcFynkrmbcrdpPAOOQmuK7cShL73nzrCybP84mHBBTesIbsZ4Xy', NULL, '2026-07-12 21:45:32', '2026-09-17 11:17:55'),
(749, '8eda0ed0-9bc5-473f-b853-734395ca378f', 'Sierra1995', 'Sierra1995', 'juvion12@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Hvja6gjJeLE.8flg5pHddeGCFqNNZsb5BsesX7irAtfqbO1sMIcUu', NULL, '2026-07-15 00:18:46', '2026-09-17 11:17:55'),
(750, 'cf37e31c-38f7-451a-9d85-bc5412b6b148', 'Jennifer Nelson', 'Zavawn', 'jennifernelson4578@gmail.com', '(618) 216-7057', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Illinois', 'Female', '1978-09-14', 1, NULL, NULL, '$2y$10$H4CdTcNx664mM4SQfVgH9O4N.7j2Zs6R5s7cA5Br9yiZlOHdYyTb2', NULL, '2026-07-13 01:46:21', '2026-09-17 11:17:55'),
(751, '7c345745-1e9c-4f08-8221-dc83ac437d14', 'fellyfedia', 'fellyfedia', 'feleve.me@gmail.con', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$3cN5yaiJxqGQdM4107e0KOM7LSKTWqzELcdnFUyNeHaotEqtyYqia', NULL, '2026-07-13 14:17:42', '2026-09-17 11:17:55'),
(752, '584822f5-fa70-43be-b659-c9633c64350c', 'Alikatt', 'Alikatt', 'wadealexandrea8294@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$b5Ae7ShPuBmkbkf2Srlrp.1w2Ylz/rD5DrjUO6skY39SWOlleUtaK', NULL, '2026-07-13 16:30:24', '2026-09-17 11:17:55');
INSERT INTO `users` (`id`, `legacy_id`, `name`, `username`, `email`, `phone`, `avatar_url`, `ghl_contact_id`, `balance`, `role`, `is_flagged`, `flagged_reason`, `flagged_at`, `email_verified_by_admin`, `phone_verified`, `phone_verified_at`, `country`, `state`, `gender`, `date_of_birth`, `email_notifications`, `email_verified_at`, `last_login_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(753, '3c6c1914-8875-4d3b-98ea-9a06f81f7225', 'Agbrittney', 'Agbrittney', 'gotchasuckab@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mvx1ej3Rg64BmgKzQjw.4em/OvLy.j5CDzSDZ9agiUUhlmhdbVXDi', NULL, '2026-07-13 16:55:33', '2026-09-17 11:17:55'),
(754, '62665256-4613-456b-a839-d0396d33465a', 'Tinalouwho', 'Tinalouwho', 'tinatidwell720@gmail.com', '+18707767242', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5GKaToUygCah4WSaUvEu0Oc3owKXx.HvGPATXAoAU8t9WJ8RtUWca', NULL, '2026-07-13 22:16:30', '2026-09-17 11:17:55'),
(755, 'eed6ff91-6ed0-4d38-870b-cbdd2051c3e1', 'Yahwehseed', 'Yahwehseed', 'loren.henderson@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$XSaOG.jPy9Bv5VcE.XI1J.IqG30n2rVgr8WinXKrsnYFGmfwhOTsq', NULL, '2026-07-14 00:10:08', '2026-09-17 11:17:55'),
(756, 'cb21447c-be70-496a-871c-4012c9cf03cf', 'Joshct', 'Joshct', 'trees7204@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vcSnEBlSAYeK79MDjDM0puGjz.WIGvRg3rRz8cIbc9A1x0gGLv296', NULL, '2026-07-14 01:34:19', '2026-09-17 11:17:55'),
(757, 'aaa1e7cb-b2ce-4500-a66c-baa06909d398', 'Vickyt0909', 'Vickyt0909', 'kemyiajakyla@gmail.com', '+18125862341', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$eXEjw2Bk2qe0vd1YPPhSO.b.Jm67FfujFFmTyFF0apTwOcaL.ozx2', NULL, '2026-06-25 08:54:16', '2026-09-17 11:17:55'),
(758, 'c47e0a46-055b-4143-b98f-b0aa33ea70a0', 'Ghoney', 'Ghoney', 'cavazosgeorge06@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$SVyajfhovY2/rtK3yLnJxeOjIlV2yOo83Jq6gXP8uHezwmmfSI27.', NULL, '2026-07-14 19:16:59', '2026-09-17 11:17:55'),
(759, '56529013-d304-4681-869a-88f80b52292c', 'Dequan1122', 'Dequan1122', 'eins2024@icloud.com', '+14633144016', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZcC9Cs8LkaHHaiHIJdnVte1PstnOYHWcsvnigIOjDUutXTtOukBcO', NULL, '2026-07-14 18:23:29', '2026-09-17 11:17:55'),
(760, '4e12f592-3755-4af4-bab8-cb0d1c84860b', 'Randall  Walters', 'Ydduba', 'randallwalters2456@gmail.com', '+12819725058', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/4e12f592-3755-4af4-bab8-cb0d1c84860b/avatar.jpg?t=1784079572402', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1991-01-01', 1, NULL, NULL, '$2y$10$LDkGf3g/M18uby99Xh5.2OOzzX4gehG2Rzs40EGANRt5g4VeXtGF.', NULL, '2026-07-14 11:21:12', '2026-09-17 11:17:55'),
(761, '025a3d67-5bbc-4f0e-8fc5-1395d358455d', 'Kate31', 'Kate31', 'katelynnpeterson079@gmail.com', '+16362918410', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$g8SirDDo8kwJGAmtaf72N.uEWHEc7shSFhN1I/Zvtid48.MpbQCpO', NULL, '2026-07-15 00:34:05', '2026-09-17 11:17:55'),
(762, '293f41e0-1a13-4df9-bf4a-aef5b9c8084f', 'Juicyee7', 'Juicyee7', 'cannonj1080@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$iPnmkGYWprzkw6SFcTee2.WWPUSZMsk/k7FiuIkDBezrcLAzlpo4O', NULL, '2026-07-15 00:45:41', '2026-09-17 11:17:55'),
(763, 'd7aa0d04-3b48-4f2c-8090-8050f938b70b', 'Becker77', 'Becker77', 'amberbecker517@gmail.com', '+15074761372', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$jku0u4I8fW5HVHfFiGxZhuLNgUrqmZt3dySOsei7d6bw8wPAAq432', NULL, '2026-07-15 06:59:37', '2026-09-17 11:17:55'),
(764, 'f2df8957-e695-437a-91a4-e0838c389936', 'Nick Geniale', 'NikkoG', 'nickgeniale1010@gmail.com', '+19048350166', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/f2df8957-e695-437a-91a4-e0838c389936/avatar.jpg?t=1784147568658', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Tennessee', 'Male', '1989-07-04', 1, NULL, NULL, '$2y$10$U7vURXM7Uos4RQCC93zWzOFCfQQk5G5ixqFs2xjTttXx4Dutqs8gu', NULL, '2026-07-15 06:55:22', '2026-09-17 11:17:55'),
(765, 'e295377d-2ae0-49a7-a774-6d28e389d06c', 'vickimaley', 'vickimaley', 'vickimaley73@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$wmJWeI/cwYeRCXBSCCMYQeRqMFl4V6Fdi1Cz1LD39FraDnLm75/me', NULL, '2026-07-15 16:54:24', '2026-09-17 11:17:55'),
(766, '75957672-1e60-445d-bc00-8ba7d1cc7813', 'elenam5891', 'elenam5891', 'elenam5891@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$L/eHdzxx.7zSIlCAFmaiKOtXsWVtWseY7/7M/y4NAgZ1FClk3dU3i', NULL, '2026-07-15 17:31:38', '2026-09-17 11:17:55'),
(767, 'da0ed8a4-a285-49c1-8ddb-7b45167aceb8', 'Mistyf811', 'Mistyf811', 'mdawn2236@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DuS2GqPh3RmVCycC8h9XMeXntxsfaieQaJZOAVyQ4m9t2WuRjf71W', NULL, '2026-07-15 20:08:49', '2026-09-17 11:17:55'),
(768, '0016ace8-3451-4fd9-9537-0f417c2e33fc', 'Matthew2', 'Matthew2', 'mwilhoite420@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$NUoPK320HO4lVp.oLOzFGuk0s8MZrCo38F/iQYkDLZnFpvFFlEpZK', NULL, '2026-07-15 21:38:17', '2026-09-17 11:17:55'),
(769, '1eabe0b8-cb4a-4eaf-b515-6ce9dc0042b4', 'Natnoel', 'Natnoel', 'tash30555@gmail.com', '+14798412408', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sNyW0fe33MsXQHJ70O08seyCcq0PUyfBEjHMWG.N2ALCRESVc/KZq', NULL, '2026-07-06 14:09:43', '2026-09-17 11:17:55'),
(770, '3941bb1b-91eb-46a9-bcee-907200a7d5d9', 'GrittyG', 'GrittyG', 'robertthomason09@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$9I7cHaFBZCVvmF3k15FhZe31u42nfubMJxK73WzDW8oQxtNigfRcO', NULL, '2026-07-15 22:50:00', '2026-09-17 11:17:55'),
(771, '59c5e036-3aa0-4661-897f-fded4a46a9cc', 'strongmama', 'strongmama', '1strongmama86@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$H8qDoZOknCHLQW15gaQEcuo6Z.W9mlNSeJPSjZ.gvtBYKVBUZPYjG', NULL, '2026-07-16 00:41:17', '2026-09-17 11:17:55'),
(772, '9c49d6e4-1fa8-437e-91ef-e213abffca5e', 'Crazyboy66', 'Crazyboy66', 'rollinstoned19900@gmail.com', '+12055479554', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Alabama', 'Male', '1992-10-03', 1, NULL, NULL, '$2y$10$GBBCROgcAArIKRKvQ0fnt.MJacgQMW3Vmb0WGG4ZQThrZzqyKTOuq', NULL, '2026-06-15 00:21:34', '2026-09-17 11:17:55'),
(773, '8c8c2bd2-a52d-486e-98d8-f717185dccdd', 'LilSissy52', 'LilSissy52', 'lilsissy5252@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$kFAIeyNgzd/hBU/DMX2QjuSJbULTEz6o79ba2wqrWN3PkQwTKwnke', NULL, '2026-07-16 05:29:51', '2026-09-17 11:17:55'),
(774, '6ccf073b-c560-4ca5-853d-596dbea495a0', 'robinsonda', 'robinsonda', 'robinson.daniellem@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$iii1vTGUtYj/Cm1bT5fjDOsBZnaUE/YoAxawazZf2opEZjeujqC82', NULL, '2026-07-19 06:33:55', '2026-09-17 11:17:55'),
(775, '3329d8c5-7eb1-4a9c-86bf-c78be2c5b6b9', 'DeeDee', 'DeeDee', 'demetricjohnson85@gmail.com', '+13184186432', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Louisiana', 'Male', '1984-06-14', 1, NULL, NULL, '$2y$10$SwMAHQbT/IIlUaT7aoJZpO4TrAeakNl0T.SXYPKUyx9S0UJadAlt6', NULL, '2026-07-16 09:13:19', '2026-09-17 11:17:55'),
(776, '5e60d7cb-7049-485c-8c90-b96278d438af', 'Joe8388', 'Joe8388', 'joniewelsh83@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tPf/KHYvjb2oT.bBKdu4IuE0suY1D4dBGWg34roxteHoQ1V278XD6', NULL, '2026-07-16 11:45:02', '2026-09-17 11:17:55'),
(777, 'b2733ebf-8e8f-4d53-a0e0-6b67c18e2054', 'ChicoRey', 'ChicoRey', 'swagalikemin3@gmail.com', '+17205491502', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CsXulIu8AF.4OkcgXswaweJmswzQuCBBd6ZCnMQPSpFIChAw4INJS', NULL, '2026-07-16 17:41:10', '2026-09-17 11:17:55'),
(778, '44c8f92c-ca94-4b7f-8013-7fdded7d186f', 'Lisanephew', 'Lisanephew', 'lisanephew02@gmail.com', '+17855018968', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ySF2BkrHx2oXA7jYpGMuMeal4yftlcw7DsnQEMDw3bExYCHYJA3jm', NULL, '2026-07-17 01:46:28', '2026-09-17 11:17:55'),
(779, '9a2e258b-417d-4e53-9978-4fddeb287a18', 'MissMote29', 'MissMote29', 'prettynpink42069@gmail.com', '+13163074264', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ukkaHjgK4telgeRBTkEpV.ITtZejDQJa4tFNWvHg9q9f7RkL0OcXS', NULL, '2026-07-17 02:21:55', '2026-09-17 11:17:55'),
(780, 'b71bd5ac-5ad5-4558-9f39-ced5cba2aa24', 'Sammarie12', 'Sammarie12', 'livefortoday1100@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$O0sKrPuSKpAjmfVQ3maeL.lMuMOtT5q8GisgpjNAgArD6nkyLnVa2', NULL, '2026-07-17 02:43:58', '2026-09-17 11:17:55'),
(781, 'e79b0087-c055-4d0d-aa7a-43122e1e6f87', 'Zincohill', 'Zincohill', 'devontaehodge251@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hxC.h4NpwaVtKGCcJSfbleZ1cOCuZw41f9tiupzjbzA/FPEqVVkCG', NULL, '2026-07-17 03:02:18', '2026-09-17 11:17:55'),
(782, '21f5264b-0283-40ca-b76d-d44b6e0fde75', 'Ebola2041', 'Ebola2041', 'stonedlord420@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$I/TEL52fFUA93/6HgRr6T.uDgC4sTRJEAfof4Pal5DKGMynRggIua', NULL, '2026-07-17 05:59:47', '2026-09-17 11:17:55'),
(783, 'b3582eef-ddb3-41ea-a4cb-61c6c7ac980d', 'NikkiLu82', 'NikkiLu82', 'chasencam0120@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$kbH80mjNNmhjLXIRkZFvnujMy2LcXsqAuYl2hmAZpOrzhlsKUiSuS', NULL, '2026-07-19 09:53:34', '2026-09-17 11:17:55'),
(784, '9103755d-9318-4249-8e5e-68404463df61', 'bambiboyki', 'bambiboyki', 'bambiboykin0528@gmail.com', '+14096565623', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$FiRUIl1Go1ryxzOqn3vZWuKzPawiu4vHhDi2WWSjoYB/d.0LgPBA2', NULL, '2026-07-17 06:08:46', '2026-09-17 11:17:55'),
(785, '422b6672-b243-44bc-9e93-94e834610785', 'Jodycones1', 'Jodycones1', 'robertjones32116@gmail.com', '+17069800009', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$wp3vYOMaRTuA9e3AuSRIVO64.kkIezJ4N7BwHO6n2gEg6gJAwG9MW', NULL, '2026-07-17 15:53:25', '2026-09-17 11:17:55'),
(786, 'a59ed685-bbac-451b-b492-8bcf5414a9b3', 'Justinp512', 'Justinp512', 'justinp171993@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7aL.ENBM21CnRE.ClsQtkOBFy3ablVkEu5Q8G3KXccVBtjKD5NH9y', NULL, '2026-07-17 22:53:05', '2026-09-17 11:17:55'),
(787, 'b8252f20-ad10-4ba5-9480-b59058fc3376', 'Lilbilo3', 'Lilbilo3', 'tyrabennett08@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Lcotq4W9rSWIPtevDH3fGu3RcIqLjBHoxdgpL946Scw3KKL2b7Eoy', NULL, '2026-07-17 23:03:07', '2026-09-17 11:17:55'),
(788, '0d3e177f-2f5b-463d-98f9-3f24395b5af9', 'Crissy1488', 'Crissy1488', 'christyystevie123@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5UCl87tq6EXeKkrl63dDYegU6iGqJcmnF4Z23coXshey8BPHNkuLa', NULL, '2026-07-18 02:08:46', '2026-09-17 11:17:55'),
(789, 'a6c9453c-5637-4e51-a878-48bc8a345f12', 'Vegasboi', 'Vegasboi', 'prettyboifly420@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$p4jBvKG35KFKSh/6H0VCEeHB0cRCkmVH1o8V5rkVt/zv8ney4L7km', NULL, '2026-07-18 03:27:34', '2026-09-17 11:17:55'),
(790, '6504afa0-c524-4290-ada1-f1638e2f0f5b', 'tinytony', 'tinytony', 'standonit187@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$o6B2jtLoo4DQ5UQOZ3dVB.dLTA497EcOc9gq/8L5.N5MnLPOjggN6', NULL, '2026-07-18 05:15:17', '2026-09-17 11:17:55'),
(791, 'dd463bd3-1c09-422b-94aa-ae9a852aa29a', 'Lala15', 'Lala15', 'jvang7997@gmail.com', '+16292515336', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$5gH4yC5evrcgUayTmpAOF.jM7Tqyit./.OHTDsCFcL.1BGyptXDBi', NULL, '2026-07-18 06:33:54', '2026-09-17 11:17:55'),
(792, '7200a7e6-e2a8-4b01-829c-727cf9e50ff2', 'JamesAnder', 'JamesAnder', 'theroyalbattle12@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Krt9oQR8cCkk1mRb0rqRjeKoTa/Gd9FOBFoONUb3zVub69viOtOvS', NULL, '2026-07-18 08:12:47', '2026-09-17 11:17:55'),
(793, 'd5a8ce22-2082-49a9-9960-2f044925f06a', 'Babyjaq', 'Babyjaq', 'babyjaq1991@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6YzzPStJxnBr5FKw8O7K4eJSiw.5cv9V2abnFNmGtHBtgUxNXCzwy', NULL, '2026-07-18 09:57:40', '2026-09-17 11:17:55'),
(794, '64bbd0d7-27f0-4fc6-995f-6e75c55135e7', 'Savagemom', 'Savagemom', 'bsmith93baby@icloud.com', '+14786729545', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$80gj2TEYxSEwn5.Di0BTluD8JfT5AqV9c4r6nHeNLwpH.bqifjudy', NULL, '2026-07-18 16:06:00', '2026-09-17 11:17:55'),
(795, '26670ecb-bb89-40ef-984c-59a2e5a752f4', 'Stacytiger', 'Stacytiger', 'staystrong2574@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$g1Y7yp30oFut6zy1xX23WeqinKxwdiQao2FX0orich7wJTediJZU2', NULL, '2026-07-18 17:28:37', '2026-09-17 11:17:55'),
(796, 'ab34f6ee-c28c-4fd7-b62b-e3d6fe383078', 'Cswayla', 'Cswayla', 'strongerwoman7480@gmail.com', '+13304613341', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$E1wBc0cLu0d2lSOCFEwCrONYm8zn54g7PCQ8pV9D0zpHQCkAd5Sjm', NULL, '2026-07-18 17:31:26', '2026-09-17 11:17:55'),
(797, 'aa65490c-3b14-4ff6-be42-8d2b31f024f9', 'Dunlap95', 'Dunlap95', 'dunlapcotey2019@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$AroI5St8sfyLgFSfsHTWuO8HQyaSKiBbiyGDAps02r2NIQJEuA7Bm', NULL, '2026-07-18 19:53:55', '2026-09-17 11:17:55'),
(798, '2d09323c-2ef8-45c0-bf9a-48d5a7cb8c23', 'Melissaho3', 'Melissaho3', 'melissamariedavis8323@gmail.com', '+18287210158', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$HBVrwy5LtEdnLn0hSwQUiuc18hhZ/HM2CdAWBFtKRhzg0F/dafl5W', NULL, '2026-07-18 20:43:44', '2026-09-17 11:17:55'),
(799, '984a9b56-a468-4579-a8fc-5c3135466fa0', 'D33four20', 'D33four20', 'ddbr4812@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$EeCmhLYRy5PGY4MCUzSLC.tBxifNIqEHC/DWbhAEi8y70tNPhNq62', NULL, '2026-07-18 21:34:44', '2026-09-17 11:17:55'),
(800, 'a0b0e777-7ae2-4140-a8e1-151240c1747e', 'Hollymaee1', 'Hollymaee1', 'hollymaee05@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ObeFE5JDapO0mGRSfNc9wuHEMQBO9mPAJPfTEeMKTnTp/IgF9uSUW', NULL, '2026-07-18 21:57:50', '2026-09-17 11:17:55'),
(801, 'cc46b4e5-fd1b-4768-8bed-445c5b0634cf', 'Ashley79', 'Ashley79', 'ashleymcdonald979@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$o9S0i7M7IrN7BZbwDtWt/ul2xzhFnBoAjUPJKfwfrgn5sDnJZKeA6', NULL, '2026-07-18 22:55:50', '2026-09-17 11:17:55'),
(802, '627ace6b-6516-43a4-9889-787e0d346e75', 'Sonjr666', 'Sonjr666', 'nson82157@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$42ZoV0Blqea74mA7JiZ2T.gXD1yOzYJPg8StCIoE/WcESL0pwkrAe', NULL, '2026-07-18 23:49:44', '2026-09-17 11:17:55'),
(803, 'e4f0c63d-54fa-4b88-ba52-41805cf6f8f6', 'Shawna1487', 'Shawna1487', 'shawnabai414@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fBLRQxd7V3ky5quc/ZFlm.hmvbHZ43OdBXD6lixuyZRxh3QipyQ.q', NULL, '2026-07-19 00:14:39', '2026-09-17 11:17:55'),
(804, '6e9043c3-85ec-4a6e-861b-85b5be8fa786', 'MicheleRay', 'MicheleRay', 'dawnofday1271@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0DR/grcQX7LkqH0HeGQXQ.Sdq3DGJGZFmRC77xASYSAxGpKu/2/26', NULL, '2026-07-19 03:43:31', '2026-09-17 11:17:55'),
(805, '974421ea-8eb4-4bac-b2f3-498c3e63d2dd', 'Bgkenn8807', 'Bgkenn8807', 'brittany880726@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tL9FiRD/UAPpJi3ODfJIgOuKjn2XDiTit0tb4koLvkS2j43m80szG', NULL, '2026-07-19 12:14:15', '2026-09-17 11:17:55'),
(806, '5bfb4f7c-1b60-4fb8-b22f-bae40049d04a', 'evelynelai', 'evelynelai', 'evelynelaine5210@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CQsojslqW8xiZVLizIE1N.zy3IIlNY7gjb8xjInubmIzmzuzu.9UO', NULL, '2026-07-19 05:56:54', '2026-09-17 11:17:55'),
(807, '9c9d89c9-95a7-4f4a-8b7a-7121ca3fe0f2', 'cornesjame', 'cornesjame', 'cornesjames5@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$UDrnyUEDwzUOf1stgxu1S.LqBzYmBlU0F0qeLmfkm6E5P9pbDip3W', NULL, '2026-07-19 06:31:21', '2026-09-17 11:17:55'),
(808, '1667c5c2-d168-4099-8516-c036ceb5869a', 'Memphis', 'Memphis', 'shanenull46@gmail.com', '+13464430175', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$uAILcbV0pQk75nZ0C/jbZu/BqJO7goxdzjfVHM1wdREpT8lI8dWCO', NULL, '2026-07-19 12:24:27', '2026-09-17 11:17:55'),
(809, '5adb7865-81d4-4664-8d6d-3ff3ffa36d9b', 'Ksantos28', 'Ksantos28', 'kalebsantos16@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OGyYx53C1VVyeU8PO2/Rh.tbblWUC0FHbbBklaeAufah4BXMjRtQS', NULL, '2026-07-19 17:51:08', '2026-09-17 11:17:55'),
(810, '25f522e0-973b-4fad-901a-a96ac0127901', 'craybrad25', 'craybrad25', 'craybrad25@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OnsQgjaW/HGF7l5CTSVZteAt47xUj1U72coJocCchXKYpydb/sb8S', NULL, '2026-07-19 17:57:58', '2026-09-17 11:17:55'),
(811, 'deecfb10-8287-4502-b385-003f4150452e', 'ssShortOne', 'ssShortOne', 'richellebrokaw3@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$TfNN/233iKEJ/JGp7xeabujxkxB8J69JvSR5h2q2FcZrpiKuhDnsS', NULL, '2026-07-19 19:47:19', '2026-09-17 11:17:55'),
(812, '4e826c84-ccab-403a-97fc-126815ab6d36', 'Holly05', 'Holly05', 'hollymaee12345@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hr0hOa6YJ17QYczxsdzCJu2euQCXc41KqDxNwWvDR59NW19CVmyLu', NULL, '2026-07-19 21:05:37', '2026-09-17 11:17:55'),
(813, '043665f5-f320-46d3-91a9-0d88f1d328b3', 'Fatkins', 'Fatkins', 'felishaatkins40@gmail.com', '+15807061155', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$ULZlckdSSm/I/tfIO.8tser6EozxQSTxs4myiIK8643Rgnbnvwk9K', NULL, '2026-09-05 01:57:51', '2026-09-17 11:17:55'),
(814, '7ae1ce6b-b621-4516-ab82-5a9f96992d4e', 'Hollymaee8', 'Hollymaee8', 'hollymaee83@gmail.com', '+15737520427', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$wY/sZDbB/xWg2ZHbBHRPa.MPPTx4yfoIrIewjDw4c53TGwn0VEgOO', NULL, '2026-07-19 21:13:31', '2026-09-17 11:17:55'),
(815, 'd4fafd24-a7ae-437a-baaa-5f38ec037085', 'Money2391', 'Money2391', 'monique.salgado1991@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LsamWNkWIVX6myP6Mx24R.6HBUAWwZ/whPDC55EXFWXXgAXd8vwHm', NULL, '2026-07-19 22:36:57', '2026-09-17 11:17:55'),
(816, 'c9f9e2d2-61dd-4a4b-849d-9439bf30578a', 'Gametime', 'Gametime', 'mekdlb109@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$foyjsB62FRYpsahFlmzpSOzItX.bxYpS.sdR0ymGthuTVANc/PVLG', NULL, '2026-07-19 23:29:57', '2026-09-17 11:17:55'),
(817, 'c9adaad2-51c4-46d0-88ac-6089af8b988a', 'larryweir9', 'larryweir9', 'larryweir97@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$lYjckDOCnTtlvNGd5Xcjm.Bs7G0k43q.qPtZjo49TSgXtORjiBMce', NULL, '2026-07-19 23:49:52', '2026-09-17 11:17:55'),
(818, '678eee7c-6cd7-4083-8a06-1265c02c195f', 'JayJai', 'JayJai', 'jay300love@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$j6SQ8j6TH73Tlz1zTypt1eniKOJR/qdN0ufJrAxcViWXLNsuBm972', NULL, '2026-07-20 06:47:33', '2026-09-17 11:17:55'),
(819, 'c9eb8d60-d418-44d4-92b4-fcefdc353974', 'Andy Carley', 'ondandyon3', 'ondandyon318@gmail.com', '+13188358669', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/c9eb8d60-d418-44d4-92b4-fcefdc353974/avatar.jpg?t=1784460090432', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Louisiana', 'Male', '1987-01-14', 1, NULL, NULL, '$2y$10$KPT26o2VUHJ8K8pGUg7nXexDnSywooMj1meuL4VGNVkVktSxKCf/m', NULL, '2026-07-19 05:13:39', '2026-09-17 11:17:55'),
(820, 'ccb71a82-772f-49b7-8dcf-1a493bc3cb6e', 'Justin Drummond', 'Justadrum', 'jwdrumm83@gmail.com', '(972) 327-0363', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/ccb71a82-772f-49b7-8dcf-1a493bc3cb6e/avatar.jpg?t=1784581885429', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1983-08-31', 1, NULL, NULL, '$2y$12$SJyvBZ8akqblCZOfVQe4pOxbHcupjpNvWKGyxSgfZs1Kp7Kcc4nYC', NULL, '2026-07-20 15:06:22', '2026-09-17 11:17:55'),
(821, '1e0f11c9-0201-4247-9224-1608299735e9', 'Desigetit', 'Desigetit', 'chandradorham0@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6WiyTZn8HDWlKad0KtW3G.rTT3ZZ2JKROtvUPqN9.J2iCa0j0i03y', NULL, '2026-07-20 18:08:18', '2026-09-17 11:17:55'),
(822, 'bb91ec05-187b-45d4-954f-d73c8b00538b', 'jenden911', 'jenden911', 'jenden921@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$APC3f6zSSo8bxKpbQjfdAey1Kz9MA90esKrOEJJtnuZ/GCFYy0jlC', NULL, '2026-07-20 22:14:42', '2026-09-17 11:17:55'),
(823, '74ae1c10-54f2-4bc6-bd73-2193dee2928e', 'KINGKONG', 'KINGKONG', 'darrentackett35@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MqNUdgeSijPTyIo14zkCwuHevvkBKVcgcX9mjZzQDowVRtySv5cyG', NULL, '2026-07-20 23:48:38', '2026-09-17 11:17:55'),
(824, '43a31bca-3bef-4807-b470-2c459e91a8ea', 'toney60', 'toney60', 'sunnysonson47@gmail.com', '+19183502506', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$yzx9TtntCwCUfpOp3RLqAeK2ok0GizwKWrJ5LLISv8lP7.gYOjRM2', NULL, '2026-07-21 00:00:06', '2026-09-17 11:17:55'),
(825, '36dee1b3-bcf5-4426-b2e0-6c1634577433', 'dinahfusse', 'dinahfusse', 'dinahfussell41@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$HJNmdpVCRV7z1dETPHTXTeK9mgMdHhYKLZyB7CSdHOC.v/YZDwr56', NULL, '2026-07-21 05:37:43', '2026-09-17 11:17:55'),
(826, '122bc04d-f9f7-4813-9273-c0c8e9a40657', 'rodd1108', 'rodd1108', 'rodneyhumphrey67@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fJcuVqetf4.nj9FC6etvPe.H2ZoDBMpSRn0Qee7Re2D0.QvvoBmxO', NULL, '2026-07-21 06:01:58', '2026-09-17 11:17:55'),
(827, '8defd6c0-80b1-48cf-a45d-6cd583415e88', 'Faye198043', 'Faye198043', 'faye198043@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/33gMEdrzsw9rXWsg6vzAuea3nFtCqntSDcaZ7AmasZGb483lwW5y', NULL, '2026-07-21 14:54:45', '2026-09-17 11:17:55'),
(828, 'bd821fec-dc57-42ed-9ced-7f171ce13bfb', 'Grootus1', 'Grootus1', 'staycmcham@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$B7X5cxgzI70.MhXtR1mui.N0Hk2hUi4TvabQu610qh6T1CqASUuPO', NULL, '2026-07-21 16:10:05', '2026-09-17 11:17:55'),
(829, 'e39e196a-be23-41d6-8e62-002b5d01ddab', 'tman7733gm', 'tman7733gm', 'tman7733@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RejsSFyA5WyE6fhk4nNhNehA.ek4KoxyVseYtk89McwNWfITa1T9.', NULL, '2026-07-27 04:21:01', '2026-09-17 11:17:55'),
(830, 'ace2b3ec-5f99-4b05-86c2-43dfdf51ff1c', 'Mimi224', 'Mimi224', 'tamekab224@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$p91FxjhQiNKzzQ.1ZVIJjubD1O/EZaHLbhj6ePOzRZ973PpcDIhii', NULL, '2026-07-27 04:39:12', '2026-09-17 11:17:55'),
(831, 'aa0cf9da-8f27-4905-9534-8ec044ec3a13', 'Samantha Moreno', 'Sammorenoo', 'sammoreno1331@gmail.com', '+16618009478', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Female', '1996-10-30', 1, NULL, NULL, '$2y$10$agusWbkdH0.rQ0G5PdSC..SBEGJwxNt9MI5mKIr2EkBZK6JNT4btW', NULL, '2026-07-17 02:39:32', '2026-09-17 11:17:55'),
(832, 'c6a1cd00-0b06-49b2-870b-460bfab066f4', 'Eugeny Franklin', 'LetsSee777', 'jokermovich@gmail.com', '+15403143076', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/c6a1cd00-0b06-49b2-870b-460bfab066f4/avatar.jpg?t=1784680617586', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Virginia', 'Male', '1983-09-17', 1, NULL, NULL, '$2y$10$hZIcCiTRTulyQXVapexOJueCEZAp2JBXWSB9xuMjnAHoBDxc2lcJa', NULL, '2026-07-21 18:17:04', '2026-09-17 11:17:55'),
(833, '6ab90b3b-d3a9-4f58-983e-7fe8a86900ab', 'Willlll', 'Willlll', 'williambragg1984@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$08RF21aUm366vopcK2w8nOSCcyKjU37g0Apa10fPPF6jOLfji6iXW', NULL, '2026-07-21 20:29:30', '2026-09-17 11:17:55'),
(834, '9650402c-8197-4f52-a105-c00d3fad4f4a', 'Aulewis97', 'Aulewis97', 'aulewis97@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0a.BmRxYoJQZYrfRxLUNmO1LPq0rv0YDprBCY8qNg2hBiX7i0dUIW', NULL, '2026-07-21 22:20:04', '2026-09-17 11:17:55'),
(835, '4356e5ec-2d5d-42e0-ba39-34024e3d9757', 'bucknasty', 'bucknasty', 'buckmasterfl3x@gmail.com', '+14173532947', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$gJhkEqxS6vXqeevpvz11LOzILdDFhVumbvTlf5zSd.Cx7DIRptGxu', NULL, '2026-07-25 06:58:30', '2026-09-17 11:17:55'),
(836, 'dd16afd7-6813-4381-b0ae-1d5d40917cf3', 'lindsaymar', 'lindsaymar', 'lindsaymariewright1989@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vKhLUEd6iggL7gHrnZFYNenQDUgly6WhDsfoG4dEb/FWyw1EWArFa', NULL, '2026-07-22 01:38:57', '2026-09-17 11:17:55'),
(837, '725a4205-cf56-48fb-851d-2dea916dc8b6', 'lind1989', 'lind1989', 'wrightlindsaymarie@gmail.com', '+13346615880', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$eN2BW3aPx5DCif4eDzGy9.bSJQ06T18c4QYfpEf8CNjoCAo7AzKbi', NULL, '2026-07-22 01:39:57', '2026-09-17 11:17:55'),
(838, 'bd4646f1-a1d1-4c49-952f-7ee98876356f', 'Steph0205', 'Steph0205', 'lestergarrett227@gmail.com', '+12764923258', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$GdApuqR1fN7swfn6xbczue37T8qfiubV4yMTSaW6rjhto8NG1th1G', NULL, '2026-07-22 02:15:30', '2026-09-17 11:17:55'),
(839, '4bd8111c-a665-4560-a2f5-f106bcc40f62', 'blakej2979', 'blakej2979', 'blakej297917@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$q5kGGPhlxJy.mULPT1rDHOVg2YQ.ggUe4vkl64b2/H.ZE3Q2CxBBq', NULL, '2026-07-22 04:29:54', '2026-09-17 11:17:55'),
(840, 'e3b1503e-4bb5-4b2f-a5fb-5112bf011da9', 'Mammas', 'Mammas', 'cmmendez69@gmail.com', '+14085044069', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/0o8EI12YsKiUz78xvuz8.Cp2/JCzxW2jSSJC9X7cJOhD6e295PZu', NULL, '2026-07-22 04:29:05', '2026-09-17 11:17:55'),
(841, '57f84cec-9e69-43fd-97ca-b0615e2fe66c', 'Evataft', 'Evataft', 'tafteva97@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$KTTOMkq8l.bAYObndJQeDuzIHUFBq2WIF6t8LAaMHGLBenqTyamyy', NULL, '2026-07-22 05:40:33', '2026-09-17 11:17:55'),
(842, 'df4a1c8f-4bf3-4a4e-9970-64e99230c49f', 'jdscrap91g', 'jdscrap91g', 'jd.scrap91@gmail.com', '+16787828483', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Snyv3X77xtUvNmUfDhTbHeePOApTad7UIbmRiLoKArv/rtxehhhM.', NULL, '2026-07-22 08:03:08', '2026-09-17 11:17:55'),
(843, '93cc5f97-7159-403e-abca-440ce42229d7', 'Rollinz13', 'Rollinz13', 'jacobrollinz489@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$nCDb51AdUE9A/tAguy2dwOa/nnUNnMclren5Jt9DQmT27tEFS73Qe', NULL, '2026-07-22 13:48:09', '2026-09-17 11:17:55'),
(844, '92cd6414-ab5f-4683-b0d0-75f4e718d21b', 'sphakinsgm', 'sphakinsgm', 'sphakins@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RJXRQIw1fCPcHXjd5VZX1.SxV7yYv3JmjuU6/9wNcVVGet1Cb4.02', NULL, '2026-07-22 14:11:25', '2026-09-17 11:17:55'),
(845, 'bd389fec-af8a-464b-8506-0e432c565f4e', 'faughtpatr', 'faughtpatr', 'faughtpatricia7@gmail.com', '+13252202042', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$Qttuu9uBNuuvAX17zwv0WOZmPElJH9Qckwn0XgAfY/Xc83k8Y8d5C', NULL, '2026-07-25 11:29:18', '2026-09-17 11:17:55'),
(846, '6e199a59-320c-43a7-a508-3d3468b48886', 'jontorres3', 'jontorres3', 'jontorres394@gmail.com', '+13855907447', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CmHS/OPQJ.c7lFHAWdY8uebWR2iWvhPlaBZuWjw/Xam/i0/tBxfra', NULL, '2026-07-26 05:26:44', '2026-09-17 11:17:55'),
(847, 'a9fcf9bf-2b4c-4209-aaa7-d39beaf85777', 'Bronson Amaral', 'Maukaboy21', 'bronzzzz821@gmail.com', '+18084804815', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Hawaii', 'Male', '1989-08-21', 1, NULL, NULL, '$2y$12$nUZmUvKKXV3ZfVZsJvw4EuD0Ku5pGcWF5lFhxjsqVB76z2ca12s9u', NULL, '2026-07-22 17:08:36', '2026-09-17 11:17:55'),
(848, '2b80eb2e-952f-4853-befd-24e697947c46', 'Gabbie0218', 'Gabbie0218', 'raiynez1129@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JvGEQAgJv9ybibeiVby4z.yC8b.C/UI06JencHljZP77ezXV2ToqG', NULL, '2026-07-22 17:55:18', '2026-09-17 11:17:55'),
(849, 'b43f792c-0881-4cde-9c43-f87ab3a3121d', 'Gabbie1129', 'Gabbie1129', 'shecara3@gmail.com', '+17406176362', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$LYRDAm9tByamol1ben8TJuL3hIgNnFew7zlwGbxBs4HCf2VSsksSi', NULL, '2026-07-22 17:58:04', '2026-09-17 11:17:55'),
(850, '8622a2e7-78d0-4aaf-95bf-0df936354b32', 'Tony Shipley', 'twotone85', 'twotone0355@gmail.com', '+16015907744', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/8622a2e7-78d0-4aaf-95bf-0df936354b32/avatar.jpg?t=1784069304743', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Mississippi', 'Male', '1985-11-16', 1, NULL, NULL, '$2y$12$ExUpmZN6eDUo.simKiFmAOWYaypyE4wMk.INEh2.vq2YOq6urxizO', NULL, '2026-07-14 16:41:28', '2026-09-17 11:17:55'),
(851, 'd407d20a-1d97-41d6-a5e3-5217c7a05f79', 'Yeshua82', 'Yeshua82', 'goodman82mo@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$p37LDxWOhkVjY86jhpmiOeMUnB2KXGK7KfMAhWRTcWQMrC6/KwdQS', NULL, '2026-07-23 02:26:12', '2026-09-17 11:17:55'),
(852, '8ca8c7b8-fb04-4ac0-bfc4-3c5aee3cc89c', 'Skeezah43', 'Skeezah43', 'sharnellhoopaikalahiki@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZC0fPZ51VlgmY7MLrJ.H9uWhss.sx67YCthqLckVfzFiCSntYCMDq', NULL, '2026-07-23 07:25:48', '2026-09-17 11:17:55'),
(853, 'f55843b3-08ed-4c5b-9268-740910e58561', 'Haleyalize', 'Haleyalize', 'haleyy990@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$A/eXAe5AiktuDZ6/hxLTTeuyVZ9OUFSPyypp72MZn1gmLihEarUIG', NULL, '2026-07-23 09:58:29', '2026-09-17 11:17:55'),
(854, '33688d54-2b52-4088-87e6-b3d4c988a9a4', 'Ngb1978', 'Ngb1978', 'brockwellnick789@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Hy6r6fUabaBbtJ/CeMq3jOnm64d7CGYX7YGtPsEbXKxAw2333Ckoy', NULL, '2026-07-24 00:30:29', '2026-09-17 11:17:55'),
(855, '32d488a8-6a3e-4d3c-925c-f743f61cbc8e', 'Carlaapena', 'Carlaapena', 'carlaapena@gmail.con', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dKjJDgDZ.m3lORJOSeT71uj0GLGG7tfCS0xTreD8NikDp6Wp6p1fm', NULL, '2026-07-24 02:11:01', '2026-09-17 11:17:55'),
(856, '4a7e56fe-2335-43eb-8472-809ff833dda2', 'Carlapryor', 'Carlapryor', 'lexielou330@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$d7HDpbtnKTI8q3omsDploe3UYVTRa0TtDDJ/wemMcFvJAuph6HwxC', NULL, '2026-07-24 02:22:10', '2026-09-17 11:17:55'),
(857, 'c328daf8-66af-455d-b8a8-26ab17fe15eb', 'Jordan', 'Jordan', 'jhenanightengale29@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$M9ClnjpjSRWcxhollBHX2uUKSz8srV495.IhouJhqP4pKNcr8TLsW', NULL, '2026-07-24 05:38:35', '2026-09-17 11:17:55'),
(858, 'ea928207-de73-4399-a1f7-22e7fde36eb6', 'Derryberry', 'Derryberry', 'mini.me.too.many@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tPZ.r2s3VDcKv7mqf6dEV.UWZ65zRa4jWsl5zXKSYkvvpogBG5rnK', NULL, '2026-07-24 19:19:44', '2026-09-17 11:17:55'),
(859, 'e34a1a3b-1a55-47e6-9c26-55833b334249', 'Phicks92', 'Phicks92', 'hicks101625@gmail.com', '+19704395523', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$QqtDaUKlK3LIaQCbE9pziOGHQqApu5OiKgz9mEaXegjP6JiQH7TpS', NULL, '2026-07-24 19:26:38', '2026-09-17 11:17:55'),
(860, '64e4daaf-d6df-47bf-8c00-129375d6cc59', 'was987532g', 'was987532g', 'was987532@gmail.com', '+19036922558', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$FRrk4DxsVfXQ97w0iofDMu5SnVT/5LVtEr6ngTg/iLx07G6/Mkbpi', NULL, '2026-07-24 23:34:27', '2026-09-17 11:17:55'),
(861, '733bd825-fbcb-4e54-9ddd-cb51bbc43968', 'Brownroyal', 'Brownroyal', 'ervin.emptygutters@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$H9s3xZ0VxTNgJA6HkRbHv.DzDN3G4TTVDS203cDOP/nxEzORo4HZe', NULL, '2026-07-25 00:43:17', '2026-09-17 11:17:55'),
(862, 'b1e0b5f0-a0f9-4ec1-8429-564f3f040c16', 'Aynsley', 'Aynsley', 'badbitch851985@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$rPXYxO/VIQMFtug2uFEBk.9Q2C/EgnZcnLYLQHeFJ13O0wWzXeBeq', NULL, '2026-07-25 10:32:17', '2026-09-17 11:17:55'),
(863, '77756edf-bbbe-4974-9292-21c41f978747', 'Tanalopez', 'Tanalopez', 'lopeztana930@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1C2r097Bf/GM/bvXnGpV4.2r4SA.M27ykVuJUo0oe9NcIXpgbzn1.', NULL, '2026-07-25 12:40:58', '2026-09-17 11:17:55'),
(864, 'ff60ca72-4e61-4940-abfe-0130f70e5eaf', 'Jake6911', 'Jake6911', 'jacobtate401@gmail.com', '+13364449533', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$M/OaH5.QZobSOm503w9laelR.UkiHfAocxXDpeZupmaXD/tk2qYzG', NULL, '2026-07-26 09:10:58', '2026-09-17 11:17:55'),
(865, '0cec126f-3de7-47fc-8411-95d010109f42', 'michelle49', 'michelle49', 'michellele294@gmail.com', '+17142325814', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$PoTMYbBFnaCxklRudLmWu.c6168Mk9pF88xu9nyTW38./yNZpZY86', NULL, '2026-07-26 14:59:37', '2026-09-17 11:17:55'),
(866, '700c9a50-4bbf-42a9-93d3-c07a2f6f9d8e', 'Latoyanell', 'Latoyanell', 'latoyalanell202024@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dwcWIq2eCfFe07R.pTzDkO4LOsPzpSW7Gqu22PO.E6mr9fT14FinO', NULL, '2026-07-26 19:47:07', '2026-09-17 11:17:55'),
(867, '00dff76d-86a6-4a79-9934-323e9c438bce', 'jf145732', 'jf145732', 'josephfletcher781@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8A0yXvbtCK/IDNKCFNitEu3lcjjCT6.5uLUa.KIIEZvcm/BivK..i', NULL, '2026-07-26 20:53:31', '2026-09-17 11:17:55'),
(868, 'eb50ccc9-5015-4fec-9cf1-78da70b92e59', 'Goodbuds', 'Goodbuds', 'pesanojames2@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$mKYHKFT6jwdVroaYO9Uhf.JJFNvuobQ8VdZwG8TU/QCDJiZ4SdthO', NULL, '2026-07-26 20:53:31', '2026-09-17 11:17:55'),
(869, 'f5f92f89-8ebc-4307-8b14-664d4e421b08', 'craighonko', 'craighonko', 'craighonkonen0330@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$h84InUxt9zu95ZdO0QLw3eCQXriyXTidIo3TtnRcO.UNMeG.8bV4K', NULL, '2026-07-26 21:20:44', '2026-09-17 11:17:55'),
(870, '1c9fa304-30fe-4c77-8aab-ce77afa3b848', 'JasonManas', 'JasonManas', 'jasonmanas757@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$iAGvWQ9lspSv3U.t96kkxO8DT9Lx3UNa52MDJI4OjqLxP624Eq29y', NULL, '2026-07-26 22:20:49', '2026-09-17 11:17:55'),
(871, 'd7f2e476-0cd5-4f4a-a852-fd45331baed4', 'rogerbonit', 'rogerbonit', 'rogerbonita068@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$zL6UTwVUcgVPd7GZWlZIx.Sk4A1AkekDKFeGp9K65rt3a6UjLee5i', NULL, '2026-07-27 02:00:14', '2026-09-17 11:17:55'),
(872, '64e83d93-2af1-4dfa-bd8d-c98fa80da242', 'Ijustwant2', 'Ijustwant2', 'ijustwant2beloved.4me@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7AT9si6I.6e6WaNNSFAwr.fLP8V7BQBvM4qPtqzn2p.MOSE47uZX2', NULL, '2026-07-27 02:35:26', '2026-09-17 11:17:55'),
(873, '9d482a0c-d4ec-4321-80b8-ad4279c800a7', 'tabbydavid', 'tabbydavid', 'tabbydavid1114@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1Iyx7U35b9sxqT06oIxGKO79xRdkQm.PFa9zQy0HChA7rnouL9c32', NULL, '2026-07-27 07:48:23', '2026-09-17 11:17:55'),
(874, '34eb1c21-f6bf-4390-95bf-dc2434e7514a', 'Reddredd69', 'Reddredd69', 'amherst.clair89@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4W1rbbzgzBoaDGtJrbSBDuZxZKMLJx.Wsu21NTwUVCAixKaj0.h8C', NULL, '2026-07-27 15:22:37', '2026-09-17 11:17:55'),
(875, '488a2dc0-63c7-4ff6-bef3-c33a24427e6b', 'Fishyngyrl', 'Fishyngyrl', 'tripihipi88@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fZFN2p1EhzqRRrDpudZLP.T2r2NIgAReWnJGtYIKSRRmMoC.9lpUG', NULL, '2026-07-27 19:27:24', '2026-09-17 11:17:55'),
(876, 'db2ea391-32cb-42f0-a879-b85b3a05dde3', 'mlanaexoxo', 'mlanaexoxo', 'm.lanaexoxo@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$z0iDhP73gX3Qkkyr7jlxcOxoH.XL0ZQKeWhUcMsIo3crX6dmdELQC', NULL, '2026-07-27 21:11:48', '2026-09-17 11:17:55'),
(877, '1cd30634-6339-4089-b014-ce24dd7c969f', 'Warriordg', 'Warriordg', 'hl.taylor88@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$RWUkA/CUaVyyu4KqS1gnpuByR8v/LS3K6.YZUoZzvX1XVQm7kYykC', NULL, '2026-07-27 21:30:06', '2026-09-17 11:17:55'),
(878, '49e57cbe-4e08-422b-a712-c77ef61372b3', 'robertsing', 'robertsing', 'robertsingsaath74@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1T5hnfr3sHpbkOE7.Bgdl.aZ1u/6WnCQ2q2AVIAp4HGIsdtQdzJia', NULL, '2026-07-28 00:19:14', '2026-09-17 11:17:55'),
(879, 'a26eec84-0fe0-46bc-ac6c-b769bb6eab17', 'christallm', 'christallm', 'christallm702@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2/XHTQdFJbbIOp83EqYrmu9opinsp.aa2rPtQKOtXA2LbtSVmRz4W', NULL, '2026-07-28 00:23:35', '2026-09-17 11:17:55'),
(880, 'a9898d9e-5c3e-4115-8135-59aad4d46ed1', 'Ashleylynn', 'Ashleylynn', 'mccolluma240@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Kn6mmqdpcWPA1Kd/TBGRl.77KC/QGNbFrJ4hWXyaZ5FB73lxcHs7O', NULL, '2026-07-28 01:56:20', '2026-09-17 11:17:55'),
(881, '376b57a1-6347-4357-adc9-98665631e141', 'Butthead', 'Butthead', 'almccollum1@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$eZkUR2wWEjxRnkH/uZf95un9.N2BEV6nAQ2nRK/BDEeAEKyJaZYYW', NULL, '2026-07-28 01:59:47', '2026-09-17 11:17:55'),
(882, '88c3874a-21c3-4276-935c-59b865f823d1', 'Ashtaybo', 'Ashtaybo', 'itsthebos121518@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$50xulqiUhBodXK9w9uQuFeiT/8OOmbv.73SPpFbVXFzX4TTEAFhHG', NULL, '2026-07-28 02:02:02', '2026-09-17 11:17:55'),
(883, '047d2aaa-dfe1-4bfd-99c9-676a32429c14', 'Samm1q', 'Samm1q', 'samanthaharveston@gmail.com', '+16016604714', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$CD2F4fB3hofHNuhaRSHCsOnj3uXrU007yR1CSqDFG.wXN8MeXXJvK', NULL, '2026-09-04 00:52:32', '2026-09-17 11:17:55'),
(884, 'ca9db148-d955-4ccc-942c-69ba5b8e513f', 'Buttcake93', 'Buttcake93', 'rbtblt93@gmail.com', '+13346436817', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$vzfsCn8RMVdwoDqomVXanuF5oDrQiL7Qr2HQwk9bgURWKDGJ/r8uu', NULL, '2026-07-22 00:27:54', '2026-09-17 11:17:55'),
(885, '0d471f5f-ddbf-4094-977b-2efa3648724a', 'Justin Peters', 'Jpeters123', 'petersjustin2169@gmail.com', '+15134352325', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Ohio', 'Male', '1990-06-29', 1, NULL, NULL, '$2y$10$LYwh6jRn0.zD7TlOKKPl8OPjs6Xy9/bF//Mf2ZDSjqxBTMvNHPW5m', NULL, '2026-07-28 08:26:20', '2026-09-17 11:17:55'),
(886, 'f5069f6c-b058-43cb-9215-33b2b8017bdf', '666prncess', '666prncess', 'feliciaanne666@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2GNuDbH/AlYSckpOwig6LOWaVED7fJ0MxCVvY8Bxv1tW8vXWjFjR6', NULL, '2026-07-28 13:18:08', '2026-09-17 11:17:55'),
(887, 'f8e02452-4d64-4b5e-aea3-345dc906453b', 'saranemeh', 'saranemeh', 'saranemeth03@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$O/1V/S.FTqlSUwEtX2jOuuwlSIVpMWaCHQXoM5DYmzhHVnGQq2tde', NULL, '2026-07-28 14:41:36', '2026-09-17 11:17:55'),
(888, 'df2d614c-f2dc-4a6b-a953-6134131e3a8d', 'SaraNemth', 'SaraNemth', 'saradnemeth83@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$oVL/ndFiHse9fya6w1eE5eKY9MjE8JVd13guTWlan520boTdwe6oK', NULL, '2026-07-28 23:57:59', '2026-09-17 11:17:55'),
(889, 'd479429a-f8c5-44ca-8bb5-e647d22fe9d5', 'NinaM14fk', 'NinaM14fk', 'metcalfnette3@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1ZNKx/fp9dL6At23AHv6auePfIaueTpUucuBNTHZtltPoKgyCtili', NULL, '2026-07-29 00:53:04', '2026-09-17 11:17:55'),
(890, 'a4b2484f-59a2-448a-bb32-c2b06aa3db4e', 'Boricua', 'Boricua', 'alicegonzalez263@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$CFX3v8Omf1CSau.U7cBaf.Yko8CH3LCFTHSwzIvqa.SIWCUS.G/nW', NULL, '2026-09-04 01:54:31', '2026-09-17 11:17:55'),
(891, '3846a055-5965-47f7-a745-bad4bf8e0492', 'Suki22', 'Suki22', 'dezzyrayz1289@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$d6pJ4F7lq3s0b9JOA8LUEu0vFBs2uTfVZdK0jW6R9cD73CbUgFi5W', NULL, '2026-07-29 09:09:25', '2026-09-17 11:17:55'),
(892, '5131a72a-261a-4189-9a45-43320e589b05', 'Melinda123', 'Melinda123', 'melindahatfield81@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$lDZeRF.MTgrcuNom3QZSyuFL3JIeD15kB6BNeCWh78/QJYB7kklNe', NULL, '2026-07-29 09:23:07', '2026-09-17 11:17:55'),
(893, 'f30925fd-e237-4815-978c-bbb27a84468b', 'Derrick88', 'Derrick88', 'chevyblazer888@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$cLqz89/4PzdesRN2Hc.C1OtGoNF38h39H1tKhSfafH6.sqV5Tckp6', NULL, '2026-07-29 16:08:52', '2026-09-17 11:17:55'),
(894, '4123dc1c-0a96-4be9-a681-36315c753c00', 'Shortyloke', 'Shortyloke', 'alina.bernal69@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$r3xKO2TaWmNJrP1ZL/iCyeKUsndr3X6AWYVxjvUlUciJlPGJ8GyXa', NULL, '2026-07-29 17:23:46', '2026-09-17 11:17:55'),
(895, '6cd22ec3-89f6-4cca-be05-a85b932338a7', 'Alexacost4', 'Alexacost4', 'galexandrea56@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0FtnkQYh8rpMSLDiHLiwY.Mw2ZhUQPgVLz5wjpBQ8HYJPg2oHbrZi', NULL, '2026-07-29 21:07:39', '2026-09-17 11:17:55'),
(896, '43f8604b-fd0d-4974-80da-9fb84fdf8240', 'Pixie1', 'Pixie1', 'queenpixie34@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dKQCfyewXoVY.AhAPNkVrObeeepE4X.KgRw1KpdaIMixbA.Gj6U72', NULL, '2026-07-30 14:32:48', '2026-09-17 11:17:55'),
(897, 'd520a5c8-d8c5-4023-a208-db56073cab0b', 'RichC420', 'RichC420', 'tezmanian420@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$k1TBye.BBX4jg78m.dq5RuqaMGY6rV0hxmJwxtIcCWkCNAAC7IQF6', NULL, '2026-07-30 15:51:43', '2026-09-17 11:17:55'),
(898, 'c92d2740-d056-4df8-86b1-9f959af1f239', 'Boyer13', 'Boyer13', 'joshuaboyer287@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$WJ9di..Xb2GoaQutYBkwEuIc8vjXMEssad7G71WGiwMwLGA7Dsloe', NULL, '2026-07-30 18:28:34', '2026-09-17 11:17:55'),
(899, '0050a75a-d4be-45da-8c25-6a5aa15b4cfd', 'Dre1979', 'Dre1979', 'dreonly79@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$I46jw6ia42zHBunwxFtA/edH.TSCwMfcStf62ZHdT0yjjBQe8EmuO', NULL, '2026-07-30 23:00:37', '2026-09-17 11:17:55'),
(900, 'e9a50968-af35-458f-aa2f-26f9890888ee', 'a76757492g', 'a76757492g', 'a76757492@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$zKP3x3tdF01AjwXKrc7JTu706SCcvemsPeS7qrnlYhEhgOoagj/Cm', NULL, '2026-07-30 23:31:16', '2026-09-17 11:17:55'),
(901, '76170d32-d796-44ab-b276-2d55e7b663b1', 'KingZino96', 'KingZino96', 'kingbenzino666@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hQzUz4uaMpetH3WIMg5/HencsftY/scJW7VoR.Dy7N0mOx6hBUY8K', NULL, '2026-07-31 00:32:00', '2026-09-17 11:17:55'),
(902, '83fa0a2e-c511-4574-bc95-91e8c5daecf5', 'LaDarien75', 'LaDarien75', 'pittmanladarien6@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$WoS7FtXqBoQkGFcgoJ3AQeU3fzjbmE.rmMtlwqw6.Wc5UzOPx2JiS', NULL, '2026-07-31 01:59:50', '2026-09-17 11:17:55'),
(903, '02487a98-fc74-4d06-baa7-460ddfff963c', 'Jessisbest', 'Jessisbest', 'jessisbest8585@gmail.com', '+13865309371', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dzUmzihLLNsxfFfhbFsKG.po/Mb2zz/1ES40cUcAMI08pv0OLB37i', NULL, '2026-07-31 08:37:49', '2026-09-17 11:17:55'),
(904, '53a30b46-8ddd-4287-9f72-548a53d6f70d', 'LA1980', 'LA1980', 'branchtanya5@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$HN7GWKRs0KrO15XlBXAPY.RDHzEYjfDyPa8n0eeHLCHo1nrOCNZ9m', NULL, '2026-07-31 21:30:24', '2026-09-17 11:17:55'),
(905, '6605519f-1771-4a82-a3f0-a2bfe2b80da9', 'BigB37', 'BigB37', 'crawfordamberida@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$cm5LsHI8O8wN82E4iHUGaOP/WM.IX94WXoLIJ/tEEJvE0tVnYDquW', NULL, '2026-08-01 00:12:45', '2026-09-17 11:17:55');
INSERT INTO `users` (`id`, `legacy_id`, `name`, `username`, `email`, `phone`, `avatar_url`, `ghl_contact_id`, `balance`, `role`, `is_flagged`, `flagged_reason`, `flagged_at`, `email_verified_by_admin`, `phone_verified`, `phone_verified_at`, `country`, `state`, `gender`, `date_of_birth`, `email_notifications`, `email_verified_at`, `last_login_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(906, '953e2b8d-d715-4535-8778-55a4c247f89f', 'BigSexyRed', 'BigSexyRed', 'brittneycraw36@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$rddLYSP0HVMtBv03XeV6ue8oETC1lL2gnJxoHxC9F34r5iQ/VqBoW', NULL, '2026-08-01 00:14:15', '2026-09-17 11:17:55'),
(907, '7fdd51a3-e2d0-42e1-8233-8d3af786aaeb', 'GobigD', 'GobigD', 'beltonladonna286@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$DC2j1ehukRNZ.XwK0Rxm..zb7dRTppijE9u6nDDmiaqei.Kq6/chy', NULL, '2026-08-01 02:36:26', '2026-09-17 11:17:55'),
(908, '29acf126-919f-4a62-a675-979b12db0e8d', 'Keepitup23', 'Keepitup23', 'forever100real@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$EpKQSN.0JKK4a5R4xZwoPugRw6wYgj9PP3WcHDxk/JkwBuZZ8ZOFe', NULL, '2026-08-01 04:21:19', '2026-09-17 11:17:55'),
(909, '9415a1a5-ed2f-417e-a3f8-2a19d4e142ed', 'Bobdnlg', 'Bobdnlg', 'dws1121@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$8lYLSRZmkpNxVilGEk3Wn.ed9/2sR24aljoT7rqv6wUrGH.81t9a6', NULL, '2026-08-01 15:13:10', '2026-09-17 11:17:55'),
(910, '893139a6-33fb-4efc-9665-2b4106c2ea1a', 'Klown666', 'Klown666', 'leviaseale@gmail.com', '+19033607627', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OxisPBk0cRSQbMQGAlJxgeTmPoWGtt4WxGZnqGLZsxNabt7RdgDyi', NULL, '2026-08-01 15:26:23', '2026-09-17 11:17:55'),
(911, '87dd012a-75c4-44be-9b9f-c3f41166cad0', 'Bigbayb', 'Bigbayb', 'my3ninostygod@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$zvYyFWN8tvWFgQvLZu5o/eHckfmT8hDzvSv7mz1./N8ugM/JIUjlm', NULL, '2026-09-04 17:23:54', '2026-09-17 11:17:55'),
(912, '514817a5-104e-4f77-baa4-0075a7d8a412', 'Abramo77gv', 'Abramo77gv', 'morls007@icloud.com', '+15593730671', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Q.Irjj.579HDhCFAFwoRHu34aHbZBjseAClq267LDLR/1ocSXTAaa', NULL, '2026-07-31 22:01:23', '2026-09-17 11:17:55'),
(913, '3bf22fcd-4550-4b8f-aa63-16dfda0c6c15', 'Moni9026', 'Moni9026', 'sotoyodi3@gmail.com', '+17377172180', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sYeXhyfrymJgG698bJXG..UDgwRu/WX3HcyGZUsLJ47wfW/AR5IAK', NULL, '2026-08-01 20:39:35', '2026-09-17 11:17:55'),
(914, '5d78da75-8799-4b3e-8b89-0e487fde0f65', 'Kaylou90', 'Kaylou90', 'kaylou8990@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hPgbqOctS6PR85V361x.7uYnA3B7n/BI6a3bX1Yhq0UIHBXOpIsPW', NULL, '2026-08-01 23:21:14', '2026-09-17 11:17:55'),
(915, 'fedf91bb-18f3-439a-858b-74add0e3cad4', 'Coleybby02', 'Coleybby02', 'nicolegoldshot0212@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$1nosnSnjrHvvDtaB4A4.S.XvuMCSLW2smyrS939YJFUba3eA69aNe', NULL, '2026-08-02 00:10:02', '2026-09-17 11:17:55'),
(916, 'c58aa202-3229-4b76-921c-df890414657c', 'Kevro0937', 'Kevro0937', 'kevwrowe89@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$OqwDGHdSkiijRgrNBJkoDe/bHHwBkB7eeoiKOkb0OT4EKK1r82tcu', NULL, '2026-08-02 13:09:16', '2026-09-17 11:17:55'),
(917, 'f0822a0c-6079-440a-8472-e08bd770f2a7', 'Ronald “Dean” Creasy', 'DeanA9gv', 'rcx3823@icloud.com', '+17653572724', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Indiana', 'Male', '1990-08-24', 1, NULL, NULL, '$2y$10$miyHM577Az684KH7uJG2xehjnjQr1G9bs7Ts12xMHt9xQMpanUPOq', NULL, '2026-08-03 01:32:31', '2026-09-17 11:17:55'),
(918, '7ed16dab-086c-4c2f-af5d-c832593d406b', 'brandonhig', 'brandonhig', 'brandonhightower9@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ek9Isax8DVJEN24AZLEmCeDnQgpxj7ON1oOMPctEc605p0yHx8WGK', NULL, '2026-08-03 03:14:39', '2026-09-17 11:17:55'),
(919, '21ec3cb4-00fc-454c-8b90-80fe488c65c6', 'epicbaby19', 'epicbaby19', 'epicbaby1993@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CPh5RQdWEzpCQIOTpCoFc.C.UoFbIMTpuztPI1FHjYMClVmGdsiZ2', NULL, '2026-08-03 03:17:01', '2026-09-17 11:17:55'),
(920, 'f65197fb-c368-4dc4-be21-80d61b22e00a', 'Sylgonz', 'Sylgonz', 'sylgonz152@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$UMHxtfohtiOg8BMVoDn1SuH3M235xushVrjbASls3xwLBBeLuqHIS', NULL, '2026-08-03 06:26:52', '2026-09-17 11:17:55'),
(921, 'af50154f-8eec-4e2e-bd2b-550cc5ac1527', 'Princenem', 'Princenem', 'emilymadrid92@yahoo.com', '+12136681018', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$gkZi6xg6l9KXHKpFqp2wH.KUtAwS5hU/Ltg6xO7tdPmYK9.95AthO', NULL, '2026-08-03 06:10:56', '2026-09-17 11:17:55'),
(922, 'cef60dc9-dc66-4032-a401-32e58b767c52', 'AllW5vb', 'AllW5vb', 'scorpioalways11@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$sioYdyPLId0ML7KqbYZQsuQKI5hmYlDWrRcmMnv.JfXDCa9PUC35S', NULL, '2026-08-03 06:44:42', '2026-09-17 11:17:55'),
(923, '7aa42053-b871-4638-a8de-39f2f63ae723', 'King863', 'King863', 'portertyler863@gnail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$c2mjhy6SseA5ZWl.T5UUMO8baBXccgD3hyv0Mueomqwzi1VuQAGaa', NULL, '2026-08-03 07:06:06', '2026-09-17 11:17:55'),
(924, '43ba0b3c-0d56-41c1-9639-1b22e4cbfae6', 'GIGI0721', 'GIGI0721', 'brittanyweldon79@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CARBQJtwEZ7oB/xwYQQzOOSvVPFQTPwrSMYdfOK0TauogED9LZYzO', NULL, '2026-08-03 11:14:16', '2026-09-17 11:17:55'),
(925, '29e03117-3a7f-4079-801a-27251848e531', 'BrittanyW', 'BrittanyW', 'weldonbrittany775@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$j9pAclEAN4.lvvvHmEJI0ujvM1nZ58pS4UEnPRn.E7Ne.qj4VOJP.', NULL, '2026-08-03 11:20:16', '2026-09-17 11:17:55'),
(926, '865f4d3d-822f-4db1-9af5-ad3b432e69b2', 'mezaguamar', 'mezaguamar', 'mezaguamaria@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$C6mWPWsDMOqkpiH8Mrh/l.Jkj2Rue9aWODhMZydZxwB6ig0csCD/W', NULL, '2026-08-03 11:59:29', '2026-09-17 11:17:55'),
(927, '1b372fcf-4906-4a5d-a062-55faca928318', 'Effiemarie', 'Effiemarie', 'effiemarie339@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2ivHw1YibtjW6H1abBwodu8i1Ewvyd6Mo2vmMk2BElvuc35NmgJre', NULL, '2026-08-03 13:12:20', '2026-09-17 11:17:55'),
(928, 'a2107814-9b10-40dc-8e69-06c415260bd3', 'Elenita831', 'Elenita831', 'medina.140831@gmail.com', '+18312798522', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$6IhAOAiigFRlmhbJ0kMxHOz8rlQOz3f98M97JNrigwttSnkf8eizu', NULL, '2026-08-03 17:42:27', '2026-09-17 11:17:55'),
(929, '08f554f8-b519-4519-a62d-b85a1803b5ec', 'Smitty', 'Smitty', 'jerryesmith69@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Pg2he0EQfsWpGRG5CvCHJe/qN9DkMHbyMDwpQYl9LAlVWvallTKci', NULL, '2026-08-03 23:04:16', '2026-09-17 11:17:55'),
(930, '88900545-5763-4d32-a6c3-0adaf0dde4ff', 'Kencole', 'Kencole', 'combellackk99@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$gic.2eg3/IOZ4JrmHwxwRuVmnH02oYfRmyveMCbZfJ7Bajr5jxJ/.', NULL, '2026-08-04 01:31:30', '2026-09-17 11:17:55'),
(931, 'ea507afe-9a9e-4cc3-b5aa-f3f7b389ec8c', 'BayronB22m', 'BayronB22m', 'bayrondelgadoreyes14@gmail.com', '+18402233274', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$l4uW1HZG94MFbDW7LycW5eR.9dlo0rtSpOTvFjeVTtsxxBnIV13pu', NULL, '2026-08-04 06:27:17', '2026-09-17 11:17:55'),
(932, 'c65670af-d25c-482b-9ddc-ce804fa7e297', 'Cynthia  Miller', 'forever77h', 'forever77his@gmail.com', '(352) 461-9309', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Florida', 'Female', '1977-10-04', 1, NULL, NULL, '$2y$10$quN7H8a2zSQim6Lcdmb/c.p/xKT6gKR25l1jbrqgCfCy4IhQUIJ6C', NULL, '2026-08-04 14:13:09', '2026-09-17 11:17:55'),
(933, 'f2b064a1-9b20-4c28-8332-0f8ba839c078', 'Legends26', 'Legends26', 'oneal24534@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$QA0hgG1OOqh3XjSngmh7XuNK4fgcJxJ30O1mvfJLAOUr49EoFnk/G', NULL, '2026-08-04 19:23:46', '2026-09-17 11:17:55'),
(934, 'b1779546-c601-438a-9c10-394a0fb525bc', 'BerT8os', 'BerT8os', 'loriberton1971@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Wshlz4fsr0qWHdcee8fTbO/a3Q2OGDok0rnVehIPOKvi05rjNkQpy', NULL, '2026-08-04 19:27:15', '2026-09-17 11:17:55'),
(935, '45c1cb01-4f99-4ee1-8016-93c5d5275a05', 'Rhondaak', 'Rhondaak', 'rhondanewman80@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xd3kXGv3sqgc90ICbFsNU.zlXCS0Tv9GEMyt6YB4ikqsNV1Kpyjc6', NULL, '2026-08-04 19:42:52', '2026-09-17 11:17:55'),
(936, '021bdcb6-0489-41ee-a43e-c180054dc574', 'Akrhonda', 'Akrhonda', 'rhondanewman80@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xgNA6QWuno3rz3fqhfbWPurAWamXjo8DXPXsKrmb.Eb1DFSrQx91i', NULL, '2026-08-04 19:50:56', '2026-09-17 11:17:55'),
(937, 'e6781b2e-2158-4988-8608-e89112917f42', 'Tiffnshu', 'Tiffnshu', 'tiffnshu@yahoo.com', '+14236761632', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$w23gfU40CZ9Iwg5VMkNbIuHlQ7Q1klJGOH3i7aHlS8pogxa1Mtlde', NULL, '2026-08-04 21:50:07', '2026-09-17 11:17:55'),
(938, 'aee50f02-8667-4e29-867d-d5884ce0befe', 'Jimmy544jw', 'Jimmy544jw', 'huertajaime546@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$RMNDj/GcrRLfyLrW7.nVtO63DrCxfFpyzHYopGvNOQs9I4cULIIji', NULL, '2026-08-05 04:02:16', '2026-09-17 11:17:55'),
(939, '29212cd4-934a-4073-a41b-07358f13f156', 'Chapis04', 'Chapis04', 'chapisoropeza04@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$06TgOg2heo.8CiIpHI.X0.FvvoBkoDSoyXyb7EAO1vENPfIDiSu8S', NULL, '2026-08-05 05:23:34', '2026-09-17 11:17:55'),
(940, '60d03e45-ce4b-47a3-b464-352ad4362477', 'Grayl52', 'Grayl52', 'grayl525252@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Quj2B97VGWzZJMXlKBaqGOiRt8QDrUH0O/Cx2j8z9JJIdYxAiWjea', NULL, '2026-08-05 07:52:25', '2026-09-17 11:17:55'),
(941, '67c9925a-d473-46fd-b107-b4f94512d170', 'SHAUNESSY MARSHALL', 'Boogi342', 'marshallshaunessy@gmail.com', '+15122135433', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1995-08-23', 1, NULL, NULL, '$2y$10$8XDT.QNYUiTei0bgbbv8oOpobwGdSrO.yVJ/L/TowMhATDXDdiKfa', NULL, '2026-08-05 06:20:55', '2026-09-17 11:17:55'),
(942, '9e7eb113-2987-40e5-8331-31b84fb352cd', 'Grayl5252', 'Grayl5252', 'lisa04141976@gmail.com', '+13186789704', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4L8J9TweLld.6alwx0ixHOnp5EYgvbuhNM.g3SIg6fPIfcDrFQc3i', NULL, '2026-08-05 07:58:45', '2026-09-17 11:17:55'),
(943, '85c99b28-951f-4899-bdbf-93d0df3d2a8b', 'Bondgirl7', 'Bondgirl7', 'bondcandy0@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$lmBGOYVPYGufa7TEpCEIVObJtxqMJk86DUWHYg3NCk7Q1t3v.HUE.', NULL, '2026-08-05 08:37:15', '2026-09-17 11:17:55'),
(944, 'cfa4ca27-5d1a-4c76-a00b-627543ebf01d', 'Babylungz9', 'Babylungz9', 'pamelal9305@gmail.com', '+18302010440', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$pj2WmKye1qpG6/McyrEUJuIlxrCvRRLauqYu3abNdsOGu6hNe68ly', NULL, '2026-07-29 00:18:58', '2026-09-17 11:17:55'),
(945, '062fb79c-2d4c-48d1-8947-c5ba75d8deec', 'GoldPorsch', 'GoldPorsch', 'newhabbitz9@outlook.com', '+12056591361', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$2KRsrb8/pYzrYR2GhIE4/uBYsS9wLRKxuZBw5Ahclvp73OGmt1eCS', NULL, '2026-08-01 17:44:00', '2026-09-17 11:17:55'),
(946, '0427f1c3-cfc6-4c5e-a17e-f4f07af8166d', 'kennsbooks', 'kennsbooks', 'kennsbooks@gmail.com', '+12055096862', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ZJv.t/zffbNGVC3M57aiPOflBJ113kUx/dOVMfEzFOJmvYKNBVhN2', NULL, '2026-08-05 16:25:56', '2026-09-17 11:17:55'),
(947, '1bcf1f29-4a89-41c9-b022-c6b97bcf7e0e', 'Jenn16', 'Jenn16', 'gracejenn123@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$la7c/Kf2kgxid6ws/450dOvA0pBLilL8w6RFp84UtPGMXzKPvRqgK', NULL, '2026-08-05 20:19:33', '2026-09-17 11:17:55'),
(948, '944842b1-a895-4aa1-99b1-fcb11a67a5af', 'Dogmama', 'Dogmama', 'lbridgett951@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$0BrBIGysAaSDuWFp5o3/Ce2yzdVKG1lu9NT8f/ElfLhOFl39dwtGC', NULL, '2026-08-05 22:09:44', '2026-09-17 11:17:55'),
(949, '656b5d1c-9a6f-4502-8dc3-d75c5a605e09', 'LeighW3gr', 'LeighW3gr', 'leighwerner74@gmail.com', '+18312461446', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$MlKyr7rjYdlf4xYXaSe./e.i5BDAE4B7PYLENwl6mmh/LmDTQkuCa', NULL, '2026-08-09 11:32:24', '2026-09-17 11:17:55'),
(950, '3ccf95a1-61e7-427b-9e94-3425250eb2ba', 'Paigeyy2', 'Paigeyy2', 'hutchinsaraine@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ROLqcXn3uGJ8M3A/KFzb/u2HE6gKzREVTK9udQJvwKMg3qqauxflO', NULL, '2026-08-09 13:20:38', '2026-09-17 11:17:55'),
(951, '46404543-2fe3-4a0d-9c10-20c8991a1e89', 'Dasjuden', 'Dasjuden', 'cordovaraymond5@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$IyUkFRItxftqJPsmaiNweuukK.j70ETE4CP/mw6XM/Ur7gOE0YqZK', NULL, '2026-08-09 13:23:00', '2026-09-17 11:17:55'),
(952, '19906390-493c-461e-8a74-9648d02517d4', 'Amber Weaver', 'Renee86313', 'amber_weaver@icloud.com', '+19402551401', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/19906390-493c-461e-8a74-9648d02517d4/avatar.jpeg?t=1785991518511', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1986-03-31', 1, NULL, NULL, '$2y$10$PuqcTc5vFnrDpvW4Rq86LuNO7SCPPzposgwf6diDNhIdmDOn44zOC', NULL, '2026-08-05 22:40:11', '2026-09-17 11:17:55'),
(953, '3bb7b861-8408-4c8e-bbe2-0a017da861d3', 'Novasarah', 'Novasarah', 'breckenridgesarah45@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$RisEiGiwGEbLWD7VjIoBJOf4od2QHiFmjAe11i5D/tQcz21smyrzW', NULL, '2026-08-05 22:57:07', '2026-09-17 11:17:55'),
(954, 'b319e680-8d01-4d29-9dc5-b937ddde71cc', 'Novasarahb', 'Novasarahb', 's23334897@gmail.com', '+19705894720', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$fVAflpmXkx0l4oJyZ4JNA.RI8JDyrmPAXluZCK8GnMaV1bxxVRJN6', NULL, '2026-08-05 23:02:45', '2026-09-17 11:17:55'),
(955, 'f436dbba-7362-4444-beee-f1ad1f1c9a18', 'Txcashman6', 'Txcashman6', 'txcashman63@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$p48LgyNlUAIS859tuRiCUOMimxi.MyC6xSQSF2KomtAlSIyjN10K6', NULL, '2026-08-06 00:02:55', '2026-09-17 11:17:55'),
(956, '94ad6aca-d692-43f6-95aa-6d67adf95cff', 'starlenemc', 'starlenemc', 'starlenemcneal@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$qNluDofdok0QpwqhB/utE.7qnUlqRfCiGtw1xfmgRuFDD2TW15TTi', NULL, '2026-08-06 01:07:37', '2026-09-17 11:17:55'),
(957, '1ea39837-05f3-459d-b57a-f986da363c80', 'Markald87', 'Markald87', 'markaldridge87@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$dNwPl2mVurwsEl7iL2Gpre/zJjW0REvU45/JpAzSujmMVjw7CQANe', NULL, '2026-08-11 03:02:41', '2026-09-17 11:17:55'),
(958, '010252d3-346d-4142-95fb-5d2433f6e253', 'Tyler Carey', 'Bos302', 'tchaha302@gmail.com', '+13025089792', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Delaware', 'Male', '1994-12-12', 1, NULL, NULL, '$2y$10$OwAM1kCstXQh7oRjXWtVAezK.r/WTQEyprS87HEB00w4bWdxJmf3C', NULL, '2026-08-09 17:53:46', '2026-09-17 11:17:55'),
(959, '367e831e-0dfc-4e12-b6a2-56167ef375c2', 'Tonya  Swann', 'Tdial88', 'tonyadial43@gmail.com', '+17652913206', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Indiana', 'Female', '1988-12-08', 1, NULL, NULL, '$2y$10$rDlgT03lqEmdHY2RTW3du.z508in28T8V/Hq./S/sqzF9hmH3LRye', NULL, '2026-08-06 01:39:32', '2026-09-17 11:17:55'),
(960, '75ad5496-29f4-49cd-989f-58aaf2b6c7ac', 'Babytyson3', 'Babytyson3', 'riri2022fly@gmail.com', '+19193686098', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CT.7t1gLJ/rB8pfYq.hW8eDl.wjjuTh7LRnD1oH8jgfrBsEvQ3aG.', NULL, '2026-08-05 22:30:22', '2026-09-17 11:17:55'),
(961, 'b5fe69c7-808b-4496-b99a-66d55c60c246', 'Shari666', 'Shari666', 'slhbh2000@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$E3mWC2oSxcoj3/vYbwhrSuxOS5q/nA39d764UA.a9hFQ9peQ0HSjm', NULL, '2026-08-06 03:36:06', '2026-09-17 11:17:55'),
(962, '6185ba42-85a7-4a72-b1bf-cf464d2fffc1', '1kingg1', '1kingg1', 'kingwray1990@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xse2Z.mCSW1aNqTc0bkF..8VsGbpHtJimZJQ/JD.lhgXkpYs1wfZ.', NULL, '2026-08-06 05:41:58', '2026-09-17 11:17:55'),
(963, '546c8ab2-dadc-47a1-9e6e-47f23f1ae6d8', 'DavRam84', 'DavRam84', 'rambodavid318@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$9nTC/H9U05vBmcSUQbqbVuOW82i/6qAEZKE4wfifllWhamo89JidS', NULL, '2026-08-06 11:35:30', '2026-09-17 11:17:55'),
(964, '53563e25-6132-4e4e-8b37-f58a7fff6af1', 'bainsarah5', 'bainsarah5', 'bainsarah570@gmail.com', '+16156633117', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$PRcnyjGdLI7H1EoHuf1NOuwjN9gQP8bFlHybheWfyED/ZCiFg4RFC', NULL, '2026-08-06 15:08:36', '2026-09-17 11:17:55'),
(965, '27b79a67-2c04-49c8-86ad-4ffc6fd0cf1a', 'Ego9199', 'Ego9199', 'ericgonzy1981@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$P6VbbT3k1iXS/85sy9ALqejbDcSopQAFdW.ZEqpTH.UF95vcbx/y2', NULL, '2026-08-07 01:13:23', '2026-09-17 11:17:55'),
(966, '22276ced-f92c-408a-851b-02f7a8d1b3fe', 'bmaness838', 'bmaness838', 'bradleymaness699@gmail.com', '+15027912772', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Xfnclv5H5dTWWdgz2Ag0MuP3oaAxoUc6dyj9QEduuut.lk9YxFUVi', NULL, '2026-08-07 04:21:33', '2026-09-17 11:17:55'),
(967, '3aaaf67e-9ec3-453d-8d49-93dbc03408fc', 'kaysue6801', 'kaysue6801', 'kaysue6801@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$aKSpKYYb9H6AIufQE2jrouxFmyIZALxNnVMpbg2uZahUwQtpcvirO', NULL, '2026-08-07 07:20:51', '2026-09-17 11:17:55'),
(968, 'ef5c817a-d27e-45c3-bc46-7fd8da4dda2a', 'Ogfly1979', 'Ogfly1979', 'ogfly1979@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$SA4L5WhDMAC/CHI1GfbVneRXSYnvqkTFUHAatOTLWmVo.qVoY.vLK', NULL, '2026-08-07 07:52:13', '2026-09-17 11:17:55'),
(969, 'd32500de-6753-4ba6-ae07-cb8e4924dadc', 'MFbrat93', 'MFbrat93', 'nishamok777@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tNJM3.vkGQ03tkitRQmBbO9RKgxSFxLW3D2SaCIpLpH14FQ087LpG', NULL, '2026-08-07 11:46:25', '2026-09-17 11:17:55'),
(970, '8cde9c11-1247-4ecc-abf6-911df2be3062', 'ChristPKR2', 'ChristPKR2', 'leialoharobins416@gmail.com', '+18082296732', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ysVEm62S4KHpCWencXb93.hrdJxFLFnfGW/WHY6E8gHL1MdeKZsmi', NULL, '2026-08-07 00:24:18', '2026-09-17 11:17:55'),
(971, 'a477e7da-c31d-454a-95a7-882c984b9a83', 'tdukes329', 'tdukes329', 'tdukes329@gmail.com', '+15025448026', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$hkP34SkkRgqesbGelkhQiu04kN9HsmUhR2TNxNvq00zYI8QHNmU3y', NULL, '2026-08-07 17:16:24', '2026-09-17 11:17:55'),
(972, '6746e8d8-310c-4e2a-a463-ca54030f3b48', 'K101104', 'K101104', 'klonganecker50@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$T6Oz.ZEr.2IVx7FgOXmxduKRCpKz968ESPvG9fP.z4fOZjm1aHHbm', NULL, '2026-08-09 23:17:07', '2026-09-17 11:17:55'),
(973, 'f240284c-4ae8-4735-8111-c70d8b8aacfc', 'Trent Reinhart', 'TR6676', 'reinhart6676@gmail.com', '+15022248700', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Kentucky', 'Male', '1996-05-30', 1, NULL, NULL, '$2y$10$7pei7YO.FSZWOsa2lYHgu..qjCnH0pUnhYcNfhKEx/vhRLcETFbqe', NULL, '2026-08-07 22:36:13', '2026-09-17 11:17:55'),
(974, '68ef1bc0-3075-47a6-ad16-246052e8e8e8', 'Egb8ps', 'Egb8ps', 'ezqt0902@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Z5yR/b6HKHx6P1UgC5YpgOQvfCFGTQJC0jC7jdLzOCK/M6DvVu5uS', NULL, '2026-08-08 00:18:13', '2026-09-17 11:17:55'),
(975, '984a7b5a-f4cc-460a-8e15-4575520d8dd6', 'Playbunny', 'Playbunny', 'playbunny.t@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xocUadRr6v0WQaa30xLwh.67iOJsdHBPIlk6knOXdpeC6NaSUKhhu', NULL, '2026-08-08 00:37:26', '2026-09-17 11:17:55'),
(976, 'b409492f-ab8b-4d82-9216-29d0b3350614', 'Shawnmfh75', 'Shawnmfh75', 'hougardyshawn83@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1bKI4AOOSIo2hYpLTumtEeN1R2X1teQSsgc4FEAiRqmPoddfKRmyC', NULL, '2026-08-08 02:30:25', '2026-09-17 11:17:55'),
(977, '76bc6b01-2ab8-4aaa-9e3c-596b23fe8715', 'Blessd7', 'Blessd7', '711saved711@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$VEUmcn3vmB03OxqL3TGeQuZKfhXVJqn1i.Ms3x2lKyXs.9NxtiCGu', NULL, '2026-08-08 08:21:08', '2026-09-17 11:17:55'),
(978, 'ffdf399b-4556-4093-96aa-301b98d277c0', 'Antsmarty', 'Antsmarty', 'antartist777@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xGw8m43FS6V2L4KtmjRww.srJNF/kgush54xGYDR0ucroAC38tvR6', NULL, '2026-08-10 00:07:03', '2026-09-17 11:17:55'),
(979, '662e24da-f202-4f47-b538-7a7e6deebff9', 'Zenja Booth', 'Zenjastar', 'boothzenja@gmail.com', '(904) 837-0673', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Florida', 'Female', '1978-11-28', 1, NULL, NULL, '$2y$10$g1sjukm/mgAhaIotpWDmg.1g9smMXYsuCMPcOuZsVM4smBnfgJcQa', NULL, '2026-08-08 10:47:14', '2026-09-17 11:17:55'),
(980, 'd5e0d6bb-6da5-4750-83f3-02c8f53689c7', 'Hisince96', 'Hisince96', 'dntvelasquez9six@gmail.com', '+19163599705', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$GNNHzQp5ssjwN/ocCGeU.u/ZNGam5BglktdOZ2Pna/avaHP1.5q2O', NULL, '2026-08-08 13:19:01', '2026-09-17 11:17:55'),
(981, 'c9eecf75-690f-4dce-b062-23c8783986f8', 'Meko123', 'Meko123', 'drakeem2025@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$CnPj3Gt9FAUntgk/5uXQ8.9YWagnRII4H8SUkodNodc4RN1TCocIW', NULL, '2026-08-09 00:34:23', '2026-09-17 11:17:55'),
(982, '1ff0e653-a685-4b35-92b4-1d474fc4fa7c', 'Michelle69', 'Michelle69', 'leannshoemaker4@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ryyKODRS9F9bBfXUBlRAj.4hmliNGBUgv/ImZaeiBrlrmR1uqpZRW', NULL, '2026-08-09 00:45:33', '2026-09-17 11:17:55'),
(983, '30e775da-e89b-4c51-8210-2c927ceb5095', 'Michelle80', 'Michelle80', 'michellebuchan30@gmail.com', '+13184793296', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$YhQVjN.hm3ZDXFLmfbcmOuRRD.Ty1XyB3GwcvKEFofA73RtXUMta2', NULL, '2026-08-09 00:44:21', '2026-09-17 11:17:55'),
(984, '3e4313c9-5582-4415-a06b-8ddab3380519', 'Heyheyyou', 'Heyheyyou', 'weric1804@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$4pKBPcSW.r1q0K7Zb9ySjeajtTwlviXCyC08Opg7iKPCg7S7t7plG', NULL, '2026-08-10 00:28:31', '2026-09-17 11:17:55'),
(985, '266d5230-ab21-42df-b2b4-e3acee691bee', 'SunBug27', 'SunBug27', 'cruzanna2763@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$/3w1wXwONUuTPgLYlQ2bx.tDJm7az9XNBkhgMul0DOG9qNua7VWES', NULL, '2026-08-10 01:54:09', '2026-09-17 11:17:55'),
(986, '868ad06c-e42d-4597-9a00-557562dd9be4', 'Michellelb', 'Michellelb', 'michellebuchan8083@outlook.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$8LQQJ76GZonRB6w9jlr6COv/fxUIdA.SkFXSwn.yGRoUs.ijuVJ4G', NULL, '2026-08-10 06:44:33', '2026-09-17 11:17:55'),
(987, 'da565f50-f5f4-4955-bc7d-b63eea2bb2b2', 'LucyJayne1', 'LucyJayne1', 'michelleleann8083@gmail.com', '+13184793296', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$jZRmPPKT8EmThG1wcEOYJuw9VmR4CfUr3GnLM/wqdnxznqu4QZ7Ja', NULL, '2026-08-10 06:47:42', '2026-09-17 11:17:55'),
(988, '94d6d0ea-7974-4c8d-9672-5fe541c8ee3a', 'Bdubb0328', 'Bdubb0328', 'brandon.walker0328@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$1QBZknteJ2FaMH/rdbHM3O8/tXFJTZ/dvmTIjenKqO05QovJez47C', NULL, '2026-08-10 11:04:04', '2026-09-17 11:17:55'),
(989, '7a502a2e-5739-4d9d-8d3d-30e026ee4041', 'Trouble', 'Trouble', '1wildcreation@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$xP2ydFcaIgHkf5Y5NLeMJemZ5oivw5RvP7O.vAiU0A.LmDnKd.CR.', NULL, '2026-08-10 12:05:02', '2026-09-17 11:17:55'),
(990, 'dc0edc6f-09d5-405f-8c3f-059787262c00', 'Eduardo Saucedo', 'Lostboy', 'jesinfinitynbeyond3249@gmail.com', '+16612408216', 'https://mgxcjmbpatmelvwvaqjt.supabase.co/storage/v1/object/public/avatars/dc0edc6f-09d5-405f-8c3f-059787262c00/avatar.jpg?t=1786410203729', NULL, 0.00, 'user', 0, NULL, NULL, 1, 1, '2026-05-13 05:47:29', 'United States', 'California', 'Male', '1990-05-23', 1, '2026-05-13 05:47:29', NULL, '$2y$10$61yjNIHqe6Pfl2MEt2ftF.ioswQEiIcjcUtx1ntM48rN/Gm9OXyxW', NULL, '2026-05-13 05:47:29', '2026-09-17 11:17:55'),
(991, 'a176732d-ff98-4944-a8ac-20b02a465278', 'Momky46', 'Momky46', 'momky46@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$Wq7AHA1mutqUl5wRswQJz.ofnxlUmeDS4A.Cye0feJN3dAO0UQ52m', NULL, '2026-08-11 08:37:24', '2026-09-17 11:17:55'),
(992, '691f1c1a-12e6-45d4-8f71-ec5e98c0d54f', 'JamesDowe', 'JamesDowe', 'squeakyrowe10@gmail.com', '+13362406257', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JnRDIQCxVDITTprEupw9tOc4.gmmCAdsBGWwHDPdTF2a9oRGH4DGi', NULL, '2026-08-10 22:28:52', '2026-09-17 11:17:55'),
(993, '20d4dcd6-c7d5-4aa6-a4fd-69f606660d42', 'Markald1', 'Markald1', 'ronnyaldridge9@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$7HSoPqjT.zi1waa43AFBHe1OQt.SBikUcVL.iKb3XAkyhdErtH5ce', NULL, '2026-08-11 03:01:12', '2026-09-17 11:17:55'),
(994, '026a829d-6789-44ca-936f-ef45325bb17e', 'idler76', 'idler76', 'alirezanajafabadi293@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$uwhk9lsVbEbJC/WmJ52eeuazK35g7c0RjMsc.N.S7qr1ArFgEi7dq', NULL, '2026-08-11 10:31:35', '2026-09-17 11:17:55'),
(995, '6f7971ea-e6de-483d-8019-ed861e6f8757', 'Jessd77os', 'Jessd77os', 'jessdejong84@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$4MQRi4fyKyKg.0KRvqb1f.TeasPG9C/r4GrECF6nOrL41.WWaGpLa', NULL, '2026-08-11 16:19:21', '2026-09-17 11:17:55'),
(996, '5e76bd18-4265-40df-b062-18a11c66a86e', 'shaunpitch', 'shaunpitch', 'shaunpitchford991@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$ipCYHnpQv/Jh25EDRx89JuXlbZoSyfko.egtmNpBvrf/kKW5pOQGe', NULL, '2026-08-12 00:47:59', '2026-09-17 11:17:55'),
(997, '5483ce7b-f526-4539-a573-18fcf3156960', 'genowworth', 'genowworth', 'worth0991j@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$reS.dUqQ9Pwoa.ZVxk2ER.jo8IATiJQGJoXqVlyrvmootGw97BY1y', NULL, '2026-08-12 02:39:22', '2026-09-17 11:17:55'),
(998, '647c9ead-26c3-4d63-98ab-81a794c302b3', 'Joniii', 'Joniii', 'nizhonifarisbenally@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$.hqpLg0dhmtVwepEF9FkQOmapfi7tAzfNAtoIL9LMiaxcaux4fTrG', NULL, '2026-08-12 04:14:37', '2026-09-17 11:17:55'),
(999, 'e6f8312c-0d87-46f5-b222-8a7ce8b8c240', 'Kaykay89', 'Kaykay89', 'kds_2608@yahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$nqybP1oc/VcYItt26lopXuVBHsIYNUkyQlI6jk8JYNSZjEyGA/iJ.', NULL, '2026-08-12 09:22:31', '2026-09-17 11:17:55'),
(1000, 'a9a38933-56a2-493d-ae04-7d80e9a5fae5', 'Tahiti86', 'Tahiti86', 'tahitianqueen50@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$tcFzyHITcTsohJoDkRTqEudrghyz7K4hgPgYB/DsaNLwxwiPDPXYC', NULL, '2026-08-12 12:05:45', '2026-09-17 11:17:55'),
(1001, '147c1f99-97e6-4478-8c8d-e261ee90c04b', 'Elaine', 'Elaine', 'heatherbrumbley80@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$10$JYgSyLIYY3MDFj92XqyJL.Ato/6DTijJweanQOdorE8P1TosLK9HK', NULL, '2026-08-12 15:52:18', '2026-09-17 11:17:55'),
(1002, '31e3512b-aefc-4890-b772-fa6b2891cda7', 'Misslady89', 'Misslady89', 'ishea.ventura74@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$YHYlNvzRudgbai9xCr4JE.fAw9LzUfrZ0dBwq5lObEW.PsRBrimoC', NULL, '2026-08-12 19:03:00', '2026-09-17 11:17:55'),
(1003, 'da0779cc-aaa5-4ea8-8a04-478d1a72054e', 'nhendrick1', 'nhendrick1', 'nhendrick10@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2y$12$98EO95FRyXWvwoH6KDyEP.TRrcdm6IX2S3ePaM8tNe2kJLNXLTK7a', NULL, '2026-08-12 19:42:07', '2026-09-17 11:17:55');

-- --------------------------------------------------------

--
-- Table structure for table `verification_settings`
--

CREATE TABLE `verification_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email_verification_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `phone_verification_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `otp_expiry_minutes` int(10) UNSIGNED NOT NULL DEFAULT 5,
  `resend_cooldown_seconds` int(10) UNSIGNED NOT NULL DEFAULT 60,
  `max_attempts` int(10) UNSIGNED NOT NULL DEFAULT 5,
  `max_per_hour` int(10) UNSIGNED DEFAULT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_port` int(10) UNSIGNED DEFAULT 587,
  `smtp_username` varchar(255) DEFAULT NULL,
  `smtp_password` varchar(255) DEFAULT NULL,
  `smtp_encryption` varchar(255) DEFAULT 'tls',
  `mail_from_address` varchar(255) DEFAULT NULL,
  `mail_from_name` varchar(255) DEFAULT 'Horizon Players',
  `infobip_base_url` varchar(255) DEFAULT NULL,
  `infobip_api_key` text DEFAULT NULL,
  `infobip_sms_sender` varchar(255) DEFAULT 'Horizon',
  `infobip_whatsapp_sender` varchar(255) DEFAULT NULL,
  `infobip_email_sender` varchar(255) DEFAULT NULL,
  `infobip_sms_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `infobip_whatsapp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `infobip_email_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `brevo_api_key` text DEFAULT NULL,
  `brevo_sms_sender` varchar(255) DEFAULT NULL,
  `brevo_sms_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `brevo_email_sender` varchar(255) DEFAULT NULL,
  `brevo_email_sender_name` varchar(255) DEFAULT NULL,
  `brevo_email_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `preferred_phone_channel` varchar(20) NOT NULL DEFAULT 'sms_only',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `verification_settings`
--

INSERT INTO `verification_settings` (`id`, `email_verification_enabled`, `phone_verification_enabled`, `otp_expiry_minutes`, `resend_cooldown_seconds`, `max_attempts`, `max_per_hour`, `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, `smtp_encryption`, `mail_from_address`, `mail_from_name`, `infobip_base_url`, `infobip_api_key`, `infobip_sms_sender`, `infobip_whatsapp_sender`, `infobip_email_sender`, `infobip_sms_enabled`, `infobip_whatsapp_enabled`, `infobip_email_enabled`, `brevo_api_key`, `brevo_sms_sender`, `brevo_sms_enabled`, `brevo_email_sender`, `brevo_email_sender_name`, `brevo_email_enabled`, `preferred_phone_channel`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 5, 60, 5, NULL, NULL, 587, NULL, NULL, 'tls', NULL, 'Horizon Players', 'nd2vdj.api.infobip.com', '2e414403e7b4d8d0fbfc79d83cafd8bf-bee7f9d7-aa68-4f10-9bf5-1b1912e0f04d', 'ServiceSMS', '447860088970', NULL, 1, 0, 0, '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', 'Horizon', 1, 'developer@kaziagency.com', NULL, 1, 'sms_only', '2026-08-07 10:52:41', '2026-09-14 07:09:58');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_methods`
--

CREATE TABLE `withdraw_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `minimum_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `maximum_amount` decimal(12,2) NOT NULL DEFAULT 10000.00,
  `fee_percentage` decimal(5,2) NOT NULL DEFAULT 0.00,
  `fee_fixed` decimal(12,2) NOT NULL DEFAULT 0.00,
  `processing_time` varchar(255) NOT NULL DEFAULT 'Instant',
  `instructions` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `withdraw_methods`
--

INSERT INTO `withdraw_methods` (`id`, `name`, `code`, `logo_url`, `minimum_amount`, `maximum_amount`, `fee_percentage`, `fee_fixed`, `processing_time`, `instructions`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'Chime', 'cashapp', '/storage/brand-assets/pObfBqNbWWSNWYa4E17LxZt7LKtsygviXADhoRyb.jpg', 40.00, 300.00, 0.00, 0.00, 'Instant - 15 mins', NULL, 1, 1, '2026-08-01 12:55:11', '2026-09-17 10:06:15'),
(2, 'PayPal', 'zelle', '/storage/brand-assets/ojSLneodRbwzzB2DibRnixrmkvBvTtlNASnsn9bY.png', 20.00, 300.00, 0.00, 0.00, '10 - 30 mins', NULL, 1, 2, '2026-08-01 12:55:11', '2026-09-17 10:07:04'),
(3, 'USDC', 'venmo', '/storage/brand-assets/zBvi5cIw9SCng0ceVjzKBXhAMmyxvMp1PmTvHYEz.png', 40.00, 100.00, 0.00, 0.00, '10 - 30 mins', NULL, 1, 3, '2026-08-01 12:55:11', '2026-09-16 10:47:32'),
(4, 'Cashapp', 'zelle_2', '/storage/brand-assets/8rSEFJTKgT5jCTjUVy3lDwWguGvmXzv2WbYWlUS3.png', 50.00, 300.00, 0.00, 0.00, 'Instant', NULL, 1, 0, '2026-09-16 10:47:54', '2026-09-17 10:05:46'),
(5, 'Zelle', 'zelle_3', '/storage/brand-assets/3RmgpYEXCH3JbAekdqT1ku0tJG2CAkd1xrwSeYpn.jpg', 20.00, 10000.00, 0.00, 0.00, 'Instant', NULL, 1, 0, '2026-09-17 10:08:12', '2026-09-17 10:09:07');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_method_fields`
--

CREATE TABLE `withdraw_method_fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `method_id` bigint(20) UNSIGNED NOT NULL,
  `field_name` varchar(255) NOT NULL,
  `field_label` varchar(255) NOT NULL,
  `field_type` enum('text','number','email','textarea','select') NOT NULL DEFAULT 'text',
  `placeholder` varchar(255) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 1,
  `validation_rule` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `withdraw_method_fields`
--

INSERT INTO `withdraw_method_fields` (`id`, `method_id`, `field_name`, `field_label`, `field_type`, `placeholder`, `is_required`, `validation_rule`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 1, 'chimetag_tag', 'Chimetag/Tag', 'text', '$yourcashtag', 1, NULL, 1, '2026-08-01 12:55:11', '2026-09-17 10:08:52'),
(3, 2, 'paypal_email', 'Paypal email', 'email', 'John Doe', 1, NULL, 2, '2026-08-01 12:55:11', '2026-09-17 10:07:04'),
(4, 3, 'wallet_address', 'Wallet Address', 'text', '@username', 1, NULL, 1, '2026-08-01 12:55:11', '2026-09-17 10:07:30'),
(5, 5, 'emaill_address', 'Emaill Address', 'email', NULL, 1, NULL, 0, '2026-09-17 10:08:13', '2026-09-17 10:08:13'),
(6, 5, 'number', 'Number', 'text', NULL, 1, NULL, 0, '2026-09-17 10:08:13', '2026-09-17 10:08:13'),
(7, 5, 'name_of_zelle', 'Name of Zelle', 'text', NULL, 1, NULL, 0, '2026-09-17 10:08:13', '2026-09-17 10:08:13'),
(8, 4, 'cashtag_tag', 'Cashtag/ Tag', 'text', NULL, 1, NULL, 0, '2026-09-17 10:09:30', '2026-09-17 10:09:30');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_requests`
--

CREATE TABLE `withdraw_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `fee_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `receive_amount` decimal(12,2) NOT NULL,
  `account_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`account_details`)),
  `proof_url` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `processed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `audit_logs_admin_id_foreign` (`admin_id`);

--
-- Indexes for table `backups`
--
ALTER TABLE `backups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `backups_created_by_foreign` (`created_by`),
  ADD KEY `backups_created_at_index` (`created_at`),
  ADD KEY `backups_type_status_index` (`type`,`status`);

--
-- Indexes for table `backup_downloads`
--
ALTER TABLE `backup_downloads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `backup_downloads_admin_id_foreign` (`admin_id`),
  ADD KEY `backup_downloads_created_at_index` (`created_at`),
  ADD KEY `backup_downloads_backup_id_index` (`backup_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_expiration_index` (`expiration`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_locks_expiration_index` (`expiration`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email_templates_trigger_event_index` (`trigger_event`);

--
-- Indexes for table `export_requests`
--
ALTER TABLE `export_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `export_requests_reviewed_by_foreign` (`reviewed_by`),
  ADD KEY `export_requests_created_at_index` (`created_at`),
  ADD KEY `export_requests_manager_id_status_index` (`manager_id`,`status`),
  ADD KEY `export_requests_status_index` (`status`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `fast_payment_api_logs`
--
ALTER TABLE `fast_payment_api_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fast_payment_api_logs_fast_payment_transaction_id_foreign` (`fast_payment_transaction_id`),
  ADD KEY `fast_payment_api_logs_created_at_index` (`created_at`),
  ADD KEY `fast_payment_api_logs_action_index` (`action`);

--
-- Indexes for table `fast_payment_transactions`
--
ALTER TABLE `fast_payment_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fast_payment_transactions_order_sn_unique` (`order_sn`),
  ADD KEY `fast_payment_transactions_transaction_id_foreign` (`transaction_id`),
  ADD KEY `fast_payment_transactions_user_id_foreign` (`user_id`),
  ADD KEY `fast_payment_transactions_payment_status_index` (`payment_status`),
  ADD KEY `fast_payment_transactions_fast_transaction_id_index` (`fast_transaction_id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_accounts`
--
ALTER TABLE `game_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_accounts_game_id_foreign` (`game_id`),
  ADD KEY `game_accounts_assigned_to_foreign` (`assigned_to`);

--
-- Indexes for table `game_api_logs`
--
ALTER TABLE `game_api_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_api_logs_created_at_index` (`created_at`),
  ADD KEY `game_api_logs_provider_id_index` (`provider_id`),
  ADD KEY `game_api_logs_action_index` (`action`);

--
-- Indexes for table `game_api_providers`
--
ALTER TABLE `game_api_providers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `game_api_providers_name_unique` (`name`);

--
-- Indexes for table `game_api_provider_secrets`
--
ALTER TABLE `game_api_provider_secrets`
  ADD PRIMARY KEY (`provider_id`),
  ADD KEY `game_api_provider_secrets_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `game_provider_assignments`
--
ALTER TABLE `game_provider_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `game_provider_assignments_game_id_unique` (`game_id`),
  ADD KEY `game_provider_assignments_provider_id_foreign` (`provider_id`);

--
-- Indexes for table `game_unlock_requests`
--
ALTER TABLE `game_unlock_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_unlock_requests_user_id_foreign` (`user_id`),
  ADD KEY `game_unlock_requests_game_id_foreign` (`game_id`),
  ADD KEY `game_unlock_requests_approved_by_foreign` (`approved_by`),
  ADD KEY `game_unlock_requests_game_account_id_foreign` (`game_account_id`);

--
-- Indexes for table `ghl_api_logs`
--
ALTER TABLE `ghl_api_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ghl_api_logs_created_at_index` (`created_at`),
  ADD KEY `ghl_api_logs_user_id_index` (`user_id`),
  ADD KEY `ghl_api_logs_action_index` (`action`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manual_verification_requests`
--
ALTER TABLE `manual_verification_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `manual_verification_requests_reviewed_by_foreign` (`reviewed_by`),
  ADD KEY `manual_verification_requests_type_status_index` (`type`,`status`),
  ADD KEY `manual_verification_requests_user_id_index` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `otp_verifications`
--
ALTER TABLE `otp_verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otp_verifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_requests`
--
ALTER TABLE `password_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `password_requests_user_id_foreign` (`user_id`),
  ADD KEY `password_requests_game_account_id_foreign` (`game_account_id`),
  ADD KEY `password_requests_reviewed_by_foreign` (`reviewed_by`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_gateway_accounts`
--
ALTER TABLE `payment_gateway_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_gateway_accounts_gateway_id_foreign` (`gateway_id`);

--
-- Indexes for table `recovery_configs`
--
ALTER TABLE `recovery_configs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `recovery_configs_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `rewards_config`
--
ALTER TABLE `rewards_config`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rewards_config_key_unique` (`key`);

--
-- Indexes for table `reward_history`
--
ALTER TABLE `reward_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reward_history_user_id_foreign` (`user_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_channels`
--
ALTER TABLE `support_channels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transactions_idempotency_key_unique` (`idempotency_key`),
  ADD KEY `transactions_user_id_foreign` (`user_id`),
  ADD KEY `transactions_game_id_foreign` (`game_id`),
  ADD KEY `transactions_reviewed_by_foreign` (`reviewed_by`),
  ADD KEY `transactions_gateway_id_foreign` (`gateway_id`),
  ADD KEY `transactions_gateway_account_id_foreign` (`gateway_account_id`);

--
-- Indexes for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction_logs_transaction_id_foreign` (`transaction_id`),
  ADD KEY `transaction_logs_action_by_foreign` (`action_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_legacy_id_unique` (`legacy_id`);

--
-- Indexes for table `verification_settings`
--
ALTER TABLE `verification_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `withdraw_methods_code_unique` (`code`);

--
-- Indexes for table `withdraw_method_fields`
--
ALTER TABLE `withdraw_method_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `withdraw_method_fields_method_id_foreign` (`method_id`);

--
-- Indexes for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `withdraw_requests_user_id_foreign` (`user_id`),
  ADD KEY `withdraw_requests_method_id_foreign` (`method_id`),
  ADD KEY `withdraw_requests_processed_by_foreign` (`processed_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `backups`
--
ALTER TABLE `backups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `backup_downloads`
--
ALTER TABLE `backup_downloads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `export_requests`
--
ALTER TABLE `export_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fast_payment_api_logs`
--
ALTER TABLE `fast_payment_api_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fast_payment_transactions`
--
ALTER TABLE `fast_payment_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `game_accounts`
--
ALTER TABLE `game_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `game_api_logs`
--
ALTER TABLE `game_api_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `game_api_providers`
--
ALTER TABLE `game_api_providers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `game_provider_assignments`
--
ALTER TABLE `game_provider_assignments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `game_unlock_requests`
--
ALTER TABLE `game_unlock_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ghl_api_logs`
--
ALTER TABLE `ghl_api_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manual_verification_requests`
--
ALTER TABLE `manual_verification_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otp_verifications`
--
ALTER TABLE `otp_verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `password_requests`
--
ALTER TABLE `password_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `payment_gateway_accounts`
--
ALTER TABLE `payment_gateway_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `recovery_configs`
--
ALTER TABLE `recovery_configs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rewards_config`
--
ALTER TABLE `rewards_config`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reward_history`
--
ALTER TABLE `reward_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `support_channels`
--
ALTER TABLE `support_channels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1004;

--
-- AUTO_INCREMENT for table `verification_settings`
--
ALTER TABLE `verification_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `withdraw_method_fields`
--
ALTER TABLE `withdraw_method_fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `backups`
--
ALTER TABLE `backups`
  ADD CONSTRAINT `backups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `backup_downloads`
--
ALTER TABLE `backup_downloads`
  ADD CONSTRAINT `backup_downloads_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `backup_downloads_backup_id_foreign` FOREIGN KEY (`backup_id`) REFERENCES `backups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `export_requests`
--
ALTER TABLE `export_requests`
  ADD CONSTRAINT `export_requests_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `export_requests_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `fast_payment_api_logs`
--
ALTER TABLE `fast_payment_api_logs`
  ADD CONSTRAINT `fast_payment_api_logs_fast_payment_transaction_id_foreign` FOREIGN KEY (`fast_payment_transaction_id`) REFERENCES `fast_payment_transactions` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `fast_payment_transactions`
--
ALTER TABLE `fast_payment_transactions`
  ADD CONSTRAINT `fast_payment_transactions_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fast_payment_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `game_accounts`
--
ALTER TABLE `game_accounts`
  ADD CONSTRAINT `game_accounts_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `game_accounts_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `game_api_logs`
--
ALTER TABLE `game_api_logs`
  ADD CONSTRAINT `game_api_logs_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `game_api_providers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `game_api_provider_secrets`
--
ALTER TABLE `game_api_provider_secrets`
  ADD CONSTRAINT `game_api_provider_secrets_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `game_api_providers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `game_api_provider_secrets_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `game_provider_assignments`
--
ALTER TABLE `game_provider_assignments`
  ADD CONSTRAINT `game_provider_assignments_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `game_provider_assignments_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `game_api_providers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `game_unlock_requests`
--
ALTER TABLE `game_unlock_requests`
  ADD CONSTRAINT `game_unlock_requests_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `game_unlock_requests_game_account_id_foreign` FOREIGN KEY (`game_account_id`) REFERENCES `game_accounts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `game_unlock_requests_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `game_unlock_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ghl_api_logs`
--
ALTER TABLE `ghl_api_logs`
  ADD CONSTRAINT `ghl_api_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `manual_verification_requests`
--
ALTER TABLE `manual_verification_requests`
  ADD CONSTRAINT `manual_verification_requests_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `manual_verification_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `otp_verifications`
--
ALTER TABLE `otp_verifications`
  ADD CONSTRAINT `otp_verifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_requests`
--
ALTER TABLE `password_requests`
  ADD CONSTRAINT `password_requests_game_account_id_foreign` FOREIGN KEY (`game_account_id`) REFERENCES `game_accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `password_requests_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `password_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_gateway_accounts`
--
ALTER TABLE `payment_gateway_accounts`
  ADD CONSTRAINT `payment_gateway_accounts_gateway_id_foreign` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `recovery_configs`
--
ALTER TABLE `recovery_configs`
  ADD CONSTRAINT `recovery_configs_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `reward_history`
--
ALTER TABLE `reward_history`
  ADD CONSTRAINT `reward_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `transactions_gateway_account_id_foreign` FOREIGN KEY (`gateway_account_id`) REFERENCES `payment_gateway_accounts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `transactions_gateway_id_foreign` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `transactions_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  ADD CONSTRAINT `transaction_logs_action_by_foreign` FOREIGN KEY (`action_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaction_logs_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `withdraw_method_fields`
--
ALTER TABLE `withdraw_method_fields`
  ADD CONSTRAINT `withdraw_method_fields_method_id_foreign` FOREIGN KEY (`method_id`) REFERENCES `withdraw_methods` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  ADD CONSTRAINT `withdraw_requests_method_id_foreign` FOREIGN KEY (`method_id`) REFERENCES `withdraw_methods` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `withdraw_requests_processed_by_foreign` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `withdraw_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
